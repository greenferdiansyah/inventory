<!-- START: dashboard alpha -->
<style type="text/css">
    .pointer {
        cursor: pointer;
    }
  /*  .read-more-state {
      display: none;
    }
    .read-more-target {
      opacity: 0;
      max-height: 0;
      font-size: 0;
      transition: .25s ease;
    }
    .read-more-state:checked ~ .read-more-wrap .read-more-target {
      opacity: 1;
      font-size: inherit;
      max-height: 999em;
    }
    .read-more-state ~ .read-more-trigger:before {
      content: 'Read more';
    }
    .read-more-state:checked ~ .read-more-trigger:before {
      content: 'Read less';
    }
    .read-more-trigger {
      cursor: pointer;
      display: inline-block;
      padding: 0 .5em;
      color: #666;
      font-size: .9em;
      line-height: 2;
      border: 1px solid #ddd;
      border-radius: .25em;
    }*/
    .panel-actions {
      margin-top: -20px;
      margin-bottom: 0;
      text-align: right;
    }
    .panel-actions a {
      color:#333;
    }
    .panel-fullscreen {
        display: block;
        z-index: 9999;
        position: fixed;
        width: 100%;
        height: 100%;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        overflow: auto;
    }
</style>
<div class="row">
    <div class="col-lg-4">
        <div class="cat__core__sortable" id="left-col0">
            <section class="card panel panel-default" order-id="card-000">
                <div class="card-header">
                    E-Pelaporan
                    <div class="pull-right cat__core__sortable__control">
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                </div>
                <div class="card-block">
                    <div class="cat__apps__messaging">
                        <input type="hidden" name="no_laporan" id="no_laporan" value="0" style="display: none;">
                        <div class="custom-scroll cat__core__scrollable" style="height: 21.50rem;">
                            <div class="cat__apps__chat-block" style="display: none;">
                                <div class="cat__apps__chat-block__item clearfix">
                                    <div class="cat__apps__chat-block__avatar">
                                        <a class="cat__core__avatar" href="javascript:void(0);">
                                            <img src="{base}assets/img/warning_image.png" alt="Alternative text to the image">
                                        </a>
                                    </div>
                                    <div class="cat__apps__chat-block__content">  
                                    <strong>Suharti</strong>  
                                    <input type="checkbox" class="read-more-state" id="post-1" />
                                        <p class="read-more-wrap">Terjadi Kerusuhan. 
                                            <span class="read-more-target">di TPS 66 Kab Jayawijawa. Tanggal 23 Januari 2018 Jam 09.00 WIB.
                                            </span>
                                        </p>
                                      <label for="post-1" class="read-more-trigger"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>    
    <div class="col-lg-8">
        <div class="cat__core__sortable" id="left-col">
            <section class="card panel panel-default" order-id="card-001">
                <div class="card-header">
                    <div class="pull-right cat__core__sortable__control">
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                    <div class="form-group row">
                            <label class="col-md-3 col-form-label" for="l0">Masukkan Nama Daerah</label>
                            <div class="col-md-6">
                                <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="nama_wilayah" 
                                            name="nama_wilayah">
                                        <option value="">Pilih Wilayah</option>
                                       {list_pilkada}
                                </select>
                            </div>
                    </div>
                </div>
                <div class="card-block">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="panel-body" style="text-align: center;font-weight: bold;">
                                <div id="map" style="width: 100%; height: 265px;"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div> 
    <div class="col-lg-4">
        <div class="cat__core__sortable" id="left-col1">
            <section class="card panel panel-default" order-id="card-002">
                <div class="card-header">
                    <strong>PILKADA GUBERNUR</strong>
                    <div class="pull-right cat__core__sortable__control">
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                </div>
                <div class="card-block">
                    <div class="row">
                        <div class="col-xl-12">
                            <div id="chart_pilgub" style="height: 150px"></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="cat__core__sortable" id="left-col2">
            <section class="card panel panel-default" order-id="card-003"> 
                <div class="card-header">
                    <strong>PILKADA WALIKOTA</strong>
                    <div class="pull-right cat__core__sortable__control">
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                </div>
                <div class="card-block">
                    <div class="row">
                        <div class="col-xl-12">
                            <div id="chart_walkot" style="height: 150px"></div>
                        </div> 
                    </div>
                </div>
            </section>
        </div>
    </div> 
    <div class="col-lg-4">
        <div class="cat__core__sortable" id="left-col3">
            <section class="card panel panel-default" order-id="card-004">
                <div class="card-header">
                    <strong>PILKADA BUPATI</strong>
                    <div class="pull-right cat__core__sortable__control">
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                </div>
                <div class="card-block">
                    <div class="row">
                        <div class="col-xl-12">
                            <div id="chart_bupati" style="height: 150px"></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="cat__core__sortable" id="left-col4">
            <section class="card panel panel-default" order-id="card-008">
                <div class="card-header">
                    <strong>PILKADA CALON TUNGGAL</strong>
                    <div class="pull-right cat__core__sortable__control">
                        <span id="jml_calon_tunggal"></span>
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                </div>
                <div class="card-block">
                    <div class="cat__apps__messaging">
                        <div class="custom-scroll cat__core__scrollable" style="height: 21.50rem;">
                           <div class="row">
                                <div class="col-lg-12">
                                    <div class="mb-5">
                                        <table class="table">
                                            <tbody id="list_calon_tunggal">
                                                <tr>
                                        
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>    
                            </div> 
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="cat__core__sortable" id="left-col5">
            <section class="card panel panel-default" order-id="card-006">
                <div class="card-header">
                    <strong>PILKADA CALON PETAHANA</strong>
                    <div class="pull-right cat__core__sortable__control">
                        <span id="jml_calon_petahana"></span>
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                </div>
                <div class="card-block">
                    <div class="cat__apps__messaging">
                        <div class="custom-scroll cat__core__scrollable" style="height: 21.50rem;">
                           <div class="row">
                                <div class="col-lg-12">
                                    <div class="mb-5">
                                        <table class="table">
                                            <tbody id="list_calon_petahana">
                                                <tr>
                                        
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>    
                            </div> 
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="cat__core__sortable" id="left-col6">
            <section class="card panel panel-default" order-id="card-007">
                <div class="card-header">
                    <strong>PILKADA CALON UNSUR ASN</strong>
                    <div class="pull-right cat__core__sortable__control">
                        <span id="jml_calon_asn"></span>
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                </div>
                <div class="card-block">
                    <div class="cat__apps__messaging">
                        <div class="custom-scroll cat__core__scrollable" style="height: 21.50rem;">
                           <div class="row">
                                <div class="col-lg-12">
                                    <div class="mb-5">
                                        <table class="table">
                                            <tbody id="list_calon_asn">
                                                <tr>
                                        
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>    
                            </div> 
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="cat__core__sortable" id="left-col7">
            <section class="card panel panel-default" order-id="card-008">
                <div class="card-header">
                    <strong>PILKADA CALON INDEPENDENT</strong>
                    <div class="pull-right cat__core__sortable__control">
                        <span id="jml_calon_independent"></span>
                        <i class="fa fa-expand mr-2 glyphicon glyphicon-resize-full fullscr" data-toggle="tooltip" data-placement="left" title="" data-original-title="Full Screen"></i>
                        <i class="icmn-minus mr-2 cat__core__sortable__collapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Collapse"></i>
                        <i class="icmn-plus mr-2 cat__core__sortable__uncollapse" data-toggle="tooltip" data-placement="left" title="" data-original-title="Uncollapse"></i>
                        <i class="icmn-cross cat__core__sortable__close" data-toggle="tooltip" data-placement="left" title="" data-original-title="Remove"></i>
                    </div>
                </div>
                <div class="card-block">
                    <div class="cat__apps__messaging">
                        <div class="custom-scroll cat__core__scrollable" style="height: 21.50rem;">
                           <div class="row">
                                <div class="col-lg-12">
                                    <div class="mb-5">
                                        <table class="table">
                                            <tbody id="list_calon_independent">
                                                <tr>
                                        
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>    
                            </div> 
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>  

<!-- START: page scripts -->
<script type="text/javascript">
    $(document).ready(function () {
    //Toggle fullscreen
        $(".fullscr").click(function (e) {
            e.preventDefault();
            
            var $this = $(this);
            if ($this.children('i').hasClass('glyphicon-resize-full'))
            {
                $this.children('i').removeClass('glyphicon-resize-full');
                $this.children('i').addClass('glyphicon-resize-small');
            }
            else if ($this.children('i').hasClass('glyphicon-resize-small'))
            {
                $this.children('i').removeClass('glyphicon-resize-small');
                $this.children('i').addClass('glyphicon-resize-full');
            }
            $(this).closest('.panel').toggleClass('panel-fullscreen');
        });
    }); 
</script>
<script>
    $(document).ready(function() {
        $('.select2').select2();    

        list_epelaporan();
        list_calon('calon_tunggal'); 
        list_calon('calon_petahana'); 
        list_calon('calon_asn'); 
        list_calon('calon_independent'); 

        v_1 = setInterval( function () {
            list_epelaporan(); 
        }, 10000 ); 
        v_2 = setInterval( function () {
            list_calon('calon_tunggal'); 
        }, 1200000 ); 
        v_3 = setInterval( function () {
            list_calon('calon_petahana'); 
        }, 1200000 ); 
        v_4 = setInterval( function () {
            list_calon('calon_asn'); 
        }, 1200000 ); 
        v_5 = setInterval( function () {
            list_calon('calon_independent'); 
        }, 1200000 ); 

        $.ajax({
            url: '{base_url}/chart_pilgubData',
            type: 'GET',
            async: true,
            dataType: "json",
            success: function (data) {
                chart_pilgubData(data);
            }
        });   

        $.ajax({
            url: '{base_url}/chart_pilkotData',
            type: 'GET',
            async: true,
            dataType: "json",
            success: function (data) {
                chart_pilkotData(data);
            }
        });

        $.ajax({
            url: '{base_url}/chart_pilbupData',
            type: 'GET',
            async: true,
            dataType: "json",
            success: function (data) {
                chart_pilbupData(data);
            }
        });

        $("#nama_wilayah").change(function(event) {
            /* Act on the event */
            $.ajax({
                url: '{base_url}/check_status',
                type: 'GET',
                dataType: 'json',
                data: {id: $("#nama_wilayah").val() },
            })
            .done(function(data) {
                if(data.status==1){
                    document.location.href="main#home/profile/"+$("#nama_wilayah").val();
                }else{
                    swal("Daerah yang anda dipilih tidak menyelenggarakan PILKADA");
                }
            })
            .fail(function() {
                console.log("error");
            });

        });

        AmCharts.makeChart("map",{
            type: "map",
           // colorSteps: 3,
            dataProvider: {
              map: "indonesiaLow",
              getAreasFromMap: true,
              areas: [{
                id: "ID-BT",
                value: 1
              },{
                id: "MY-13",
                color:"#8b8282"
              },{
                id : "MY-12",
                color:"#8b8282"
              },{
                id : "TL",
                color:"#8b8282"
              },{
                id : "BN",
                color:"#8b8282"
              }{data_ikp_provinsi}]
            },
            areasSettings: {
              autoZoom: true,
              color: "#3cff00",
              selectedColor: "#0077ff",
              rollOverOutlineColor : "#0077ff",
              colorSolid : "#cd1c00"
            },
            listeners: [{
            event: "clickMapObject",
            method: function(event) {
                /* Act on the event */
                $.ajax({
                    url: '{base_url}/check_status',
                    type: 'GET',
                    dataType: 'json',
                    data: {id: event.mapObject.id },
                })
                .done(function(data) {
                    if(data.status==1){
                        document.location.href="main#home/profile/"+event.mapObject.id;
                    }else{
                        swal("Daerah yang anda dipilih tidak menyelenggarakan PILKADA");
                    }
                })
                .fail(function() {
                    console.log("error");
                });
            }
          }]
       });

    });
    

    $( function() {

        ///////////////////////////////////////////////////////////
        // tooltips
        $("[data-toggle=tooltip]").tooltip();

        ///////////////////////////////////////////////////////////
        // jquery ui sortable
        $('#left-col, #left-col0, #left-col1, #left-col2, #left-col3, #left-col4, #left-col5, #left-col6, #left-col7, #right-col, #right-col0, #bottom-col, #top-col').each(function(){
            $(this).sortable({
                // connect left and right containers
                connectWith: '.cat__core__sortable',
                tolerance: 'pointer',
                scroll: true,

                // set initial order from localStorage
                create: function () {

                    var that = $(this),
                        id = $(this).attr('id'),
                        orderLs = localStorage.getItem('order-' + id);

                    if (orderLs) {
                        var order = orderLs.split(',');

                        $.each(order, function(key, val){
                            var el = $('[order-id=' + val + ']');
                            that.append(el);
                        });
                    }

                },

                // save order state on order update to localStorage
                update: function () {
                    var orderArray = $(this).sortable('toArray', {attribute: 'order-id'}),
                        prefix = $(this).attr('id');

                    localStorage.setItem('order-' + prefix, orderArray);
                },

                // handler
                handle: ".card-header"
            });
        });

        ///////////////////////////////////////////////////////////
        // reset dashboard
        $('.reset-button').on('click', function(){
            localStorage.removeItem('order-left-col');
            localStorage.removeItem('order-right-col');
            localStorage.removeItem('order-bottom-col');
            setTimeout(function () {
                location.reload();
            }, 500)
        });

        ///////////////////////////////////////////////////////////
        // card controls
        $('.cat__core__sortable__collapse, .cat__core__sortable__uncollapse').on('click', function(){
            $(this).closest('.card').toggleClass('cat__core__sortable__collapsed');
        });
        $('.cat__core__sortable__close').on('click', function(){
            $(this).closest('.card').remove();
            $('.tooltip').remove();
        });

        // header double click
        $('.cat__core__sortable .card-header').on('dblclick', function() {
            $(this).closest('.card').toggleClass('cat__core__sortable__collapsed');
        });

        ///////////////////////////////////////////////////////////
        // custom scroll
        if (!('ontouchstart' in document.documentElement) && jQuery().jScrollPane) {
            $('.custom-scroll').each(function() {
                $(this).jScrollPane({
                    contentWidth: '100%',
                    autoReinitialise: true,
                    autoReinitialiseDelay: 100
                });
                var api = $(this).data('jsp'),
                        throttleTimeout;
                $(window).bind('resize', function() {
                    if (!throttleTimeout) {
                        throttleTimeout = setTimeout(function() {
                            api.reinitialise();
                            throttleTimeout = null;
                        }, 50);
                    }
                });
            });
        }

    } );

    function chart_pilgubData(data) { 
        
        $('#chart_pilgub').highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: null
            },
            legend: {
                    enabled: false
            },
            xAxis: {
                categories: {chart_pilgubCategories},
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: ''
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            credits: {
                enabled: false
            },
            series: [data],
        });    
    }

    function chart_pilkotData(data) { 
        
        $('#chart_walkot').highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: null
            },
            legend: {
                    enabled: false
            },
            xAxis: {
                categories: {chart_pilkotCategories},
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: ''
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            credits: {
                enabled: false
            },
            series: [data],
        });    
    }

    function chart_pilbupData(data) { 
        
        $('#chart_bupati').highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: null
            },
            legend: {
                    enabled: false
            },
            xAxis: {
                categories: {chart_pilbupCategories},
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: ''
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            credits: {
                enabled: false
            },
            series: [data],
        });    
    }

    function list_calon(ini){
    var data_calon ='';
    var nom = 0;
        $.ajax({
            url: '{base_url}/list_calon',
            type: 'POST',
            dataType: 'json',
            data: {tipe: ini},
        })
        .done(function(data) {
            $.each(data, function(index, val) {
                 /* iterate through array or object */
                    if(val.jumlah_total==0 || val.jumlah_total==null){
                        var percen = 0;
                    }else{
                        var percen = (val.jumlah_suara/val.jumlah_total)*100;
                        numeral.defaultFormat('0.00');
                        var number = numeral(percen); 
                        var percen = number.format();
                    }
                nom++;    
                data_calon = data_calon+'<tr>';
                data_calon = data_calon+'<td rowspan="2" style="text-align: center; vertical-align: middle">';
                data_calon = data_calon+'<font size="12">'+val.no_urut+'</font><br>';
                data_calon = data_calon+'<font size="2">'+percen+'%</font>';
                data_calon = data_calon+'</td>';
                data_calon = data_calon+'<td>';
                data_calon = data_calon+'<a href="javascript:void(0);">';                
                data_calon = data_calon+'<img src="'+val.image_1+'" alt="Kepala Daerah" width="40px">';
                data_calon = data_calon+'</a>&nbsp;';
                data_calon = data_calon+'<a href="javascript:void(0);">';
                data_calon = data_calon+'<img src="'+val.image_2+'" alt="Wakil Kepala Daerah" width="40px">';
                data_calon = data_calon+'</a>';
                data_calon = data_calon+'</td>';
                data_calon = data_calon+'<td width="50%">';
                data_calon = data_calon+'<font size="3px">'+val.name+'</font><br>';
                data_calon = data_calon+'<font size="1px">'+val.kepala_daerah+' <br>'+val.wakil_kepala_daerah+'</font>';
                data_calon = data_calon+'</td>';
                data_calon = data_calon+'</tr>';
                data_calon = data_calon+'<tr>';
                data_calon = data_calon+'<td colspan="2">';
                data_calon = data_calon+'<div class="progress mb-2">';
                data_calon = data_calon+'<div class="progress-bar progress-bar-striped progress-bar-animated bg-danger" ';
                data_calon = data_calon+'role="progressbar" ';
                data_calon = data_calon+'style="width: '+percen+'%"';
                data_calon = data_calon+'aria-valuenow="'+percen+'"';
                data_calon = data_calon+'aria-valuemin="0"';
                data_calon = data_calon+'aria-valuemax="100">'+addCommas(val.jumlah_suara)+' Suara';
                data_calon = data_calon+'</div>';
                data_calon = data_calon+'</div>';
                data_calon = data_calon+'</td>';
                data_calon = data_calon+'</tr>';

            });            
        })
        .fail(function() {
            console.log("error");
        })
        .always(function() {
            if(ini=="calon_tunggal"){
                $('#list_calon_tunggal').html(data_calon);
                $("#jml_calon_tunggal").html("<span>Jumlah Calon: "+nom+"</span>");
            }else if (ini=="calon_petahana") {
                $('#list_calon_petahana').html(data_calon);
                $("#jml_calon_petahana").html("<span>Jumlah Calon: "+nom+"</span>");
            }else if (ini=="calon_asn") {
                $('#list_calon_asn').html(data_calon);
                $("#jml_calon_asn").html("<span>Jumlah Calon: "+nom+"</span>");
            }else if (ini=="calon_independent") {
                $('#list_calon_independent').html(data_calon);
                $("#jml_calon_independent").html("<span>Jumlah Calon: "+nom+"</span>");
            }
            //console.log("complete");
        });

    }

    function list_epelaporan(){
    
    var max_id      = $("#no_laporan").val();
    var start_data  = $("#data_epelaporan").val();
    var append_data = "";
        $.ajax({
            url: '{base_url}/epelaporan',
            type: 'GET',
            dataType: 'json',
            data: {id: max_id},
        })
        .done(function(data) {
            $.each(data, function(index, val) {
                 /* iterate through array or object */
                append_data ='<div class="cat__apps__chat-block">';
                append_data = append_data+'<div class="cat__apps__chat-block__item clearfix">';
                append_data = append_data+'<div class="cat__apps__chat-block__avatar">';
                append_data = append_data+'<a class="cat__core__avatar" href="javascript:void(0);">';
                append_data = append_data+'<img src="{base}assets/img/warning_image.png" alt="Alternative text to the image">';
                append_data = append_data+'</a>';
                append_data = append_data+'</div>';
                append_data = append_data+'<div class="cat__apps__chat-block__content">';
                append_data = append_data+'<strong>'+val.id_pelapor+'</strong>'; 
                append_data = append_data+'<p class="read-more-wrap">'+val.judul+'. ';
                append_data = append_data+'<span class="read-more-target">'+val.keterangan+'.</span>';
                if(val.img_laporan!=''|| val.img_laporan!=null){
                    append_data = append_data+'<br><img class="cat__apps__profile__wall__message-img" src="{base}assets/img/laporan/'+val.img_laporan+'">';
                }
                append_data = append_data+'</p>';
                append_data = append_data+'</div>';
                append_data = append_data+'</div>';
                append_data = append_data+'</div>';

                $("#no_laporan").val(val.nomor_laporan);           
            });
        })
        .fail(function() {
            console.log("error");
        })
        .always(function() {
            $(".cat__apps__chat-block").before(append_data);
            $('.read-more-wrap').shorten({
                moreText: 'read more',
                lessText: 'read less',
                showChars: 20,
            });
            console.log("complete");
        });
        
    }

    function addCommas(nStr) {

        nStr += '';
        var x = nStr.split('.');
        var x1 = x[0];
        var x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        return x1 + x2;
    }

    function compress_image(kode_wilayah,img_kd){
          $.ajax({
                url: '{base_url}/com_fileproject',
                type: 'POST',
                dataType: 'json',
                data: {kode_wilayah: kode_wilayah, img_kd: img_kd},
                success:function(data) {
                  //console.log(data); 
                }
          });
    }

    function doesFileExist(urlToFile) {
        var xhr = new XMLHttpRequest();
        xhr.open('HEAD', urlToFile, false);
        xhr.send();
        
        if (xhr.status == "404") {
            return false;
        } else {
            return true;
        }
    }
</script>
<!-- END: page scripts -->