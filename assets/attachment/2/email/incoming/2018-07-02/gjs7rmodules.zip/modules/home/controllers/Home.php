<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index(){
		
			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
			
			$userid 		= $this->session->userdata('userid');
			$userlevel 		= $this->session->userdata('userlevel');
			$group_member	= $this->session->userdata('group_member');

			$this->load->model('m_home');

			$list_pilkada 		= $this->m_home->list_pilkada();
			$data_ikp_provinsi 	= $this->m_home->data_ikp_provinsi();

			$this->load->library('page_render');

			$data1 	= $this->m_home->chart_pilgubData();
			$data2 	= $this->m_home->chart_pilkotData();
			$data3  = $this->m_home->chart_pilbupData();

			$chart_pilgubCategories =  '[';
			foreach ($data1 as $key => $value) {
				# code...
				$chart_pilgubCategories .= '"'.$value['name'].'",';
			}

			$chart_pilkotCategories =  '[';
			foreach ($data2 as $key => $value) {
				# code...
				$chart_pilkotCategories .= '"'.$value['name'].'",';
			}

			$chart_pilbupCategories =  '[';
			foreach ($data3 as $key => $value) {
				# code...
				$chart_pilbupCategories .= '"'.$value['name'].'",';
			}

			$chart_pilgubCategories =substr($chart_pilgubCategories, 0, -1).']';
			$chart_pilkotCategories =substr($chart_pilkotCategories, 0, -1).']';
			$chart_pilbupCategories =substr($chart_pilbupCategories, 0, -1).']';
		
			$data=array(
				'page_content' 				=> $page,
				'base_url'					=> base_url().$page,
				'base'						=> base_url(),
				"new"						=> '0',
				"assigned"					=> '0',
				"inprogress"				=> '0',
				"pending"					=> '0',
				"resolved"					=> '0',
				"closed"					=> '0',
				"cancelled"					=> '0',
				"total"						=> '0',
				"list_pilkada"				=> $list_pilkada,
				"data_ikp_provinsi"			=> $data_ikp_provinsi,
				"chart_pilgubCategories"	=> $chart_pilgubCategories,
				"chart_pilkotCategories"	=> $chart_pilkotCategories,
				"chart_pilbupCategories"	=> $chart_pilbupCategories
			);

			$this->parser->parse('master/content', $data);
	}

	public function profile(){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
			
			$id 			= $this->uri->segment(3);
			$leng_id 		= strlen($id);

			$this->load->model('m_home');

			$check_area_pilkada  = $this->m_home->check_area_pilkada($id,$leng_id);

			$bar_chart			 = $this->m_home->bar_chart_ikp($check_area_pilkada);

			$pie_chart			 = $this->m_home->pie_chart_hasil($check_area_pilkada);

			$data_wilayah 		 = $this->m_home->data_wilayah($id,$leng_id);
			
			$ikp = number_format(($check_area_pilkada['ikp_partisipasi']+$check_area_pilkada['ikp_konstetasi']+$check_area_pilkada['ikp_penyelenggaraan'])/3,2,'.','');
			if($ikp<2.00){
				$clr_ikp ="28d109";
			}elseif($ikp<3.00){
				$clr_ikp ="ff5e00";
			}else{
				$clr_ikp ="d11509";
			}
			$this->load->library('page_render');
			if($leng_id=="2"){
				$jumlah_wil = $this->m_home->data_jumlah_wilayah($id);
			}else{
				$jumlah_wil = $this->m_home->data_jumlah_wilayah_kab($id);
			}
			
			
			$data=array(
				'page_content' 				=> 'profile',
				'base'						=> base_url(),
				'base_url'					=> base_url().$page,
				'kode_wilayah'				=> $id,
				'first_name'				=> $this->session->userdata('first_name'),
				'last_name'					=> $this->session->userdata('last_name'),
				'email'						=> $this->session->userdata('email'),
				'userlevel'					=> $this->session->userdata('userlevel'),
				'position'					=> $this->session->userdata('position'),
				"tenant_id"					=> $this->session->userdata('tenant_id'),
				"id_img"					=> $check_area_pilkada['id'],
				"name"						=> strtoupper($check_area_pilkada['name']),
				"name_small"				=> $check_area_pilkada['name'],
				"bar_chart"					=> $bar_chart,
				"pie_chart"					=> $pie_chart,
				"ikp"						=> $ikp,
				"clr_ikp"					=> $clr_ikp,
				"jumlah_penduduk"			=> number_format($data_wilayah['sum_citizen']),
				"jumlah_dpt"				=> number_format($data_wilayah['sum_man']+$data_wilayah['sum_woman']),
				"jumlah_tps"				=> number_format($data_wilayah['sum_tps']),
				"jumlah_asn"				=> number_format($data_wilayah['sum_asn']),
				"kab"						=> number_format($jumlah_wil[0]['kabupaten']),
				"kota"						=> number_format($jumlah_wil[0]['kota']),
				"kec"						=> number_format($jumlah_wil[0]['kec']),
				"desa"						=> number_format($jumlah_wil[0]['desa']),
			);

			$this->parser->parse('master/content', $data);
	}

	public function check_status(){

		$id 	= 	$this->input->get('id');
		$leng_id= strlen($id);

		$this->load->model('m_home');

		$check_status = $this->m_home->check_status_pilkada($id,$leng_id);

		echo json_encode($check_status);
	}

	public function list_calon(){

		$tipe = $this->input->post('tipe');

		$this->load->model('m_home');

		$data = $this->m_home->list_calon($tipe);

		echo json_encode($data);
	}

	public function check_hasil_pilkada(){

		$id = $this->input->post('id');

		$this->load->model('m_home');

		$data = $this->m_home->check_hasil_pilkada($id);

		echo json_encode($data);
	}

	public function chart_pilgubData(){
		
		$this->load->model('m_home');

		$data 	= $this->m_home->chart_pilgubData();

		$series =  '{"name": "Tahun 2018","data": [';
		foreach ($data as $key => $value) {
			# code...
			$series .= '{"y": '.$value['perc'].'},';
		}

			$series =substr($series, 0, -1).']}';
		
		echo $series;
	}

	public function chart_pilkotData(){
		
		$this->load->model('m_home');

		$data 	= $this->m_home->chart_pilkotData();

		$series =  '{"name": "Tahun 2018","data": [';
		foreach ($data as $key => $value) {
			# code...
			$series .= '{"y": '.$value['perc'].'},';
		}

			$series =substr($series, 0, -1).']}';
		
		echo $series;
	}

	public function chart_pilbupData(){
		
		$this->load->model('m_home');

		$data 	= $this->m_home->chart_pilbupData();

		$series =  '{"name": "Tahun 2018","data": [';
		foreach ($data as $key => $value) {
			# code...
			$series .= '{"y": '.$value['perc'].'},';
		}

			$series =substr($series, 0, -1).']}';
		
		echo $series;
	}

	public function epelaporan(){

		$id = $this->input->get('id');

		$this->load->model('m_home');

		$data = $this->m_home->epelaporan($id);

		echo json_encode($data);

	}

	public function test_kompress(){

		$this->load->model('m_home');

		$data = $this->m_home->test_kompress();

		echo json_encode($data);

	}

	public function logout(){

		$this->session->sess_destroy();

		redirect('login');
	}
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */
