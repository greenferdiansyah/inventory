<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <span class="text-muted">Rekapitulasi Hasil Pilkada ·</span>
        <strong>Berdasarkan Partai Pengusung</strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-block">
        <div class="row">
            <div class="col-lg-6">
                <div class="mb-5">
                    <div class="form-group row">
                            <label class="col-md-3 col-form-label" for="l0">Periode Pilkada</label>
                            <div class="col-md-6">
                                <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="periode" 
                                            name="periode">
                                        <option value="">Pilih Periode</option>
                                       {list_periode}
                                </select>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Rekapitulasi Hasil Berdasarkan Partai Pengusung </strong>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-striped table-bordered table-condensed display select" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th rowspan="2" style="text-align: center; vertical-align: middle; width: 21px;">No</th>
                            <th rowspan="2" style="text-align: center; vertical-align: middle; width: 21px;">Partai</th>
                            <th rowspan="1" colspan="3" style="text-align: center; vertical-align: middle" >Calon</th>
                            <th rowspan="2" style="text-align: center; vertical-align: middle" >Total</th>
                        </tr>
                        <tr>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">Gubernur</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">Bupati</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">Walikota</th>
                        </thead>
                        <tfoot>
                            <tr>
                                <th colspan="2" style="text-align:right">Total:</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                        </tfoot>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END: tables/datatables -->
<!-- START: page scripts -->
<script src="assets/js/numeral.min.js"></script>
<script>

    jQuery(document).ready(function($) {
        $('.select2').select2();

        $("#periode").change(function(event) {
            /* Act on the event */
            var vanza = $("#periode").val();
            
            if(vanza==''){
                $('#data-table').empty(); 
            }else if (vanza!=''){
                cari_data(vanza); 
            }
            
        });
    });

    function cari_data(vanza){
     var baseUrl = '{base_url}';  
     var table =   
     $('#data-table').DataTable({
            lengthChange: false,
            processing: true,
            searching: false,
            destroy:true,
            serverSide: true,
            responsive: true,
            autoFill: true,
            colReorder: true,
            keys: true,
            rowReorder: true,
            pageLength : 50,
            "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                switch (aData[8]) {
                    case 'Done':
                        $(nRow).addClass('success')
                        break;
                }
            },
            columnDefs: [
                { "width": "2%", "targets": 0 },
                { "width": "15%", "targets": 1 },
                { className: "text-center col-with-icon", "targets": [ 2 ] },
                { className: "text-center col-with-icon", "targets": [ 3 ] },
                { className: "text-center col-with-icon", "targets": [ 4 ] },
                { className: "text-center col-with-icon", "targets": [ 5 ] }
            ],
            ajax: {
                url: baseUrl+"/json_list/"+vanza,
                type:'POST',
            },
            "footerCallback": function(row, data, start, end, display) {
                var api = this.api(),
                    data;

                // Remove the formatting to get integer data for summation
                var intVal = function(i) {
                    return typeof i === 'string' ?
                        i.replace(/[\$,]/g, '') * 1 :
                        typeof i === 'number' ?
                        i : 0;
                };

                // Total over this page
                total1 = api
                    .column(2, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total2 = api
                    .column(3, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total3 = api
                    .column(4, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total4 = api
                    .column(5, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);                          

                var number = numeral(total1);
                var number2 = numeral(total2);
                var number3 = numeral(total3);
                var number4 = numeral(total4);

                number.format();
                number2.format();
                number3.format();
                number4.format();
                // '1,000'
                numeral.defaultFormat('0,0');

                // Update footer
                $(api.column(2).footer()).html(
                    ' ' + number.format() + ' '
                );
                $(api.column(3).footer()).html(
                    ' ' + number2.format() + ' '
                );
                $(api.column(4).footer()).html(
                    ' ' + number3.format() + ' '
                );
                $(api.column(5).footer()).html(
                    ' ' + number4.format() + ' '
                );
            }
    });

    }
</script>
<!-- END: page scripts -->