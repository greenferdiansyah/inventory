<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_dpt_provinces extends CI_Controller {

	public function index(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
				
			$this->load->library('page_render');
			$this->load->library('drop_down');
			
			$this->drop_down->select('province_id','name');
			$this->drop_down->from('m_area_provinces');
			$this->drop_down->where('is_deleted="0"');
			$list_provinces = $this->drop_down->build(null);

			$data=array(
				'page_content' 				=> $page,
				'base_url'					=> base_url().$page,
				"tenant_id"					=> $this->session->userdata('tenant_id'),
				'list_provinces'			=> $list_provinces
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list(){
			
			$parent_page	=  $this->uri->segment(1);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_dpt');
			
			$data =  $this->m_page_dpt->list_data($length,$start,$search,$order,$dir);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				$iconAction = "<a href='main#".$parent_page."/view_regency/".base64_encode($this->encryption->encrypt($row['id_provinces']))."' data-toggle='tooltip' title='View Details Area' aria-expanded='false'>
			                    ".$row['name']."
			                  </a>";
			    $iconActionx = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-primary btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['id_provinces']."')>
								<i class='icmn-pencil'></i>
							  </a>";

				$output['data'][]=array(
					$nomor_urut, 
					$iconAction, 
					number_format($row['sum_tps']),
					number_format($row['sum_man']),
					number_format($row['sum_woman']),
					number_format($row['sum_gender']),
					number_format($row['dif_1']),
					number_format($row['dif_2']),
					number_format($row['dif_3']),
					number_format($row['dif_4']),
					number_format($row['dif_5']),
					number_format($row['sum_dif']),
					$iconActionx,
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function detail_data(){

		if($this->session->userdata('is_logged_in') == true){
			
		$id 		= $this->input->post('id');

		$this->load->model('m_page_dpt');

		$data =  $this->m_page_dpt->detail_data($id);


		echo json_encode($data);

		}else{
			exit();
		}

	}


	public function forms_submit(){

		if($this->session->userdata('is_logged_in') == true){

			$act 				= $this->input->post('act');
			$id					= $this->input->post('id');
			$id_provinces		= $this->input->post('id_provinces');
			$periode			= $this->input->post('periode');
			$sum_citizen		= str_replace('.', '', $this->input->post('sum_citizen'));
			$sum_asn 			= str_replace('.', '', $this->input->post('sum_asn'));
			$sum_tps 			= str_replace('.', '', $this->input->post('sum_tps'));
			$sum_man 			= str_replace('.', '', $this->input->post('sum_man'));
			$sum_woman 			= str_replace('.', '', $this->input->post('sum_woman'));
			$dif_1 				= str_replace('.', '', $this->input->post('dif_1'));
			$dif_2 				= str_replace('.', '', $this->input->post('dif_2'));
			$dif_3 				= str_replace('.', '', $this->input->post('dif_3'));
			$dif_4 				= str_replace('.', '', $this->input->post('dif_4'));
			$dif_5 				= str_replace('.', '', $this->input->post('dif_5'));

			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');
	
			$this->load->model('m_page_dpt');

			if($act=="Edit"){

					$submit = $this->m_page_dpt->edit($act,$id,$id_provinces,$periode,$sum_citizen,$sum_asn,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup);

					if($submit['status']){
						$statusResp=true;
						$reason="Update Data Successfully...!";
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}

			}else{
				
					$submit = $this->m_page_dpt->add($act,$id_provinces,$periode,$sum_citizen,$sum_asn,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup);
					
					if($submit['status']){
						$statusResp=true;
						$reason=$submit['reason'];
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}					
			}

			echo json_encode(array("status"=>$statusResp, "reason"=>$reason));

		}else{
			exit();
		}

	}

	public function view_regency(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
			$page_content	=  $this->uri->segment(2);

			$this->load->library('encryption');
			$id_provinces = $this->encryption->decrypt(base64_decode($this->uri->segment(3)));

			$this->load->model('m_page_dpt');

			$province_name = $this->m_page_dpt->find_province_name($id_provinces);

			$this->load->library('page_render');
			$this->load->library('drop_down');
			
			$this->drop_down->select('regency_id','name');
			$this->drop_down->from('m_area_regencies');
			$this->drop_down->where('is_deleted="0" AND province_id='.$id_provinces.'');
			$list_regency = $this->drop_down->build(null);

			$data=array(
				'page_content' 				=> $page.'_'.$page_content,
				'base_url'					=> base_url().$page,
				'id_provinces'				=> $id_provinces,
				'province_name'				=> $province_name,
				"tenant_id"					=> $this->session->userdata('tenant_id'),
				"list_regency"				=> $list_regency
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list_regency(){
			
			$parent_page	=  $this->uri->segment(1);

			$this->load->library('encryption');
			$find_id		=  $this->uri->segment(3);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_dpt');
			
			$data =  $this->m_page_dpt->list_data_regency($length,$start,$search,$order,$dir,$find_id);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				$iconAction = "<a href='main#".$parent_page."/view_district/".base64_encode($this->encryption->encrypt($row['id_regencies']))."' data-toggle='tooltip' title='View Details Area' aria-expanded='false'>
			                    ".$row['name']."
			                  </a>";
			    $iconActionx = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-primary btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['id_regencies']."')>
								<i class='icmn-pencil'></i>
							  </a>";

				$output['data'][]=array(
					$nomor_urut, 
					$iconAction, 
					number_format($row['sum_tps']),
					number_format($row['sum_man']),
					number_format($row['sum_woman']),
					number_format($row['sum_gender']),
					number_format($row['dif_1']),
					number_format($row['dif_2']),
					number_format($row['dif_3']),
					number_format($row['dif_4']),
					number_format($row['dif_5']),
					number_format($row['sum_dif']),
					$iconActionx
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function detail_data_regency(){

		if($this->session->userdata('is_logged_in') == true){
			
		$id 		= $this->input->post('id');

		$this->load->model('m_page_dpt');

		$data =  $this->m_page_dpt->detail_data_regency($id);


		echo json_encode($data);

		}else{
			exit();
		}

	}

	public function forms_submit_regency(){

		if($this->session->userdata('is_logged_in') == true){

			$act 				= $this->input->post('act');
			$id					= $this->input->post('id');
			$id_regencies		= $this->input->post('id_regencies');
			$periode			= $this->input->post('periode');
			$sum_citizen		= str_replace('.', '', $this->input->post('sum_citizen'));
			$sum_asn 			= str_replace('.', '', $this->input->post('sum_asn'));
			$sum_tps 			= $this->input->post('sum_tps');
			$sum_man 			= $this->input->post('sum_man');
			$sum_woman 			= $this->input->post('sum_woman');
			$dif_1 				= $this->input->post('dif_1');
			$dif_2 				= $this->input->post('dif_2');
			$dif_3 				= $this->input->post('dif_3');
			$dif_4 				= $this->input->post('dif_4');
			$dif_5 				= $this->input->post('dif_5');

			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');
	
			$this->load->model('m_page_dpt');

			if($act=="Edit"){

					$submit = $this->m_page_dpt->edit_dpt_regency($act,$id,$id_regencies,$periode,$sum_citizen,$sum_asn,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup);

					if($submit['status']){
						$statusResp=true;
						$reason="Update Data Successfully...!";
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}

			}else{
				
					$submit = $this->m_page_dpt->add_dpt_regency($act,$id_regencies,$periode,$sum_citizen,$sum_asn,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup);
					
					if($submit['status']){
						$statusResp=true;
						$reason=$submit['reason'];
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}					
			}

			echo json_encode(array("status"=>$statusResp, "reason"=>$reason));

		}else{
			exit();
		}

	}

	public function view_district(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
			$page_content	=  $this->uri->segment(2);

			$this->load->library('encryption');
			$id_regency = $this->encryption->decrypt(base64_decode($this->uri->segment(3)));

			$this->load->model('m_page_dpt');

			$regency_name = $this->m_page_dpt->find_regency_name($id_regency);

			$this->load->library('page_render');
			$this->load->library('drop_down');
			
			$this->drop_down->select('district_id','name');
			$this->drop_down->from('m_area_districts');
			$this->drop_down->where('is_deleted="0" AND regency_id='.$id_regency.'');
			$list_district = $this->drop_down->build(null);

			$data=array(
				'page_content' 				=> $page.'_'.$page_content,
				'base_url'					=> base_url().$page,
				'id_regency'				=> $id_regency,
				'province_name'				=> $regency_name[0]['province'],
				'regency_name'				=> $regency_name[0]['regency'],
				"tenant_id"					=> $this->session->userdata('tenant_id'),
				"list_district"				=> $list_district
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list_district(){
			
			$parent_page	=  $this->uri->segment(1);

			$this->load->library('encryption');
			$find_id		=  $this->uri->segment(3);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_dpt');
			
			$data =  $this->m_page_dpt->list_data_district($length,$start,$search,$order,$dir,$find_id);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				$iconAction = "<a href='main#".$parent_page."/view_villages/".base64_encode($this->encryption->encrypt($row['id_district']))."' data-toggle='tooltip' title='View Details Area' aria-expanded='false'>
			                    ".$row['name']."
			                  </a>";
			    $iconActionx = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-primary btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['id_district']."')>
								<i class='icmn-pencil'></i>
							  </a>";

				$output['data'][]=array(
					$nomor_urut, 
					$iconAction, 
					number_format($row['sum_tps']),
					number_format($row['sum_man']),
					number_format($row['sum_woman']),
					number_format($row['sum_gender']),
					number_format($row['dif_1']),
					number_format($row['dif_2']),
					number_format($row['dif_3']),
					number_format($row['dif_4']),
					number_format($row['dif_5']),
					number_format($row['sum_dif']),
					$iconActionx
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function detail_data_district(){

		if($this->session->userdata('is_logged_in') == true){
			
		$id 		= $this->input->post('id');

		$this->load->model('m_page_dpt');

		$data =  $this->m_page_dpt->detail_data_district($id);


		echo json_encode($data);

		}else{
			exit();
		}

	}

	public function forms_submit_district(){

		if($this->session->userdata('is_logged_in') == true){

			$act 				= $this->input->post('act');
			$id					= $this->input->post('id');
			$id_district		= $this->input->post('id_district');
			$periode			= $this->input->post('periode');
			$sum_tps 			= $this->input->post('sum_tps');
			$sum_man 			= $this->input->post('sum_man');
			$sum_woman 			= $this->input->post('sum_woman');
			$dif_1 				= $this->input->post('dif_1');
			$dif_2 				= $this->input->post('dif_2');
			$dif_3 				= $this->input->post('dif_3');
			$dif_4 				= $this->input->post('dif_4');
			$dif_5 				= $this->input->post('dif_5');

			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');
	
			$this->load->model('m_page_dpt');

			if($act=="Edit"){

					$submit = $this->m_page_dpt->edit_dpt_district($act,$id,$id_district,$periode,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup);

					if($submit['status']){
						$statusResp=true;
						$reason="Update Data Successfully...!";
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}

			}else{
				
					$submit = $this->m_page_dpt->add_dpt_district($act,$id_district,$periode,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup);
					
					if($submit['status']){
						$statusResp=true;
						$reason=$submit['reason'];
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}					
			}

			echo json_encode(array("status"=>$statusResp, "reason"=>$reason));

		}else{
			exit();
		}

	}

	public function view_villages(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
			$page_content	=  $this->uri->segment(2);

			$this->load->library('encryption');
			$id_district = $this->encryption->decrypt(base64_decode($this->uri->segment(3)));

			$this->load->model('m_page_dpt');

			$district_name = $this->m_page_dpt->find_district_name($id_district);

			$this->load->library('page_render');
			$this->load->library('drop_down');
			
			$this->drop_down->select('village_id','name');
			$this->drop_down->from('m_area_villages');
			$this->drop_down->where('is_deleted="0" AND district_id='.$id_district.'');
			$list_villages = $this->drop_down->build(null);

			$data=array(
				'page_content' 				=> $page.'_'.$page_content,
				'base_url'					=> base_url().$page,
				'id_district'				=> $id_district,
				'province_name'				=> $district_name[0]['province'],
				'regency_name'				=> $district_name[0]['regency'],
				'district'					=> $district_name[0]['district'],
				"tenant_id"					=> $this->session->userdata('tenant_id'),
				"list_villages"				=> $list_villages
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list_villages(){
			
			$parent_page	=  $this->uri->segment(1);

			$this->load->library('encryption');
			$find_id		=  $this->uri->segment(3);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_dpt');
			
			$data =  $this->m_page_dpt->list_data_villages($length,$start,$search,$order,$dir,$find_id);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				/*$iconAction = "<a href='main#".$parent_page."/view_villages/".base64_encode($this->encryption->encrypt($row['id_district']))."' data-toggle='tooltip' title='View Details Area' aria-expanded='false'>
			                    ".$row['name']."
			                  </a>";*/
			     $iconActionx = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-primary btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['id_villages']."')>
								<i class='icmn-pencil'></i>
							  </a>";             
				$output['data'][]=array(
					$nomor_urut, 
					$row['name'], 
					number_format($row['sum_tps']),
					number_format($row['sum_man']),
					number_format($row['sum_woman']),
					number_format($row['sum_gender']),
					number_format($row['dif_1']),
					number_format($row['dif_2']),
					number_format($row['dif_3']),
					number_format($row['dif_4']),
					number_format($row['dif_5']),
					number_format($row['sum_dif']),
					$iconActionx
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function detail_data_villages(){

		if($this->session->userdata('is_logged_in') == true){
			
		$id 		= $this->input->post('id');

		$this->load->model('m_page_dpt');

		$data =  $this->m_page_dpt->detail_data_villages($id);


		echo json_encode($data);

		}else{
			exit();
		}

	}

	public function forms_submit_villages(){

		if($this->session->userdata('is_logged_in') == true){

			$act 				= $this->input->post('act');
			$id					= $this->input->post('id');
			$id_villages		= $this->input->post('id_villages');
			$periode			= $this->input->post('periode');
			$sum_tps 			= $this->input->post('sum_tps');
			$sum_man 			= $this->input->post('sum_man');
			$sum_woman 			= $this->input->post('sum_woman');
			$dif_1 				= $this->input->post('dif_1');
			$dif_2 				= $this->input->post('dif_2');
			$dif_3 				= $this->input->post('dif_3');
			$dif_4 				= $this->input->post('dif_4');
			$dif_5 				= $this->input->post('dif_5');

			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');
	
			$this->load->model('m_page_dpt');

			if($act=="Edit"){

					$submit = $this->m_page_dpt->edit_dpt_villages($act,$id,$id_villages,$periode,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup);

					if($submit['status']){
						$statusResp=true;
						$reason="Update Data Successfully...!";
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}

			}else{
				
					$submit = $this->m_page_dpt->add_dpt_villages($act,$id_villages,$periode,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup);
					
					if($submit['status']){
						$statusResp=true;
						$reason=$submit['reason'];
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}					
			}

			echo json_encode(array("status"=>$statusResp, "reason"=>$reason));

		}else{
			exit();
		}

	}

}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
