<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_villages extends CI_Controller {

	public function index(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
				
			$this->load->library('page_render');
			$this->load->library('drop_down');

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="status_kesertaan"');
			$list_status = $this->drop_down->build(null);

			$this->drop_down->select('district_id','name');
			$this->drop_down->from('m_area_districts');
			$this->drop_down->where('is_deleted="0"');
			$list_district = $this->drop_down->build(null);

			$this->drop_down->select('regency_id','name');
			$this->drop_down->from('m_area_regencies');
			$this->drop_down->where('is_deleted="0"');
			$list_regency = $this->drop_down->build(null);

			$this->drop_down->select('province_id','name');
			$this->drop_down->from('m_area_provinces');
			$this->drop_down->where('is_deleted="0"');
			$list_provinces = $this->drop_down->build(null);

			$data=array(
				'page_content' 				=> $page,
				'base_url'					=> base_url().$page,
				'list_status'				=> $list_status,
				'list_provinces'			=> $list_provinces,
				'list_regency'				=> $list_regency,
				'list_district'				=> $list_district
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}


	public function json_list(){
			
			$parent_page	=  $this->uri->segment(1);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_admin_villages');
			
			$data =  $this->m_admin_villages->list_data($length,$start,$search,$order,$dir);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
                $iconAction = "";    

				$iconAction = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-primary btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['village_id']."')>
								<i class='icmn-pencil'></i>
							  </a>
							  <a onclick=del('".$row['village_id']."') class='btn btn-icon btn-danger btn-rounded mr-2 mb-2' data-toggle='tooltip' title='Deleted' aria-expanded='false'>
			                    <i class='icmn-bin2'></i>
			                  </a>";
				$output['data'][]=array(
					$nomor_urut, 
					$row['village_id'], 
					$row['provinsi'], 
					$row['kota_kab'],
					$row['kecamatan'],
					$row['desa'],
					$iconAction
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function detail_data(){

		if($this->session->userdata('is_logged_in') == true){
			
		$id 		= $this->input->post('id');

		$this->load->model('m_admin_villages');

		$data =  $this->m_admin_villages->detail_data($id);


		echo json_encode($data);

		}else{
			exit();
		}

	}


	public function forms_submit(){

		if($this->session->userdata('is_logged_in') == true){

			$act 				= $this->input->post('act');
			$id 				= $this->input->post('kode_wil');
			$province_id		= $this->input->post('province_id');
			$regency_id 		= $this->input->post('regency_id');
			$district_id 		= $this->input->post('district_id');
			$nama_wilayah		= $this->input->post('nama_wilayah');

			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');
	
			$this->load->model('m_admin_villages');

			if($act=="Edit"){

					$submit = $this->m_admin_villages->edit($act,$id,$province_id,$regency_id,$district_id,$nama_wilayah,$upd,$lup);

					if($submit['status']){
						$statusResp=true;
						$reason="Update Data Successfully...!";
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}

			}else{
				
					$submit = $this->m_admin_villages->add($act,$id,$province_id,$regency_id,$district_id,$nama_wilayah,$upd,$lup);

					
					if($submit['status']){
						$statusResp=true;
						$reason=$submit['reason'];
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}					
			}

			echo json_encode(array("status"=>$statusResp, "reason"=>$reason));

		}else{
			exit();
		}

	}

	public function del_item(){

		if($this->session->userdata('is_logged_in') == true){

			$id 	= $this->input->post('id');
			$status = $this->input->post('status');
			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');

			$this->load->model('m_admin_villages');

			$deleted_item = $this->m_admin_villages->deleted_item($id,$status,$upd,$lup);

			echo json_encode($deleted_item);

		}else{
			exit();
		}
	}


	public function find_regency(){

		if($this->session->userdata('is_logged_in')){

			$page			= $this->uri->segment(1);

			$province_id	= $this->input->post('province_id');
			$q				= $this->input->post('q');
			$data = array();
			
				$this->load->model('m_admin_villages');

				$data = $this->m_admin_villages->find_regency($q,$province_id);
				
				if(is_array($data)){
					foreach($data as $key => $val ){	
						
						$result[] =  array('id' => $val['regency_id'], 'text'=> $val['name'] );
					}
				}else{
					$result = array();
				}

				echo json_encode($result);
	
		}else{
			exit();
		}
	}


	public function find_district(){

		if($this->session->userdata('is_logged_in')){

			$page			= $this->uri->segment(1);

			$regency_id		= $this->input->post('regency_id');
			$q				= $this->input->post('q');
			$data = array();
			
				$this->load->model('m_admin_villages');

				$data = $this->m_admin_villages->find_district($q,$regency_id);
				
				if(is_array($data)){
					foreach($data as $key => $val ){	
						
						$result[] =  array('id' => $val['district_id'], 'text'=> $val['name'] );
					}
				}else{
					$result = array();
				}

				echo json_encode($result);
	
		}else{
			exit();
		}
	}

}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
