<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_admin_provinces extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY province_id";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (`province_id` like '%$search%' OR `name` like '%$search%' OR `ikp_partisipasi` like '%$search%'

			OR `ikp_konstetasi` like '%$search%' OR `ikp_penyelenggaraan` like '%$search%' )";
		}

		$sql		= " SELECT province_id,`name`,`status`,ikp_partisipasi,ikp_konstetasi,ikp_penyelenggaraan
						FROM m_area_provinces
						WHERE is_deleted=0
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	function detail_data($id){
		$this->db->query("SET sql_mode=''");
		$this->db->select('province_id, name, status, ikp_partisipasi, ikp_konstetasi, ikp_penyelenggaraan');
		$query = $this->db->get_where('m_area_provinces', array('province_id' => $id));

		$data = $query->result_array();
		
		return $data[0];

	}

	function update_status($id,$status,$upd,$lup){

		$data = array('status' => $status,
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('province_id', $id );

		$update	= $this->db->update('m_area_provinces', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}

	function deleted_item($id,$status,$upd,$lup){

		$data = array('is_deleted' => '1',
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('province_id', $id );

		$update	= $this->db->update('m_area_provinces', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been deleted');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Deleted Data');
		}

		return $result;

	}


	function add($act,$id,$nama_wilayah,$ikp_partisipasi,$ikp_konstetasi,
						$ikp_penyelenggaraan,$status,$upd,$lup){

		$data = array(
		   'province_id' => $id,	
		   'name' => $nama_wilayah,
		   'ikp_partisipasi' => $ikp_partisipasi,
		   'ikp_konstetasi' => $ikp_konstetasi,
		   'ikp_penyelenggaraan' => $ikp_penyelenggaraan,
		   'status' => $status,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('m_area_provinces', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit($act,$id,$nama_wilayah,$ikp_partisipasi,$ikp_konstetasi,
						$ikp_penyelenggaraan,$status,$upd,$lup){
		
		$data = array('name' => $nama_wilayah,
					  'ikp_partisipasi' => $ikp_partisipasi,
					  'ikp_konstetasi' => $ikp_konstetasi,
					  'ikp_penyelenggaraan' => $ikp_penyelenggaraan,
					  'status' => $status,
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('province_id', $id );

		$update	= $this->db->update('m_area_provinces', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}

}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
