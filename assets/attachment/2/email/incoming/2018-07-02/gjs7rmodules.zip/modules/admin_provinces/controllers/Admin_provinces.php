<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_provinces extends CI_Controller {

	public function index(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
				
			$this->load->library('page_render');
			$this->load->library('drop_down');

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="status_kesertaan"');
			$list_status = $this->drop_down->build(null);

			$data=array(
				'page_content' 				=> $page,
				'base_url'					=> base_url().$page,
				'list_status'				=> $list_status,
				"tenant_id"					=> $this->session->userdata('tenant_id')
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}


	public function json_list(){
			
			$parent_page	=  $this->uri->segment(1);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_admin_provinces');
			
			$data =  $this->m_admin_provinces->list_data($length,$start,$search,$order,$dir);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				$id = $row['province_id'];

				if($row['status'] == '1'){
					$iconStatus = "<input type='checkbox' data-render='switchery' id=$id onclick='change_status($id)' class='form-check-input' checked />";
				}else{
					$iconStatus = "<input type='checkbox' data-render='switchery' id=$id onclick='change_status($id)' class='form-check-input' />";
				}
				
                $iconAction = "";    

				$iconAction = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-primary btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['province_id']."')>
								<i class='icmn-pencil'></i>
							  </a>
							  <a onclick=del('".$row['province_id']."') id=$id class='btn btn-icon btn-danger btn-rounded mr-2 mb-2' data-toggle='tooltip' title='Deleted' aria-expanded='false'>
			                    <i class='icmn-bin2'></i>
			                  </a>";
				$output['data'][]=array(
					$nomor_urut, 
					$row['province_id'], 
					$row['name'],
					$iconStatus,
					$iconAction
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function detail_data(){

		if($this->session->userdata('is_logged_in') == true){
			
		$id 		= $this->input->post('id');

		$this->load->model('m_admin_provinces');

		$data =  $this->m_admin_provinces->detail_data($id);


		echo json_encode($data);

		}else{
			exit();
		}

	}


	public function forms_submit(){

		if($this->session->userdata('is_logged_in') == true){

			$act 				= $this->input->post('act');
			$id 				= $this->input->post('kode_wil');
			$nama_wilayah		= $this->input->post('nama_wilayah');
			$ikp_partisipasi	= $this->input->post('ikp_partisipasi');
			$ikp_konstetasi		= $this->input->post('ikp_konstetasi');
			$ikp_penyelenggaraan= $this->input->post('ikp_penyelenggaraan');
			$status 			= $this->input->post('status');

			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');
	
			$this->load->model('m_admin_provinces');

			if($act=="Edit"){

					$submit = $this->m_admin_provinces->edit($act,$id,$nama_wilayah,$ikp_partisipasi,$ikp_konstetasi,
						$ikp_penyelenggaraan,$status,$upd,$lup);

					if($submit['status']){
						$statusResp=true;
						$reason="Update Data Successfully...!";
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}

			}else{
				
					$submit = $this->m_admin_provinces->add($act,$id,$nama_wilayah,$ikp_partisipasi,$ikp_konstetasi,
						$ikp_penyelenggaraan,$status,$upd,$lup);

					
					if($submit['status']){
						$statusResp=true;
						$reason=$submit['reason'];
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}					
			}

			echo json_encode(array("status"=>$statusResp, "reason"=>$reason));

		}else{
			exit();
		}

	}

	public function change_status(){

		if($this->session->userdata('is_logged_in') == true){

			$id 	= $this->input->post('id');
			$status = $this->input->post('status');
			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');

			$this->load->model('m_admin_provinces');

			$update_status 	= $this->m_admin_provinces->update_status($id,$status,$upd,$lup);

			echo json_encode($update_status);

		}else{
			exit();
		}

	}

	public function del_item(){

		if($this->session->userdata('is_logged_in') == true){

			$id 	= $this->input->post('id');
			$status = $this->input->post('status');
			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');

			$this->load->model('m_admin_provinces');

			$deleted_item = $this->m_admin_provinces->deleted_item($id,$status,$upd,$lup);

			echo json_encode($deleted_item);

		}else{
			exit();
		}
	}


}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
