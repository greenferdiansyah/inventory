<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_rekap_partai extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir,$periode){
		$this->db->query("SET sql_mode=''");
		$sql		= "SELECT a.id, a.desc, IFNULL(b.jumlah,0) AS gub, IFNULL(c.jumlah,0) AS bup, IFNULL(d.jumlah,0) AS kot FROM m_partai a
						LEFT OUTER JOIN 
						(SELECT f.desc, COUNT(*) AS jumlah
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_provinces d ON c.kode_wilayah=d.province_id COLLATE utf8_unicode_ci
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						INNER JOIN m_partai f ON e.parpol_pengusung REGEXP f.desc
						GROUP BY f.desc
						ORDER BY f.desc) b ON a.desc=b.desc
						LEFT OUTER JOIN 
						(SELECT f.desc, COUNT(*) AS jumlah
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_regencies d ON c.kode_wilayah=d.regency_id COLLATE utf8_unicode_ci AND LOWER(d.name) LIKE 'kabupaten%'
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						INNER JOIN m_partai f ON e.parpol_pengusung REGEXP f.desc
						GROUP BY f.desc
						ORDER BY f.desc) c ON a.desc=c.desc
						LEFT OUTER JOIN 
						(SELECT f.desc, COUNT(*) AS jumlah
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_regencies d ON c.kode_wilayah=d.regency_id COLLATE utf8_unicode_ci AND LOWER(d.name) LIKE 'kota%'
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						INNER JOIN m_partai f ON e.parpol_pengusung REGEXP f.desc
						GROUP BY f.desc
						ORDER BY f.desc) d ON a.desc=d.desc";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
