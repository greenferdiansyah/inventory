<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_admin_suket extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (a.name like '%$search%')";
		}

		$sql		= " SELECT a.`name`, IFNULL(b.`jumlah`,'0') AS jumlah, b.id, a.`province_id` as idx
						FROM 
						m_area_provinces a
						LEFT JOIN trans_suket b ON a.`province_id`=b.`kode_wilayah` COLLATE utf8_unicode_ci
						WHERE 1=1 COLLATE utf8_unicode_ci  AND a.status='1' $where_clause
						UNION
						SELECT a.`name`, IFNULL(b.`jumlah`,'0') AS jumlah, b.id , a.`regency_id` as idx
						FROM 
						m_area_regencies a
						LEFT JOIN trans_suket b ON a.`regency_id`=b.`kode_wilayah` COLLATE utf8_unicode_ci
						WHERE 1=1 COLLATE utf8_unicode_ci AND a.status='1' $where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}


	function detail_data($id,$idx){
		
		$leng_id 		= strlen($idx);

		if($leng_id=="2"){
			$sql = "SELECT a.`name`, IFNULL(b.`jumlah`,'0') AS jumlah, b.id, a.`province_id` as idx
				FROM 
				m_area_provinces a
				LEFT JOIN trans_suket b ON a.`province_id`=b.`kode_wilayah` COLLATE utf8_unicode_ci
				WHERE b.id=$id";
		}else{
			$sql = "SELECT a.`name`, IFNULL(b.`jumlah`,'0') AS jumlah, b.id , a.`regency_id` as idx
				FROM 
				m_area_regencies a
				LEFT JOIN trans_suket b ON a.`regency_id`=b.`kode_wilayah` COLLATE utf8_unicode_ci
				WHERE b.id=$id";
		}

		$query = $this->db->query($sql);	
		$data = $query->result_array();
		
		return $data[0];

	}

	function submit($kode_wilayah,$jumlah,$upd,$lup){

		$data = array(
		   'kode_wilayah' => $kode_wilayah,	
		   'jumlah' => $jumlah,
		   'name' => $nama_wilayah,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup,
		);

		$insert = $this->db->replace('m_area_regencies', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
