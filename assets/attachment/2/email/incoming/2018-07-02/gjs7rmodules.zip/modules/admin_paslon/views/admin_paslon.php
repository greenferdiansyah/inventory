<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <span class="text-muted">Administration ·</span>
        <strong>Pasangan Calon</strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Pasangan Calon </strong>
            <a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-success btn-rounded mr-2 mb-2 pointer pull-right' id='modal_form'>
                    <i class='icmn-plus'>Add</i>
            </a>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-hover nowrap" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Wilayah</th>
                            <th>No Urut</th>
                            <th>Kepala Daerah</th>
                            <th>Wakil Kepala Daerah</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama Wilayah</th>
                            <th>No Urut</th>
                            <th>Kepala Daerah</th>
                            <th>Wakil Kepala Daerah</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade modal-size-large show" id="merge_modal" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Pasangan Calon</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="form-1" name="form-1" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" style="display: none"> 
            <input type="hidden" name="act" id="act" value="" style="display: none"> 
            <input type="hidden" name="id" id="id" value="" style="display: none"> 
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Periode</label>
                                <div class="col-md-9" id="sh_2">
                                    <select class="form-control select2"
                                                    data-validation="[NOTEMPTY]"
                                                    id="periode" 
                                                    name="periode">
                                                <option value="">Choose</option>    
                                                {list_periode}
                                    </select>
                                </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Petahana</label>
                                <div class="col-md-9" id="sh_2">
                                    <select class="form-control select2"
                                                    data-validation="[NOTEMPTY]"
                                                    id="is_petahana" 
                                                    name="is_petahana">
                                                <option value="">Choose</option>    
                                                {list_petahana}
                                    </select>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Nama Wilayah</label>
                                <div class="col-md-9" id="sh_2">
                                    <select class="form-control select2"
                                                    data-validation="[NOTEMPTY]"
                                                    id="kode_wilayah" 
                                                    name="kode_wilayah">
                                                <option value="">Choose</option>    
                                                {list_provinces}
                                                {list_regency}
                                    </select>
                                </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Nomor Urut</label>
                                <div class="col-md-9">
                                    <input type="text" 
                                    data-validation="[NOTEMPTY]"
                                    class="form-control" 
                                    placeholder="Nomor Urut" 
                                    id="no_urut" 
                                    name="no_urut" 
                                    value="">
                                </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Kepala Daerah</label>
                                <div class="col-md-9">
                                    <input type="text" 
                                    data-validation="[NOTEMPTY]"
                                    class="form-control" 
                                    placeholder="Kepala Daerah" 
                                    id="kepala_daerah" 
                                    name="kepala_daerah" 
                                    value="">
                                </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Jenis Kelamin Kepala Daerah</label>
                                <div class="col-md-9">
                                    <select class="form-control select2"
                                                    data-validation="[NOTEMPTY]"
                                                    id="gender_kd" 
                                                    name="gender_kd">
                                                <option value="">Choose</option>    
                                                {list_gender}
                                    </select>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Pekerjaan Kepala Daerah</label>
                                <div class="col-md-9">
                                    <input type="text" 
                                    data-validation="[NOTEMPTY]"
                                    class="form-control" 
                                    placeholder="Pekerjaan Kepala Daerah" 
                                    id="pekerjaan_kd" 
                                    name="pekerjaan_kd" 
                                    value="">
                                </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Foto Kepala Daerah</label>
                                <div class="col-md-9">
                                    <input type="file"
                                    class="form-control" 
                                    placeholder="Foto Kepala Daerah" 
                                    id="img_kd" 
                                    name="img_kd" 
                                    value="">
                                </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Wakil Kepala Daerah</label>
                                <div class="col-md-9">
                                    <input type="text" 
                                    data-validation="[NOTEMPTY]"
                                    class="form-control" 
                                    placeholder="Wakil Kepala Daerah" 
                                    id="wakil_kepala_daerah" 
                                    name="wakil_kepala_daerah" 
                                    value="">
                                </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Jenis Kelamin Wakil Kepala Daerah</label>
                                <div class="col-md-9">
                                    <select class="form-control select2"
                                                    data-validation="[NOTEMPTY]"
                                                    id="gender_wakil" 
                                                    name="gender_wakil">
                                                <option value="">Choose</option>    
                                                {list_gender}
                                    </select>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Pekerjaan Wakil Kepala Daerah</label>
                                <div class="col-md-9">
                                    <input type="text" 
                                    data-validation="[NOTEMPTY]"
                                    class="form-control" 
                                    placeholder="Pekerjaan Wakil Kepala Daerah" 
                                    id="pekerjaan_wakil" 
                                    name="pekerjaan_wakil" 
                                    value="">
                                </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Foto Wakil Kepala Daerah</label>
                                <div class="col-md-9">
                                    <input type="file"
                                    class="form-control" 
                                    placeholder="Foto Kepala Daerah" 
                                    id="img_wakil" 
                                    name="img_wakil" 
                                    value="">
                                </div>
                        </div>
                    </div>
                </div>
                <div class="row">    
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Jenis Calon</label>
                                <div class="col-md-9">
                                    <select class="form-control select2"
                                                    data-validation="[NOTEMPTY]"
                                                    id="jenis_calon" 
                                                    name="jenis_calon">
                                                <option value="">Choose</option>    
                                                {list_pencalonan}
                                    </select>
                                </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Status Penetapan</label>
                                <div class="col-md-9">
                                    <input type="text" 
                                    data-validation="[NOTEMPTY]"
                                    class="form-control" 
                                    placeholder="Status Penetapan" 
                                    id="status_penetapan" 
                                    name="status_penetapan" 
                                    value="">
                                </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Parpol Pengusung</label>
                            <div class="col-md-9">
                                <select class="select2" id="parpol_pengusung" name="parpol_pengusung[]" multiple>
                                    {list_parpol}
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Jumlah Kursi/KTP</label>
                                <div class="col-md-9">
                                    <input type="text" 
                                    data-validation="[NOTEMPTY]"
                                    class="form-control" 
                                    placeholder="Jumlah Kursi/KTP" 
                                    id="jml_kursi_ktp" 
                                    name="jml_kursi_ktp" 
                                    value="">
                                </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="l1">Keterangan</label>
                                <div class="col-md-9">
                                    <textarea class="form-control" rows="4"
                                    id="keterangan" 
                                    name="keterangan"></textarea>
                                </div>
                        </div>
                    </div>
                </div>
                          
            </div>
            <div class="modal-footer">
                <button type="button" class="btn pointer" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary pull-right pointer" >Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- END: tables/datatables -->
<!-- START: page scripts -->
<script>
    jQuery(document).ready(function($) {
        $('.select2').select2();
        $('#merge_modal').on('hidden.bs.modal', function () {
          // do something…
               $("#act").val('add');
               $('#periode').val(null).trigger('change');
               $('#is_petahana').val(null).trigger('change');
               $("#no_urut").val('');
               $("#kepala_daerah").val('');
               $("#pekerjaan_kd").val('');
               $("#img_kd").val('');
               $("#wakil_kepala_daerah").val('');
               $("#pekerjaan_wakil").val('');
               $("#img_wakil").val('');
               $("#jml_kursi_ktp").val('');
              // $("#parpol_pengusung").val('');
               $("#status_penetapan").val('');
               $('#gender_kd').val(null).trigger('change');
               $('#gender_wakil').val(null).trigger('change');
               $('#jenis_calon').val(null).trigger('change');
               $('#kode_wilayah').val(null).trigger('change');
               $('#parpol_pengusung').val(null).trigger('change');
        })
    });

    $(function(){
     var baseUrl = '{base_url}';  

     var table =   
     $('#data-table').DataTable({
            processing: true,
            destroy:true,
            serverSide: true,
            responsive: true,
            autoFill: true,
            colReorder: true,
            keys: true,
            rowReorder: true,
            columnDefs: [
                { "width": "10%", "targets": 0 },
                { className: "text-center col-with-icon", "targets": [ 5 ] },
            ],
            ajax: {
                url: baseUrl+"/json_list",
                type:'POST',
            }
        });

    table_reload = setInterval( function () {
        table.ajax.reload( null, false ); // user paging is not reset on reload
    }, 50000 );  

    $('#form-1').validate({
        submit: {
            settings: {
                inputContainer: '.form-group',
                errorListClass: 'form-control-error',
                errorClass: 'has-danger'
            },
            callback: {
                onBeforeSubmit: function (node) {
                    NProgress.start();    
                },
                onSubmit: function (node) {
                    var form = document.getElementById('form-1');
                    var formData = new FormData(form);

                    $.ajax({
                        url: '{base_url}/forms_submit',
                        enctype: 'multipart/form-data',
                        data: formData,
                        processData: false,
                        contentType: false,
                        type: 'post',
                        dataType: 'json',
                    })
                    .done(function(data) {
                        NProgress.done();
                        if(data.status==true){
                            
                            $.notify({
                            title: '<strong>Success!</strong>',
                            message: data.reason
                            },{
                                type: 'primary'
                            });
                            
                            $('#merge_modal').modal('hide');
                            $("#act").val('add');
                            $('#periode').val(null).trigger('change');
                            $('#is_petahana').val(null).trigger('change');
                            $("#no_urut").val('');
                            $("#kepala_daerah").val('');
                            $("#pekerjaan_kd").val('');
                            $("#img_kd").val('');
                            $("#wakil_kepala_daerah").val('');
                            $("#pekerjaan_wakil").val('');
                            $("#img_wakil").val('');
                            $("#jml_kursi_ktp").val('');
                            //$("#parpol_pengusung").val('');
                            $("#status_penetapan").val('');
                            $('#gender_kd').val(null).trigger('change');
                            $('#gender_wakil').val(null).trigger('change');
                            $('#jenis_calon').val(null).trigger('change');
                            $('#kode_wilayah').val(null).trigger('change');
                            $('#parpol_pengusung').val(null).trigger('change');
                            table.ajax.reload( null, false );
                        }else{
                            $.notify(data.reason);
                        }          
                    })
                    .fail(function() {
                        NProgress.done();
                        $.notify("Fail Save Data, Please check your connections...");
                    });
                    
                },
                onError: function (error) {
                    $.notify("Fail, Please Check your input...");
                }

            }
        },
        debug: true

    });

    del = function (id){   
   
        swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, remove it",
            cancelButtonText: "Cancel",
            closeOnConfirm: false,
            closeOnCancel: false
        },
        function(isConfirm) {
            if (isConfirm) {

                $.ajax({
                    url: baseUrl+"/del_item",
                    type: 'POST',
                    dataType: 'json',
                    data: {id: id},
                })
                .done(function() {
                    swal({
                        title: "Deleted!",
                        text: "Your item has been deleted.",
                        type: "success",
                        confirmButtonClass: "btn-success"
                    });
                })
                .fail(function() {
                    swal({
                        title: "Error",
                        text: "Your item is safe :). Fail deleted item",
                        type: "error",
                        confirmButtonClass: "btn-danger"
                    });
                })
                .always(function() {
                    table.ajax.reload( null, false );
                });
                          
            } else {
                swal({
                    title: "Cancelled",
                    text: "Your item is safe :)",
                    type: "error",
                    confirmButtonClass: "btn-danger"
                });
            }
        });
    }

    });

    function detail_data(id){

    var baseUrl = '{base_url}';  
        
        $.ajax({
            url: baseUrl+"/detail_data",
            type: 'POST',
            dataType: 'json',
            data: {id: id },
        })
        .done(function(data) {
            
                $("#act").val('Edit');
                $("#id").val(data.id);
                $('#periode').val(data.periode).trigger('change');
                $('#is_petahana').val(data.is_petahana).trigger('change');
                $("#no_urut").val(data.no_urut);
                $("#kepala_daerah").val(data.kepala_daerah);
                $("#pekerjaan_kd").val(data.pekerjaan_kd);
                $("#wakil_kepala_daerah").val(data.wakil_kepala_daerah);
                $("#pekerjaan_wakil").val(data.pekerjaan_wakil);
                $("#jml_kursi_ktp").val(data.jml_kursi_ktp);
               // $("#parpol_pengusung").val(data.parpol_pengusung);
                $("#status_penetapan").val(data.status_penetapan);
                $('#gender_kd').val(data.gender_kd).trigger('change');
                $('#gender_wakil').val(data.gender_wakil).trigger('change');
                $('#jenis_calon').val(data.jenis_calon).trigger('change');
                $('#kode_wilayah').val(data.kode_wilayah).trigger('change');
                var objparpol = JSON.parse(data.parpol_pengusung);

                $.each(objparpol, function(index, val) {
                     /* iterate through array or object */
                    $("#parpol_pengusung option[value='" + val + "']").prop("selected", true);
                });
                $("#parpol_pengusung").trigger("change");


        })
        .fail(function(data) {
                $("#act").val('add');
                $("#id").val('');
                $('#periode').val(null).trigger('change');
                $('#is_petahana').val(null).trigger('change');
                $("#no_urut").val('');
                $("#kepala_daerah").val('');
                $("#pekerjaan_kd").val('');
                $("#img_kd").val('');
                $("#wakil_kepala_daerah").val('');
                $("#pekerjaan_wakil").val('');
                $("#img_wakil").val('');
                $("#jml_kursi_ktp").val('');
                //$("#parpol_pengusung").val('');
                $("#status_penetapan").val('');
                $('#gender_kd').val(null).trigger('change');
                $('#gender_wakil').val(null).trigger('change');
                $('#jenis_calon').val(null).trigger('change');
                $('#kode_wilayah').val(null).trigger('change');
                $('#parpol_pengusung').val(null).trigger('change');
        });
    }
  
    
</script>
<!-- END: page scripts -->