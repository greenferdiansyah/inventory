<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_admin_regency extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY a.regency_id";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (a.regency_id like '%$search%' OR b.name like '%$search%' OR a.`name` like '%$search%' )";
		}

		$sql		= " SELECT a.regency_id,b.name AS provinsi, a.`name` AS kota_kab, a.`status`
						FROM m_area_regencies a
						LEFT JOIN m_area_provinces b ON a.`province_id`=b.`province_id`
						WHERE a.is_deleted=0
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	function detail_data($id){

		$sql ="SELECT a.regency_id,b.name AS provinsi, a.`name` AS kota_kab, a.`status`, 
			a.ikp_partisipasi, a.ikp_konstetasi,a.ikp_penyelenggaraan,a.province_id
			FROM m_area_regencies a
			LEFT JOIN m_area_provinces b ON a.`province_id`=b.`province_id`
			WHERE a.is_deleted=0 AND a.regency_id='$id'";
		$query = $this->db->query($sql);	
		$data = $query->result_array();
		
		return $data[0];

	}

	function update_status($id,$status,$upd,$lup){

		$data = array('status' => $status,
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('regency_id', $id );

		$update	= $this->db->update('m_area_regencies', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}

	function deleted_item($id,$status,$upd,$lup){

		$data = array('is_deleted' => '1',
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('regency_id', $id );

		$update	= $this->db->update('m_area_regencies', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been deleted');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Deleted Data');
		}

		return $result;

	}


	function add($act,$id,$province_id,$nama_wilayah,$ikp_partisipasi,$ikp_konstetasi,
						$ikp_penyelenggaraan,$status,$upd,$lup){

		$data = array(
		   'regency_id' => $id,	
		   'province_id' => $province_id,
		   'name' => $nama_wilayah,
		   'ikp_partisipasi' => $ikp_partisipasi,
		   'ikp_konstetasi' => $ikp_konstetasi,
		   'ikp_penyelenggaraan' => $ikp_penyelenggaraan,
		   'status' => $status,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('m_area_regencies', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit($act,$id,$province_id,$nama_wilayah,$ikp_partisipasi,$ikp_konstetasi,
						$ikp_penyelenggaraan,$status,$upd,$lup){
		
		$data = array( 'province_id' => $province_id,
					   'name' => $nama_wilayah,
					   'ikp_partisipasi' => $ikp_partisipasi,
					   'ikp_konstetasi' => $ikp_konstetasi,
					   'ikp_penyelenggaraan' => $ikp_penyelenggaraan,
					   'status' => $status,
					   'updated' => $upd,
					   'updated_at' => $lup
					);

		$this->db->where('regency_id', $id );

		$update	= $this->db->update('m_area_regencies', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}

}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
