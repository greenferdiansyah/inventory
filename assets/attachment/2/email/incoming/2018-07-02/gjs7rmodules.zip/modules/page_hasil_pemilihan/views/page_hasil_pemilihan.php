<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <span class="text-muted">Hasil ·</span>
        <strong>Hasil Pemilihan</strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Hasil Pemilihan </strong>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-striped table-bordered table-condensed display select" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th rowspan="1" style="text-align: center; vertical-align: middle; width: 21px;">No</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle; width: 21px;">Nama Wilayah</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Jenis Pemilihan</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >No.Urut</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Nama Calon Kepala Daerah</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Nama Calon Wakil Kepala Daerah</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Parpol Pendukung</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Jumlah Suara</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Presentase</th>
                        </tr>
                        </thead>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- END: tables/datatables -->
<!-- START: page scripts -->
<script src="assets/js/numeral.min.js"></script>
<script>
    jQuery(document).ready(function($) {
        $('.select2').select2();
    });

    $(function(){
     var baseUrl = '{base_url}';  
     var table =   
     $('#data-table').DataTable({
            processing: true,
            destroy:true,
            serverSide: true,
            responsive: true,
            autoFill: true,
            colReorder: true,
            keys: true,
            rowReorder: true,
            pageLength : 50,
            columnDefs: [
                { "width": "2%", "targets": 0 },
                { "width": "20%", "targets": 1 },
                { "width": "12%", className: "text-left col-with-icon", "targets": [ 2 ] },
                { "width": "5%", className: "text-center col-with-icon", "targets": [ 3 ] },
                { className: "text-left col-with-icon", "targets": [ 4 ] },
                { className: "text-left col-with-icon", "targets": [ 5 ] },
                { className: "text-left col-with-icon", "targets": [ 6 ] },
                { className: "text-right col-with-icon", "targets": [ 7 ] },
                { className: "text-right col-with-icon", "targets": [ 7 ] },
            ],
            ajax: {
                url: baseUrl+"/json_list",
                type:'POST',
            }
    });

    }); 
</script>
<!-- END: page scripts -->