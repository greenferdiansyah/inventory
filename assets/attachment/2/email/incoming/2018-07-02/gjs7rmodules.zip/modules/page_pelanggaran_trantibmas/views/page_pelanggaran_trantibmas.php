<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <span class="text-muted">Pelanggaran ·</span>
        <strong>Trantibmas</strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Trantibmas </strong>
            <?php
            if($this->session->userdata('userlevel')=="admin"){
            ?>
            <a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-success btn-rounded mr-2 mb-2 pointer pull-right' id='modal_form'>
                    <i class='icmn-plus'>Add</i>
            </a>
            <?php
            }
            ?>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-striped table-bordered table-condensed display select" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th rowspan="1" style="text-align: center; vertical-align: middle; width: 21px;">No</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle; width: 21px;">Nama Wilayah</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Kode Wilayah</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Pemohon</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Termohon</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Kategori Sengketa</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Obyek Sengketa</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Keterangan</th>
                        </tr>
                        </thead>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="merge_modal" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Data Sengketa</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="form-1" name="form-1" method="POST">
            <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" style="display: none"> 
            <input type="hidden" name="act" id="act" value="" style="display: none"> 
            <input type="hidden" name="id" id="id" value="" style="display: none"> 
            <div class="modal-body">
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l2">Provinsi</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="province_id" 
                                            name="province_id">
                                        <option value="">Choose</option>    
                                        {list_provinces}
                            </select>
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l2">Kabupaten/Kota</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="regency_id" 
                                            name="regency_id">
                                        <option value="">Choose</option>    
                                        {list_regencies}
                            </select>
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l2">Periode</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="periode" 
                                            name="periode">
                                        <option value="">Choose</option>    
                                        {list_periode}
                            </select>
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Pemohon</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Pemohon" id="pemohon" name="pemohon" value="">
                        </div>
                </div>  
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Termohon</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Termohon" id="termohon" name="termohon" value="">
                        </div>
                </div>   
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Kategori Pelanggaran</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="kategori_pelanggaran" 
                                            name="kategori_pelanggaran">
                                        <option value="">Choose</option>    
                                        {list_kategori_pelanggaran}
                            </select>
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Kategori Sengketa</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Kategori Sengketa" id="kategori_sengketa" name="kategori_sengketa" value="">
                        </div>
                </div> 
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Obyek Sengketa</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Kategori Sengketa" id="obyek_sengketa" name="obyek_sengketa" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Keterangan</label>
                        <div class="col-md-9">
                            <textarea id="keterangan" name="keterangan" class="form-control" rows="3"></textarea>
                        </div>
                </div>  
            </div>
            <div class="modal-footer">
                <button type="button" class="btn pointer" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary pull-right pointer" >Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- END: tables/datatables -->
<!-- START: page scripts -->
<script src="assets/js/numeral.min.js"></script>
<script>
    jQuery(document).ready(function($) {
        $('.select2').select2();

        $('#province_id').change(function(event) {
            /* Act on the event */
            $("#regency_id").val(null).trigger("change"); 
        });

        $('#merge_modal').on('hidden.bs.modal', function () {
          // do something…
            $("#act").val('add');
            $("#id").val('');
            $("#periode").val('');
            $("#pemohon").val('');
            $("#termohon").val('');
            $("#kategori_sengketa").val('');
            $("#obyek_sengketa").val('');
            $("#keterangan").val('');
            $('#province_id').val(null).trigger('change');
            $('#regency_id').val(null).trigger('change');
            $('#kategori_pelanggaran').val(null).trigger('change');
        });
   
         var baseUrl = '{base_url}';  
         var table =   
         $('#data-table').DataTable({
                processing: true,
                destroy:true,
                serverSide: true,
                responsive: true,
                autoFill: true,
                colReorder: true,
                keys: true,
                rowReorder: true,
                pageLength : 50,
                columnDefs: [
                    { "width": "2%", "targets": 0 },
                    { "width": "15%", "targets": 1 },
                    { "width": "15%", className: "text-left col-with-icon", "targets": [ 2 ] },
                    { className: "text-left col-with-icon", "targets": [ 3 ] },
                    { className: "text-left col-with-icon", "targets": [ 4 ] },
                    { className: "text-left col-with-icon", "targets": [ 5 ] },
                    { className: "text-left col-with-icon", "targets": [ 6 ] },
                    { className: "text-left col-with-icon", "targets": [ 7 ] }
                ],
                ajax: {
                    url: baseUrl+"/json_list",
                    type:'POST',
                }
        });

        $('#regency_id').select2({
            placeholder: 'Choose',
            allowClear: false,
            language: {
                 noResults: function(term) {
                    return "No Results Found";
                }
            },
            escapeMarkup: function (markup) {
                    return markup;
            },
            ajax: {
            url: "admin_district/find_regency",
            method:'post',
            dataType: 'json',
            delay: 250,
            data: function (params) {
                    return {
                        q: params.term, // search term
                        page: params.page,
                        province_id: $("#province_id").val(),
                    };
                },
              processResults: function (data) {
                    return {
                    results: data
                };
              },
              cache: true
            }     
        });
        
        $('#form-1').validate({
            submit: {
                settings: {
                    inputContainer: '.form-group',
                    errorListClass: 'form-control-error',
                    errorClass: 'has-danger'
                },
                callback: {
                    onBeforeSubmit: function (node) {
                        NProgress.start();    
                    },
                    onSubmit: function (node) {

                        $.ajax({
                            url: '{base_url}/forms_submit',
                            type: 'POST',
                            dataType: 'json',
                            data: $('#form-1').serialize() ,
                        })
                        .done(function(data) {
                            NProgress.done();
                            if(data.status==true){
                                
                                $.notify({
                                title: '<strong>Success!</strong>',
                                message: data.reason
                                },{
                                    type: 'primary'
                                });
                                $('#merge_modal').modal('hide');
                                $("#act").val('add');
                                $("#id").val('');
                                $("#periode").val('');
                                $("#pemohon").val('');
                                $("#termohon").val('');
                                $("#kategori_sengketa").val('');
                                $("#obyek_sengketa").val('');
                                $("#keterangan").val('');
                                $('#province_id').val(null).trigger('change');
                                $('#regency_id').val(null).trigger('change');
                                $('#kategori_pelanggaran').val(null).trigger('change');

                                table.ajax.reload( null, false );
                            }else{
                                $.notify(data.reason);
                            }          
                        })
                        .fail(function() {
                            NProgress.done();
                            $.notify("Fail Save Data, Please check your connections...");
                        });
                        
                    },
                    onError: function (error) {
                        $.notify("Fail, Please Check your input...");
                    }

                }
            },
            debug: true

        }); 

    }); 

    function detail_data(id){

    var baseUrl = '{base_url}';  
        
        $.ajax({
            url: baseUrl+"/detail_data",
            type: 'POST',
            dataType: 'json',
            data: {id: id },
        })
        .done(function(data) {
            
                $("#act").val('Edit');
                $("#id").val(data.id);
                $("#periode").val(data.periode);
                $("#pemohon").val(data.pemohon);
                $("#termohon").val(data.termohon);
                $("#kategori_sengketa").val(data.kategori_sengketa);
                $("#obyek_sengketa").val(data.obyek_sengketa);
                $("#keterangan").val(data.keterangan);
                $('#province_id').val(data.province_id).trigger('change');
                $('#regency_id').val(data.regency_id).trigger('change');
                $('#kategori_pelanggaran').val(data.kategori_pelanggaran).trigger('change');
            
        })
        .fail(function(data) {
                $("#act").val('add');
                $("#id").val('');
                $("#periode").val('');
                $("#pemohon").val('');
                $("#termohon").val('');
                $("#kategori_sengketa").val('');
                $("#obyek_sengketa").val('');
                $("#keterangan").val('');
                $('#province_id').val(null).trigger('change');
                $('#regency_id').val(null).trigger('change');
                $('#kategori_pelanggaran').val(null).trigger('change');
        });
    }
</script>
<!-- END: page scripts -->