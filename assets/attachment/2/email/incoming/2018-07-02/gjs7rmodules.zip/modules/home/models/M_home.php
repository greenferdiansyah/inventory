<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_home extends CI_Model {

	function list_pilkada(){

		$sql = "SELECT province_id AS id,CONCAT('Provinsi',' ',`name`) as name FROM m_area_provinces";

		$query = $this->db->query($sql);

		$result= $query->result_array();
		$list_data = "";
		foreach ($result as $key1 => $value1) {
			# code...
			$list_data .="<optgroup label=\"".$value1['name']."\">"; 

			$sql2 	= "SELECT regency_id AS id,`name` FROM `m_area_regencies` WHERE province_id='".$value1['id']."' AND status='1'";
			$query2 = $this->db->query($sql2); 
			$result2= $query2->result_array();

				foreach ($result2 as $key2 => $value2) {
					# code...
					$list_data .= "<option value='".$value2['id']."' >".$value2['name']."</option>";
				}

			$list_data .="</optgroup>"; 
		}

		return $list_data;
	}

	function check_area_pilkada($id,$leng_id){

		if($leng_id==2){
			$sql = "SELECT province_id AS id,CONCAT('Provinsi',' ',`name`) AS name,ikp_partisipasi,ikp_konstetasi,ikp_penyelenggaraan
					FROM m_area_provinces WHERE province_id='$id'";	

		}else{
			$sql = "SELECT regency_id AS id,`name`,ikp_partisipasi,ikp_konstetasi,ikp_penyelenggaraan
					FROM m_area_regencies WHERE regency_id='$id'";			
		}

		$query  = $this->db->query($sql);
			
		$result = $query->result_array();

		return $result[0];
	}

	function check_status_pilkada($id,$leng_id){
		
		if($leng_id==2){
			
			$sql 	= "SELECT `status` FROM m_area_provinces WHERE province_id='$id'";

		}else{

			$sql 	= "SELECT `status` FROM `m_area_regencies` WHERE regency_id='$id'";	
		}

		$query  = $this->db->query($sql);

		$result = $query->result_array();
		if(isset($result[0])){
			$result = $result[0];
		}else{
			$result = array("status"=> 0);
		}
		return $result;
	}


	function data_ikp_provinsi(){
		$sql 	= "SELECT province_id AS id, ikp_partisipasi,ikp_konstetasi,ikp_penyelenggaraan
					FROM m_area_provinces";	
		$query  = $this->db->query($sql);
			
		$result = $query->result_array();	
		# #d11509 merah
		# #28d109 hijau
		# #ff5e00 orange
		$data = "";
		foreach ($result as $key => $value) {
			# code...
			$ikp= number_format(($value['ikp_partisipasi']+$value['ikp_konstetasi']+$value['ikp_penyelenggaraan'])/3,2,'.','');
			if($ikp<2.00){
				$clr ="28d109";
			}elseif($ikp<3.00){
				$clr ="ff5e00";
			}else{
				$clr ="d11509";
			}

			$data .= ',{
		                id: "'.$value['id'].'",
		                color:"#'.$clr.'"
		              }';
		}

		return $data;	
	}

	function check_hasil_pilkada($id){

		$sql = "SELECT a.kode_wilayah,a.no_urut,a.kepala_daerah,a.wakil_kepala_daerah,IFNULL(c.jml_suara_sah,'0') AS jumlah_suara,IFNULL(b.jumlah_pemilih,'0') AS jumlah_pemilih,
				a.img_kd,a.img_wakil,a.jenis_calon,a.parpol_pengusung,a.jml_kursi_ktp
				FROM m_paslon a
				LEFT JOIN trans_suara b ON a.kode_wilayah=b.kode_wilayah
				LEFT JOIN trans_js_v2 c ON b.id=c.id_trans_suara AND a.id=c.id_paslon
				WHERE a.kode_wilayah='$id' AND a.no_urut!=0 AND a.is_deleted='0' ";
		$query  = $this->db->query($sql);
			
		$data = $query->result_array();

		$result = array();

		foreach ($data as $key => $rows) {
			# code...
			if(isset($rows['img_kd'])){
				$file_image1 = $this->com_fileproject($rows['kode_wilayah'],$rows['img_kd']);
			}else{
				$url_destination = base_url().'assets/img/default.png';
				$file_image1 = array("status"=> "success", "image"=> $url_destination );
			}
			
			if(isset($rows['img_wakil'])){
				$file_image2 = $this->com_fileproject($rows['kode_wilayah'],$rows['img_wakil']);
			}else{
				$url_destination = base_url().'assets/img/default.png';
				$file_image2 = array("status"=> "success", "image"=> $url_destination ); 
			}

			$result[]=array(
				"kode_wilayah" 	=> $rows["kode_wilayah"],
				"no_urut" 		=> $rows["no_urut"],
				"kepala_daerah"	=> $rows["kepala_daerah"],
				"wakil_kepala_daerah"	=> $rows["wakil_kepala_daerah"],
				"jumlah_suara"	=> $rows["jumlah_suara"],
				"jumlah_pemilih"=> $rows["jumlah_pemilih"],
				"img_kd"		=> $file_image1['image'],
				"img_wakil"		=> $file_image2['image'],
				"jenis_calon"	=> $rows["jenis_calon"],
				"parpol_pengusung"	=> $rows["parpol_pengusung"],
				"jml_kursi_ktp"	=> $rows["jml_kursi_ktp"]
			);
		}
		return $result;
	}

	function data_jumlah_wilayah($id){
		$sql = "SELECT v.province_id,SUM(v.kabupaten) AS kabupaten ,SUM(v.kota) AS kota
				FROM 
				(SELECT regency_id,province_id,
				CASE 
				WHEN LOWER(`name`) NOT LIKE 'kota%' THEN 1
				ELSE 0
				END kabupaten,
				CASE
				WHEN LOWER(`name`) LIKE 'kota%' THEN 1
				ELSE 0
				END kota
				FROM m_area_regencies) v WHERE v.province_id='$id'
				GROUP BY v.province_id";

		$query  = $this->db->query($sql);
			
		$data = $query->result_array();
		$result = array();
		foreach ($data as $key => $rows) {
				# code...
			$result[]= array(
				"kabupaten" => $rows['kabupaten'],
				"kota" 		=> $rows['kota'],
				"kec" 		=> $this->jumlah_kecamatan($rows['province_id']),
				"desa" 		=> $this->jumlah_desa($rows['province_id']),
			);
		}	
		
		return $result;
	}

	function jumlah_kecamatan($id){
		$sql = "SELECT count(*) as jml
				FROM m_area_districts a,m_area_regencies b,m_area_provinces c
				WHERE a.regency_id=b.regency_id AND c.province_id=b.province_id AND b.province_id='$id'";

		$query  = $this->db->query($sql);
		$result = $query->result_array();
		return $result[0]['jml'];
	}

	function jumlah_desa($id){
		$sql = "SELECT count(*) as jml
				FROM m_area_districts a,m_area_regencies b,m_area_provinces c,m_area_villages d
				WHERE a.regency_id=b.regency_id AND c.province_id=b.province_id AND d.district_id=a.district_id 
				AND b.province_id='$id'";

		$query  = $this->db->query($sql);
		$result = $query->result_array();
		return $result[0]['jml'];
	}

	function data_jumlah_wilayah_kab($id){
		$sql = "SELECT v.province_id,SUM(v.kabupaten) AS kabupaten ,SUM(v.kota) AS kota
				FROM 
				(SELECT regency_id,province_id,
				CASE 
				WHEN LOWER(`name`) NOT LIKE 'kota%' THEN 1
				ELSE 0
				END kabupaten,
				CASE
				WHEN LOWER(`name`) LIKE 'kota%' THEN 1
				ELSE 0
				END kota
				FROM m_area_regencies WHERE regency_id='$id') v
				GROUP BY v.province_id";

		$query  = $this->db->query($sql);
			
		$data = $query->result_array();
		
		$result = array();
		foreach ($data as $key => $rows) {
				# code...
			$result[]= array(
				"kabupaten" => $rows['kabupaten'],
				"kota" 		=> $rows['kota'],
				"kec" 		=> $this->jumlah_kecamatan_kab($id),
				"desa" 		=> $this->jumlah_desa_kab($id),
			);
		}	
		
		return $result;
	}

	function jumlah_kecamatan_kab($id){
		$sql = "SELECT count(*) as jml
				FROM m_area_districts a,m_area_regencies b,m_area_provinces c
				WHERE a.regency_id=b.regency_id AND c.province_id=b.province_id AND b.regency_id='$id'";

		$query  = $this->db->query($sql);
		$result = $query->result_array();
		return $result[0]['jml'];
	}

	function jumlah_desa_kab($id){
		$sql = "SELECT count(*) as jml
				FROM m_area_districts a,m_area_regencies b,m_area_provinces c,m_area_villages d
				WHERE a.regency_id=b.regency_id AND c.province_id=b.province_id AND d.district_id=a.district_id 
				AND b.regency_id='$id'";

		$query  = $this->db->query($sql);
		$result = $query->result_array();
		return $result[0]['jml'];
	}

	public function bar_chart_ikp($check_area_pilkada){
		if($check_area_pilkada['ikp_penyelenggaraan']<2){
				$clr_1 ="green";
			}elseif($check_area_pilkada['ikp_penyelenggaraan']<3){
				$clr_1 ="orange";
			}else{
				$clr_1 ="red";
			}

			if($check_area_pilkada['ikp_konstetasi']<2){
				$clr_2 ="green";
			}elseif($check_area_pilkada['ikp_konstetasi']<3){
				$clr_2 ="orange";
			}else{
				$clr_2 ="red";
			}

			if($check_area_pilkada['ikp_partisipasi']<2){
				$clr_3 ="green";
			}elseif($check_area_pilkada['ikp_partisipasi']<3){
				$clr_3 ="orange";
			}else{
				$clr_3 ="red";
			}

			$bar_chart 			 = "data: [
				                    {y: ".$check_area_pilkada['ikp_penyelenggaraan'].", color: '".$clr_1."'},
				                    {y: ".$check_area_pilkada['ikp_konstetasi'].", color: '".$clr_2."'},
				                    {y: ".$check_area_pilkada['ikp_partisipasi'].", color: '".$clr_3."'}
				                    ]";
			return $bar_chart;	                    

	}

	public function pie_chart_hasil($check_area_pilkada){
		
		$sql = "SELECT jumlah_dpt,jumlah_pemilih,suara_sah,suara_tidak_sah,abstain FROM trans_suara WHERE kode_wilayah='".$check_area_pilkada['id']."'";
		
		$query = $this->db->query($sql);

		$result = $query->result_array();
		if(isset($result[0])){
			$pie_chart 			= "[{
			                        name: 'Suara Sah',
			                        y: ".$result[0]['suara_sah'].",
			                        color: 'green'
			                    }, {
			                        name: 'Suara Tidak Sah',
			                        y: ".$result[0]['suara_tidak_sah'].",
			                        color: 'orange'
			                    }, {
			                        name: 'Tidak Memilih',
			                        y: ".$result[0]['abstain'].",
			                        color: 'red'
			                    }]";	
		}else{
			$pie_chart = "[{
			                  name: 'Belum ada data',
			                  y: 100,
			                  color: 'grey'
			              }]";
		}
		
		return $pie_chart;
	}

	public function count_suara($kode_wilayah){
		$sql ="SELECT SUM(jumlah_suara) as jumlah_total FROM m_paslon WHERE kode_wilayah='$kode_wilayah'";

		$query  = $this->db->query($sql);
			
		$result = $query->result_array();

		return $result[0];
	}

	public function list_calon($tipe){
		$this->db->query("SET sql_mode=''");

		$select_having="";
		$where_having = "";
		$where_clause = "";
		if($tipe=="calon_tunggal"){
			$select_having="COUNT(1) AS jml,";
			$where_having = "HAVING (jml = 1)";
		}else if($tipe=="calon_petahana"){
			$where_clause = " AND a.is_petahana='1'";
		}else if($tipe=="calon_asn"){
			$where_clause = " AND (a.pekerjaan_kd='PNS' OR a.pekerjaan_wakil='PNS')";
		}else if($tipe=="calon_independent"){
			$where_clause = " AND a.jenis_calon='PERSEORANGAN'";
		}

		$sql ="SELECT a.kode_wilayah, b.name, a.no_urut, a.kepala_daerah, a.wakil_kepala_daerah,IFNULL(d.jml_suara_sah,'0') AS jumlah_suara,IFNULL(c.jumlah_pemilih,'0') AS jumlah_total,
				$select_having a.img_kd,a.img_wakil
				FROM m_paslon a
				LEFT JOIN m_area_provinces b ON a.kode_wilayah=b.province_id COLLATE utf8_unicode_ci
				LEFT JOIN trans_suara c ON a.kode_wilayah=c.kode_wilayah
				LEFT JOIN trans_js_v2 d ON c.id=d.id_trans_suara AND a.id=d.id_paslon
				WHERE LENGTH(a.`kode_wilayah`)=2 AND a.no_urut!=0 AND b.status =1 AND a.is_deleted='0' $where_clause
				GROUP BY a.kode_wilayah 
				$where_having
				UNION
				SELECT a.kode_wilayah, b.name, a.no_urut, a.kepala_daerah, a.wakil_kepala_daerah,IFNULL(d.jml_suara_sah,'0') AS jumlah_suara,IFNULL(c.jumlah_pemilih,'0') AS jumlah_total,
				$select_having a.img_kd,a.img_wakil
				FROM m_paslon a
				LEFT JOIN m_area_regencies b ON a.kode_wilayah=b.regency_id COLLATE utf8_unicode_ci
				LEFT JOIN trans_suara c ON a.kode_wilayah=c.kode_wilayah
				LEFT JOIN trans_js_v2 d ON c.id=d.id_trans_suara AND a.id=d.id_paslon
				WHERE LENGTH(a.`kode_wilayah`)=4 AND a.no_urut!=0 AND b.status =1 AND a.is_deleted='0' $where_clause
				GROUP BY a.kode_wilayah 
				$where_having";		
		$query  = $this->db->query($sql);
			
		$result = $query->result_array();

		$data		= array();
		foreach($result as $key => $rows){
			if(isset($rows['img_kd'])){
				$file_image1 = $this->com_fileproject($rows['kode_wilayah'],$rows['img_kd']);
			}else{
				$url_destination = base_url().'assets/img/default.png';
				$file_image1 = array("status"=> "success", "image"=> $url_destination );
			}
			
			if(isset($rows['img_wakil'])){
				$file_image2 = $this->com_fileproject($rows['kode_wilayah'],$rows['img_wakil']);
			}else{
				$url_destination = base_url().'assets/img/default.png';
				$file_image2 = array("status"=> "success", "image"=> $url_destination ); 
			}
			$data[] = array(
							"kode_wilayah" => $rows['kode_wilayah'],
							"name" => $rows['name'],
							"no_urut" => $rows['no_urut'],
							"kepala_daerah" => $rows['kepala_daerah'],
							"wakil_kepala_daerah" => $rows['wakil_kepala_daerah'],
							"jumlah_suara" => $rows['jumlah_suara'],
							"jumlah_total" => $rows['jumlah_total'],
							"image_1" => $file_image1['image'],
							"image_2" => $file_image2['image']
					);
		}

		return $data;
	}


	public function chart_pilgubData(){
		$sql = "SELECT a.name, FORMAT(IFNULL((IFNULL(b.suara_sah+b.suara_tidak_sah+b.abstain,0)/IFNULL(b.jumlah_dpt,0))*100,0),2) AS perc
				FROM m_area_provinces a
				LEFT OUTER JOIN trans_suara b ON a.province_id=b.kode_wilayah COLLATE utf8_unicode_ci
				WHERE a.status=1
				ORDER BY perc DESC LIMIT 5";
		$query  = $this->db->query($sql);
			
		$result = $query->result_array();
		
		return $result;		
	}

	public function chart_pilkotData(){
		$sql = "SELECT a.name, FORMAT(IFNULL((IFNULL(b.suara_sah+b.suara_tidak_sah+b.abstain,0)/IFNULL(b.jumlah_dpt,0))*100,0),2) AS perc
				FROM m_area_regencies a
				LEFT OUTER JOIN trans_suara b ON a.regency_id=b.kode_wilayah COLLATE utf8_unicode_ci
				WHERE LOWER(`name`) LIKE 'kota%' AND a.status=1
				ORDER BY perc DESC LIMIT 5";
		$query  = $this->db->query($sql);
			
		$result = $query->result_array();
		
		return $result;		
	}

	public function chart_pilbupData(){
		$sql = "SELECT a.name, FORMAT(IFNULL((IFNULL(b.suara_sah+b.suara_tidak_sah+b.abstain,0)/IFNULL(b.jumlah_dpt,0))*100,0),2) AS perc
				FROM m_area_regencies a
				LEFT OUTER JOIN trans_suara b ON a.regency_id=b.kode_wilayah COLLATE utf8_unicode_ci
				WHERE LOWER(`name`) NOT LIKE 'kota%' AND a.status=1
				ORDER BY perc DESC LIMIT 5";
		$query  = $this->db->query($sql);
			
		$result = $query->result_array();
		
		return $result;		
	}

	public function epelaporan($id){
		$sql = "SELECT nomor_laporan,id_pelapor,judul,keterangan,img_laporan,tanggal_laporan
				FROM trans_laporan WHERE flg_verify_show=1 AND nomor_laporan>$id";

		$query  = $this->db->query($sql);
			
		$result = $query->result_array();
		
		return $result;
	}

	public function data_wilayah($id,$leng_id){

		if($leng_id==2){
			$this->db->query("SET sql_mode=''");
			$this->db->select('sum_citizen, sum_asn, sum_tps, sum_man, sum_woman ');
			$query = $this->db->get_where('m_dpt_provinces', array('id_provinces' => $id));

			$data = $query->result_array();
			
			return $data[0];
		}else{
			$this->db->query("SET sql_mode=''");
			$this->db->select('sum_citizen, sum_asn, sum_tps, sum_man, sum_woman ');
			$query = $this->db->get_where('m_dpt_regencies', array('id_regencies' => $id));

			$data = $query->result_array();

			return $data[0];
		}

	}


	public function com_fileproject($kode_wilayah,$img_kd){

		$kode_wilayah = $kode_wilayah;
		$img_kd 	  = $img_kd;
		$this->load->library('Compress');  // load the codeginiter library


		
		$file = base_url().'assets/img/paslon/'.$kode_wilayah.'/'.$img_kd; // file that you wanna compress
		$new_name_image = 'com_'.$img_kd; // name of new file compressed
		$quality = 10; // Value that I chose
		$destination = '/mesiotda/assets/img/paslon/'.$kode_wilayah; // This destination must be exist on your project

		$file_ori 	   = $_SERVER['DOCUMENT_ROOT'].$destination.'/'.$img_kd;
		$file_compress = $_SERVER['DOCUMENT_ROOT'].$destination.'/'.$new_name_image;

		if(file_exists($file_ori)){
			if(!file_exists($file_compress)){
				$compress = new Compress();

				$compress->file_url = $file;
				$compress->new_name_image = $new_name_image;
				$compress->quality = $quality;
				$compress->destination = $destination;

				$result = $compress->compress_image();
				
				$url_destination = base_url().'/assets/img/paslon/'.$kode_wilayah.'/'.$new_name_image;
				$data = array("status"=> "success", "image"=> $url_destination );
			}else{
				$url_destination = base_url().'/assets/img/paslon/'.$kode_wilayah.'/'.$new_name_image;
				$data = array("status"=> "success", "image"=> $url_destination );
			}
		}else{
				$url_destination = base_url().'assets/img/default.png';
				$data = array("status"=> "success", "image"=> $url_destination );
		}		

		return $data;
	}

	function test_kompress(){

		$sql = "SELECT a.kode_wilayah,a.no_urut,a.kepala_daerah,a.wakil_kepala_daerah,IFNULL(c.jml_suara_sah,'0') AS jumlah_suara,IFNULL(b.jumlah_pemilih,'0') AS jumlah_pemilih,
				a.img_kd,a.img_wakil,a.jenis_calon,a.parpol_pengusung,a.jml_kursi_ktp
				FROM m_paslon a
				LEFT JOIN trans_suara b ON a.kode_wilayah=b.kode_wilayah
				LEFT JOIN trans_js_v2 c ON b.id=c.id_trans_suara AND a.id=c.id_paslon
				WHERE a.no_urut!=0 AND a.is_deleted='0' ";
		$query  = $this->db->query($sql);
			
		$data = $query->result_array();

		$result = array();

		foreach ($data as $key => $rows) {
			# code...
			if(isset($rows['img_kd'])){
				$file_image1 = $this->com_fileproject($rows['kode_wilayah'],$rows['img_kd']);
			}else{
				$url_destination = base_url().'assets/img/default.png';
				$file_image1 = array("status"=> "success", "image"=> $url_destination );
			}
			
			if(isset($rows['img_wakil'])){
				$file_image2 = $this->com_fileproject($rows['kode_wilayah'],$rows['img_wakil']);
			}else{
				$url_destination = base_url().'assets/img/default.png';
				$file_image2 = array("status"=> "success", "image"=> $url_destination ); 
			}

			$result[]=array(
				"kode_wilayah" 	=> $rows["kode_wilayah"],
				"no_urut" 		=> $rows["no_urut"],
				"kepala_daerah"	=> $rows["kepala_daerah"],
				"wakil_kepala_daerah"	=> $rows["wakil_kepala_daerah"],
				"jumlah_suara"	=> $rows["jumlah_suara"],
				"jumlah_pemilih"=> $rows["jumlah_pemilih"],
				"img_kd"		=> $file_image1['image'],
				"img_wakil"		=> $file_image2['image'],
				"jenis_calon"	=> $rows["jenis_calon"],
				"parpol_pengusung"	=> $rows["parpol_pengusung"],
				"jml_kursi_ktp"	=> $rows["jml_kursi_ktp"]
			);
		}
		return $result;
	}
}

/* End of file M_home.php */
/* Location: ./application/models/M_home.php */
