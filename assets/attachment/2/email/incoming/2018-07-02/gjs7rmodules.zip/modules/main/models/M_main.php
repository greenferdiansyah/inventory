<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_main extends CI_Model {


}

/* End of file M_main.php */
/* Location: ./application/models/M_main.php */
