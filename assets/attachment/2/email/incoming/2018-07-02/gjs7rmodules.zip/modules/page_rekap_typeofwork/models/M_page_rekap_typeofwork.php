<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_rekap_typeofwork extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir,$periode){
		$this->db->query("SET sql_mode=''");
		$sql		= "SELECT DISTINCT(a.pekerjaan_kd) AS pekerjaan_kd , 
						IFNULL(b.jml1,0)AS gub,
						IFNULL(c.jml1,0)AS wagub, 
						IFNULL(d.jml1,0)AS bupati,
						IFNULL(e.jml1,0)AS wabup,
						IFNULL(f.jml1,0)AS walikota,
						IFNULL(g.jml1,0)AS wawal
						FROM m_paslon a
						LEFT JOIN
						(SELECT e.`pekerjaan_kd` AS pekerjaan,COUNT(*) AS jml1
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_provinces d ON c.kode_wilayah=d.province_id COLLATE utf8_unicode_ci
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						GROUP BY e.`pekerjaan_kd`) b ON a.`pekerjaan_kd`=b.pekerjaan
						LEFT JOIN 
						(SELECT e.`pekerjaan_wakil` AS pekerjaan,COUNT(*) AS jml1
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_provinces d ON c.kode_wilayah=d.province_id COLLATE utf8_unicode_ci
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						GROUP BY e.`pekerjaan_kd`) c ON a.`pekerjaan_kd`=c.pekerjaan
						LEFT JOIN
						(SELECT e.`pekerjaan_kd` AS pekerjaan,COUNT(*) AS jml1
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_regencies d ON c.kode_wilayah=d.regency_id COLLATE utf8_unicode_ci AND LOWER(d.`name`) LIKE 'kabupaten%'
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						GROUP BY e.`pekerjaan_kd`) d ON a.`pekerjaan_kd`=d.pekerjaan
						LEFT JOIN
						(SELECT e.`pekerjaan_wakil` AS pekerjaan,COUNT(*) AS jml1
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_regencies d ON c.kode_wilayah=d.regency_id COLLATE utf8_unicode_ci AND LOWER(d.`name`) LIKE 'kabupaten%'
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						GROUP BY e.`pekerjaan_kd`) e ON a.`pekerjaan_kd`=e.pekerjaan
						LEFT JOIN
						(SELECT e.`pekerjaan_kd` AS pekerjaan,COUNT(*) AS jml1
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_regencies d ON c.kode_wilayah=d.regency_id COLLATE utf8_unicode_ci AND LOWER(d.`name`) LIKE 'kota%'
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						GROUP BY e.`pekerjaan_kd`) f ON a.`pekerjaan_kd`=f.pekerjaan
						LEFT JOIN
						(SELECT e.`pekerjaan_wakil` AS pekerjaan,COUNT(*) AS jml1
						FROM trans_js_v2 a
						INNER JOIN (
						SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						FROM trans_js_v2
						GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_regencies d ON c.kode_wilayah=d.regency_id COLLATE utf8_unicode_ci AND LOWER(d.`name`) LIKE 'kota%'
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						GROUP BY e.`pekerjaan_kd`) g ON a.`pekerjaan_kd`=g.pekerjaan
						ORDER BY pekerjaan_kd";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");
		
		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
