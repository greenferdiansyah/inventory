<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page_paslon_perseorangan extends CI_Controller {

	public function index(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
				
			$this->load->library('page_render');
			$this->load->library('drop_down');

			$data=array(
				'page_content' 				=> $page,
				'base_url'					=> base_url().$page
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}


	public function json_list(){
			
			$parent_page	=  $this->uri->segment(1);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_paslon_perseorangan');
			
			$data =  $this->m_page_paslon_perseorangan->list_data($length,$start,$search,$order,$dir);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				$parpol = "";
				$no = 0;
				if(is_array(json_decode($row['parpol_pengusung']))){
					foreach (json_decode($row['parpol_pengusung']) as $key => $value) {
						# code...
						$no++;
						$parpol .=$no.". ".$value."<br>";
					}
				}
				$output['data'][]=array(
					$nomor_urut, 
					$row['area_name'], 
					$row['no_urut'], 
					$row['kepala_daerah'],
					$row['gender_kd'],
					$row['pekerjaan_kd'],
					$row['wakil_kepala_daerah'],
					$row['gender_wakil'],
					$row['pekerjaan_wakil'],
					$row['jenis_calon'],
					$parpol,
					$row['jml_pendukung'],
					$row['status_penetapan'],
					$row['keterangan'],
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
