<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_paslon extends CI_Controller {

	public function index(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
				
			$this->load->library('page_render');
			$this->load->library('drop_down');

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="jenis_kelamin"');
			$list_gender = $this->drop_down->build(null);

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="jenis_pencalonan"');
			$list_pencalonan = $this->drop_down->build(null);

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="pemilihan"');
			$list_pemilihan = $this->drop_down->build(null);

			$this->drop_down->select('province_id','name');
			$this->drop_down->from('m_area_provinces');
			$this->drop_down->where('is_deleted="0"');
			$list_provinces = $this->drop_down->build(null);

			$this->drop_down->select('regency_id','name');
			$this->drop_down->from('m_area_regencies');
			$this->drop_down->where('is_deleted="0"');
			$list_regency = $this->drop_down->build(null);

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="periode_pilkada"');
			$list_periode = $this->drop_down->build(null);

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="is_petahana"');
			$list_petahana = $this->drop_down->build(null);


			$this->drop_down->select('`desc`','`desc` as detail');
			$this->drop_down->from('m_partai');
			$this->drop_down->where('is_deleted="0"');
			$list_parpol = $this->drop_down->build(null);

			$data=array(
				'page_content' 				=> $page,
				'base_url'					=> base_url().$page,
				'list_gender'				=> $list_gender,
				'list_pencalonan'			=> $list_pencalonan,
				'list_pemilihan'			=> $list_pemilihan,
				'list_provinces'			=> $list_provinces,
				'list_regency'				=> $list_regency,
				'list_periode'				=> $list_periode,
				'list_petahana'				=> $list_petahana,
				'list_parpol'				=> $list_parpol
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}


	public function json_list(){
			
			$parent_page	=  $this->uri->segment(1);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_admin_paslon');
			
			$data =  $this->m_admin_paslon->list_data($length,$start,$search,$order,$dir);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
                $iconAction = "";    

				$iconAction = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-primary btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['id']."')>
								<i class='icmn-pencil'></i>
							  </a>
							  <a onclick=del('".$row['id']."') class='btn btn-icon btn-danger btn-rounded mr-2 mb-2' data-toggle='tooltip' title='Deleted' aria-expanded='false'>
			                    <i class='icmn-bin2'></i>
			                  </a>";
				$output['data'][]=array(
					$nomor_urut, 
					$row['area_name'], 
					$row['no_urut'], 
					$row['kepala_daerah'],
					$row['wakil_kepala_daerah'],
					$iconAction
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function detail_data(){

		if($this->session->userdata('is_logged_in') == true){
			
		$id 		= $this->input->post('id');

		$this->load->model('m_admin_paslon');

		$data =  $this->m_admin_paslon->detail_data($id);

		echo json_encode($data);

		}else{
			exit();
		}

	}


	public function forms_submit(){

		if($this->session->userdata('is_logged_in') == true){
			

			$act 				= $this->input->post('act');
			$id 				= $this->input->post('id');
			$periode 			= $this->input->post('periode');
			$is_petahana		= $this->input->post('is_petahana');
			$kode_wilayah		= $this->input->post('kode_wilayah');
			$no_urut 			= $this->input->post('no_urut');
			$kepala_daerah 		= $this->input->post('kepala_daerah');
			$gender_kd 			= $this->input->post('gender_kd');
			$pekerjaan_kd 		= $this->input->post('pekerjaan_kd');
			$wakil_kepala_daerah= $this->input->post('wakil_kepala_daerah');
			$gender_wakil 		= $this->input->post('gender_wakil');
			$pekerjaan_wakil 	= $this->input->post('pekerjaan_wakil');
			$jenis_calon 		= $this->input->post('jenis_calon');
			$status_penetapan 	= $this->input->post('status_penetapan');
			$parpol_pengusung 	= $this->input->post('parpol_pengusung');
			$jml_kursi_ktp		= $this->input->post('jml_kursi_ktp');
			$keterangan			= $this->input->post('keterangan');

			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');
			
			$parpol = "";
			if(is_array($parpol_pengusung)){
				$parpol = '["';
				foreach ($parpol_pengusung as $key => $value) {
					$parpol .= $value.'","'; 
				}
				$parpol  = substr($parpol, 0, -2);
				$parpol .= ']';
			}
			$parpol_pengusung = $parpol;
			$this->load->model('m_admin_paslon');

			if($act=="Edit"){

					$submit = $this->m_admin_paslon->edit($act,$id,$kode_wilayah,$periode,$is_petahana,$no_urut,$kepala_daerah,$gender_kd,$pekerjaan_kd,$wakil_kepala_daerah,
								$gender_wakil,$pekerjaan_wakil,$jenis_calon,$status_penetapan,$parpol_pengusung,$jml_kursi_ktp,$keterangan,$upd,$lup);

					if($submit['status']){
						$path 	= str_replace('\\','/', APPPATH)."";
						$path 	= str_replace('application','assets/img/paslon',$path);
						$kode_wilayah = $kode_wilayah.'/';
						
						!is_dir($path.$kode_wilayah)?mkdir($path.$kode_wilayah,0777,TRUE):'';

						$final_path = $path.$kode_wilayah;

						$config['upload_path'] = $final_path;
						$config['allowed_types'] = 'gif|jpg|png';
						$config['encrypt_name'] = TRUE;

						$this->load->library('upload', $config);
					
						if($this->upload->do_upload('img_kd')){

							$file_img	= $this->upload->data('file_name');
							$orig_name	= $this->upload->data('orig_name');	

							$upload_file 	= $this->m_admin_paslon->upload_kd($id,$file_img);
						}

						if($this->upload->do_upload('img_wakil')){
							$file_img	= $this->upload->data('file_name');
							$orig_name	= $this->upload->data('orig_name');	

							$upload_file 	= $this->m_admin_paslon->upload_wakil($id,$file_img);
						}
						
						$statusResp=true;
						$reason="Update Data Successfully...!";

					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}

			}else{
				
					$submit = $this->m_admin_paslon->add($act,$id,$kode_wilayah,$periode,$is_petahana,$no_urut,$kepala_daerah,$gender_kd,$pekerjaan_kd,$wakil_kepala_daerah,
								$gender_wakil,$pekerjaan_wakil,$jenis_calon,$status_penetapan,$parpol_pengusung,$jml_kursi_ktp,$keterangan,$upd,$lup);

					
					if($submit['status']){
						$path 	= str_replace('\\','/', APPPATH)."";
						$path 	= str_replace('application','assets/img/paslon',$path);
						$kode_wilayah = $kode_wilayah.'/';
						
						!is_dir($path.$kode_wilayah)?mkdir($path.$kode_wilayah,0777,TRUE):'';

						$final_path = $path.$kode_wilayah;

						$config['upload_path'] = $final_path;
						$config['allowed_types'] = 'gif|jpg|png';
						$config['encrypt_name'] = TRUE;

						$this->load->library('upload', $config);
					
						if($this->upload->do_upload('img_kd')){

							$file_img	= $this->upload->data('file_name');
							$orig_name	= $this->upload->data('orig_name');	

							$upload_file 	= $this->m_admin_paslon->upload_kd($submit['insert_id'],$file_img);
						}

						if($this->upload->do_upload('img_wakil')){
							$file_img	= $this->upload->data('file_name');
							$orig_name	= $this->upload->data('orig_name');	

							$upload_file 	= $this->m_admin_paslon->upload_wakil($submit['insert_id'],$file_img);
						}
						
						$statusResp=true;
						$reason="Insert Data Successfully...!";

					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}					
			}

			echo json_encode(array("status"=>$statusResp, "reason"=>$reason));

		}else{
			exit();
		}

	}

	public function del_item(){

		if($this->session->userdata('is_logged_in') == true){

			$id 	= $this->input->post('id');
			$status = $this->input->post('status');
			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');

			$this->load->model('m_admin_paslon');

			$deleted_item = $this->m_admin_paslon->deleted_item($id,$status,$upd,$lup);

			echo json_encode($deleted_item);

		}else{
			exit();
		}
	}

}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
