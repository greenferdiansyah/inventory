<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_paslon extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY area_name,no_urut";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%' OR a.no_urut like '%$search%' OR a.kepala_daerah like '%$search%' 
			OR a.gender_kd like '%$search%' OR a.pekerjaan_kd like '%$search%' OR a.wakil_kepala_daerah like '%$search%' 
			OR a.gender_wakil like '%$search%' OR a.pekerjaan_wakil like '%$search%' OR a.jenis_calon like '%$search%'
			OR a.parpol_pengusung like '%$search%' OR a.status_penetapan like '%$search%' OR a.keterangan like '%$search%')";
		}

		$sql		= " SELECT b.name AS area_name,a.no_urut,a.kepala_daerah,a.gender_kd,a.pekerjaan_kd,
						a.`wakil_kepala_daerah`,a.`gender_wakil`,a.`pekerjaan_wakil`,a.`jenis_calon`,
						a.parpol_pengusung, a.jml_pendukung, a.`status_penetapan`,a.`keterangan`,a.id
						FROM
						m_paslon a 
						LEFT JOIN m_area_provinces b ON a.kode_wilayah=b.province_id COLLATE utf8_unicode_ci
						WHERE LENGTH(a.`kode_wilayah`)=2 AND a.is_deleted='0'
						$where_clause
						UNION 
						SELECT b.name AS area_name,a.no_urut,a.kepala_daerah,a.gender_kd,a.pekerjaan_kd,
						a.`wakil_kepala_daerah`,a.`gender_wakil`,a.`pekerjaan_wakil`,a.`jenis_calon`,
						a.parpol_pengusung, a.jml_pendukung, a.`status_penetapan`,a.`keterangan`,a.id
						FROM
						m_paslon a 
						LEFT JOIN m_area_regencies b ON a.kode_wilayah=b.regency_id COLLATE utf8_unicode_ci
						WHERE LENGTH(a.`kode_wilayah`)=4 AND a.is_deleted='0'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
