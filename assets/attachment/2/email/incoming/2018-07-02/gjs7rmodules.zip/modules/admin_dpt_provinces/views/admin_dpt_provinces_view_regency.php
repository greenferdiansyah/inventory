<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <span class="text-muted">Administration ·</span>
        <span class="text-muted">DPT ·</span>
        <strong>Provinsi {province_name}</strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Daftar Pemilih Tetap Pilakada Serentak Tahun 2018 {province_name}</strong>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-striped table-bordered table-condensed display select" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th rowspan="3" style="text-align: center; vertical-align: middle; width: 21px;">No</th>
                            <th rowspan="3" style="text-align: center; vertical-align: middle; width: 21px;">Kabupaten/Kota</th>
                            <th rowspan="1" colspan="14" style="text-align: center; vertical-align: middle" >Data Pemilih Tetap Tahun 2018</th>
                        </tr>
                        <tr>
                            <th rowspan="2" style="text-align: center; vertical-align: middle; width: 21px;">Jumlah TPS</th>
                            <th rowspan="1" colspan="3" style="text-align: center; vertical-align: middle">Jumlah Pemilih</th>
                            <th rowspan="1" colspan="6" style="text-align: center; vertical-align: middle">Difabel</th>
                        </tr>
                        <tr>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">L</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">P</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">Total</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">1</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">2</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">3</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">4</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">5</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">Total</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle">Action</th>
                        </thead>
                        <tfoot>
                            <tr>
                                <th colspan="2" style="text-align:right">Total:</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                        </tfoot>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END: tables/datatables -->
<div class="modal fade" id="merge_modal" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Kabupaten/Kota</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="form-1" name="form-1" method="POST">
            <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" style="display: none"> 
            <input type="hidden" name="act" id="act" value="" style="display: none"> 
            <input type="hidden" name="id" id="id" value="" style="display: none"> 
            <div class="modal-body">
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l2">Kabupaten/Kota</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="id_regencies" 
                                            name="id_regencies">
                                        <option value="">Choose</option>    
                                        {list_regency}
                            </select>
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Periode</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Periode" id="periode" name="periode" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Penduduk</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah Penduduk" id="sum_citizen" name="sum_citizen" value="">
                        </div>
                </div> 
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">ASN</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah ASN" id="sum_asn" name="sum_asn" value="">
                        </div>
                </div> 
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">TPS</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah TPS" id="sum_tps" name="sum_tps" value="">
                        </div>
                </div>    
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Pemilih Pria</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah Pemilih Pria" id="sum_man" name="sum_man" value="">
                        </div>
                </div>  
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Pemilih Wanita</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah Pemilih Wanita" id="sum_woman" name="sum_woman" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Pemilih Difabel1</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah Pemilih Difabel 1" id="dif_1" name="dif_1" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Pemilih Difabel2</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah Pemilih Difabel 2" id="dif_2" name="dif_2" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Pemilih Difabel3</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah Pemilih Difabel 3" id="dif_3" name="dif_3" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Pemilih Difabel4</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah Pemilih Difabel 4" id="dif_4" name="dif_4" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Pemilih Difabel5</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Jumlah Pemilih Difabel 5" id="dif_5" name="dif_5" value="">
                        </div>
                </div>          
            </div>
            <div class="modal-footer">
                <button type="button" class="btn pointer" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary pull-right pointer" >Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- START: page scripts -->
<script src="assets/js/numeral.min.js"></script>
<script>
    jQuery(document).ready(function($) {
        $('.select2').select2();
    });

    $(function(){
     var baseUrl = '{base_url}';  
     var table =   
     $('#data-table').DataTable({
            processing: true,
            destroy:true,
            serverSide: true,
            responsive: true,
            autoFill: true,
            colReorder: true,
            keys: true,
            rowReorder: true,
            pageLength : 50,
            "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                switch (aData[8]) {
                    case 'Done':
                        $(nRow).addClass('success')
                        break;
                }
            },
            columnDefs: [
                { "width": "2%", "targets": 0 },
                { "width": "15%", "targets": 1 },
                { "width": "10%", className: "text-right col-with-icon", "targets": [ 2 ] },
                { className: "text-right col-with-icon", "targets": [ 3 ] },
                { className: "text-right col-with-icon", "targets": [ 4 ] },
                { className: "text-right col-with-icon", "targets": [ 5 ] },
                { className: "text-right col-with-icon", "targets": [ 6 ] },
                { className: "text-right col-with-icon", "targets": [ 7 ] },
                { className: "text-right col-with-icon", "targets": [ 8 ] },
                { className: "text-right col-with-icon", "targets": [ 9 ] },
                { className: "text-right col-with-icon", "targets": [ 10 ] },
                { className: "text-right col-with-icon", "targets": [ 11 ] },
                { className: "text-center col-with-icon", "targets": [ 12 ] },
            ],
            ajax: {
                url: baseUrl+"/json_list_regency/{id_provinces}",
                type:'POST',
            },
            "footerCallback": function(row, data, start, end, display) {
                var api = this.api(),
                    data;

                // Remove the formatting to get integer data for summation
                var intVal = function(i) {
                    return typeof i === 'string' ?
                        i.replace(/[\$,]/g, '') * 1 :
                        typeof i === 'number' ?
                        i : 0;
                };

                // Total over this page
                total1 = api
                    .column(2, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total2 = api
                    .column(3, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total3 = api
                    .column(4, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total4 = api
                    .column(5, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total5 = api
                    .column(6, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total6 = api
                    .column(7, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total7 = api
                    .column(8, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
                             
                total8 = api
                    .column(9, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
                
                total9 = api
                    .column(10, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);

                total10 = api
                    .column(11, { page: 'current' })
                    .data()
                    .reduce(function(a, b) {
                        return intVal(a) + intVal(b);
                    }, 0);
                    

                var number = numeral(total1);
                var number2 = numeral(total2);
                var number3 = numeral(total3);
                var number4 = numeral(total4);
                var number5 = numeral(total5);
                var number6 = numeral(total6);
                var number7 = numeral(total7);
                var number8 = numeral(total8);
                var number9 = numeral(total9);
                var number10= numeral(total10);

                number.format();
                number2.format();
                number3.format();
                number4.format();
                number5.format();
                number6.format();
                number7.format();
                number8.format();
                number9.format();
                number10.format();
                // '1,000'
                numeral.defaultFormat('0,0');

                // Update footer
                $(api.column(2).footer()).html(
                    ' ' + number.format() + ' '
                );
                $(api.column(3).footer()).html(
                    ' ' + number2.format() + ' '
                );
                $(api.column(4).footer()).html(
                    ' ' + number3.format() + ' '
                );
                $(api.column(5).footer()).html(
                    ' ' + number4.format() + ' '
                );
                $(api.column(6).footer()).html(
                    ' ' + number5.format() + ' '
                );
                $(api.column(7).footer()).html(
                    ' ' + number6.format() + ' '
                );
                $(api.column(8).footer()).html(
                    ' ' + number7.format() + ' '
                );
                $(api.column(9).footer()).html(
                    ' ' + number8.format() + ' '
                );
                $(api.column(10).footer()).html(
                    ' ' + number9.format() + ' '
                );
                $(api.column(11).footer()).html(
                    ' ' + number10.format() + ' '
                );
            }
    });

    $('#form-1').validate({
        submit: {
            settings: {
                inputContainer: '.form-group',
                errorListClass: 'form-control-error',
                errorClass: 'has-danger'
            },
            callback: {
                onBeforeSubmit: function (node) {
                    NProgress.start();    
                },
                onSubmit: function (node) {

                    $.ajax({
                        url: '{base_url}/forms_submit_regency',
                        type: 'POST',
                        dataType: 'json',
                        data: $('#form-1').serialize() ,
                    })
                    .done(function(data) {
                        NProgress.done();
                        if(data.status==true){
                            
                            $.notify({
                            title: '<strong>Success!</strong>',
                            message: data.reason
                            },{
                                type: 'primary'
                            });
                            
                            $('#merge_modal').modal('hide');
                            $("#act").val('add');
                            $("#periode").val('');
                            $("#sum_asn").val('');
                            $("#sum_citizen").val('');
                            $("#sum_tps").val('');
                            $("#sum_man").val('');
                            $("#sum_woman").val('');
                            $("#dif_1").val('');
                            $("#dif_2").val('');
                            $("#dif_3").val('');
                            $("#dif_4").val('');
                            $("#dif_5").val('');
                            $('#id_regencies').val(null).trigger('change');
                            table.ajax.reload( null, false );
                        }else{
                            $.notify(data.reason);
                        }          
                    })
                    .fail(function() {
                        NProgress.done();
                        $.notify("Fail Save Data, Please check your connections...");
                    });
                    
                },
                onError: function (error) {
                    $.notify("Fail, Please Check your input...");
                }

            }
        },
        debug: true

    });

    }); 


function detail_data(id){

    var baseUrl = '{base_url}';  
        
        $.ajax({
            url: baseUrl+"/detail_data_regency",
            type: 'POST',
            dataType: 'json',
            data: {id: id },
        })
        .done(function(data) {
            
                $("#act").val('Edit');
                $("#id").val(data.id);
                $("#periode").val(data.periode);
                $("#sum_asn").val(data.sum_asn);
                $("#sum_citizen").val(data.sum_citizen);
                $("#sum_tps").val(data.sum_tps);
                $("#sum_man").val(data.sum_man);
                $("#sum_woman").val(data.sum_woman);
                $("#dif_1").val(data.dif_1);
                $("#dif_2").val(data.dif_2);
                $("#dif_3").val(data.dif_3);
                $("#dif_4").val(data.dif_4);
                $("#dif_5").val(data.dif_5);
                $('#id_regencies').val(data.id_regencies).trigger('change');
            
        })
        .fail(function(data) {
                $("#act").val('add');
                $("#id").val('');
                $("#periode").val('');
                $("#sum_asn").val('');
                $("#sum_citizen").val('');
                $("#sum_tps").val('');
                $("#sum_man").val('');
                $("#sum_woman").val('');
                $("#dif_1").val('');
                $("#dif_2").val('');
                $("#dif_3").val('');
                $("#dif_4").val('');
                $("#dif_5").val('');
                $('#id_regencies').val(null).trigger('change');
        });
    }
</script>
<!-- END: page scripts -->