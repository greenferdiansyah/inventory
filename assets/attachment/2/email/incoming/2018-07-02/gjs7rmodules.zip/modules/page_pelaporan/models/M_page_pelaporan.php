<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_pelaporan extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY a.tanggal_laporan DESC";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" WHERE (DATE(a.`tanggal_laporan`) like '%$search%' OR DATE_FORMAT(a.`tanggal_laporan`, '%H:%i') like '%$search%' 
			OR a.`lokasi` like '%$search%' OR a.`keterangan` like '%$search%' )";
		}

		$sql		= " SELECT DATE(a.`tanggal_laporan`) AS tanggal, DATE_FORMAT(a.`tanggal_laporan`, '%H:%i') AS jam,
						a.`lokasi`,a.`keterangan`,a.`img_laporan`, a.nomor_laporan
						FROM trans_laporan a
						LEFT JOIN m_login b ON a.`id_pelapor`=b.`userid`
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
