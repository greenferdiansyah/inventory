<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index(){
		
		$this->load->model('q_login');

		$tenant = $this->q_login->check_tenant();

		$data = array(  "base_url" => base_url() ,
						"favicon" => $tenant['favicon'], 
						"title" => $tenant['title'] );

		$this->parser->parse('login', $data);
		
	}

	public function check_login(){

		$userid		= $this->input->post('validation[email]');
		$password	= $this->input->post('validation[password]');


		$this->load->model('q_login');

		$check_login = $this->q_login->check_login($userid,$password);
		
		if(is_array($check_login)){				

				if($check_login['status']==TRUE){
						$sess	= array(
									'userid'				=> $check_login['userid'],
									'first_name'			=> $check_login['first_name'],
									'last_name'				=> $check_login['last_name'],
									'group_member'			=> $check_login['group_member'],
									'userlevel' 			=> $check_login['userlevel'],
									'position' 				=> $check_login['position'],
									'email' 				=> $check_login['email'],
									'phone' 				=> $check_login['phone'],
									'foto'					=> $check_login['foto'],
									'is_logged_in'			=> true
									);

						$this->session->set_userdata($sess);
						
						$result = array("status"=>"success","title"=>"Login Success","reason"=>"Please Wait");
				}else{

					$result = array("status"=>"fail","title"=>"Login Fail","reason"=>"mohon cek kembali userid & password anda, atau ulangi beberapa saat lagi");		
				
				}	

		}else{
			
			$result = array("status"=>"error","title"=>"Login Fail","reason"=>"error");
		
		}

		echo json_encode($result);
	}
}

/* End of file login.php */
/* Location: ./application/controllers/login.php */
