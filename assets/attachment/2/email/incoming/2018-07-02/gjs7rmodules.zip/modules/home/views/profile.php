<!-- START: dashboard alpha -->
<style type="text/css">
    .pointer {
        cursor: pointer;
    }
    .btn.btn-danger, .show > .btn.btn-danger {
        background-color: #cd1c00;
        border-color: #cd1c00;
    }
    tr.border_bottom td {
      border-bottom:1pt solid black;
    }
    tr.border_top td {
      border-top:1pt solid black;
    }
    tr.border_left td {
      border-left:1pt solid black;
    }
</style>
<div class="row">
    <div class="col-lg-6">
        <div class="cat__core__sortable" id="left-col0">
            <section class="card" order-id="card-000">
                <div class="card-block">
                    <table class="table">
                        <tbody>
                            <tr>
                                <td>
                                    <a href="javascript:void(0);">
                                        <img src="assets/img/wilayah/{id_img}.png" alt="Alternative text to the image" width="100px">
                                    </a>
                                </td>
                                <td>
                                    <h2>PILKADA {name}</h2>
                                    <p>{name_small}</p>
                                    <ul>
                                      <li>Jumlah Penduduk : {jumlah_penduduk}</li>
                                      <li>Jumlah DPT : {jumlah_dpt}</li>
                                      <li>Jumlah TPS : {jumlah_tps}</li>
                                      <li>Jumlah ASN : {jumlah_asn}</li>
                                      <li>Jumlah Kab/Kota/Kec/Desa : {kab} / {kota} / {kec} / {desa}</li>
                                    </ul>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>    
    <div class="col-lg-6">
        <div class="cat__core__sortable" id="left-col">
            <section class="card" order-id="card-001">
                <div class="card-block">
                    <div class="row">
                        <div class="col-xl-6">
                            <div id="chart1" style="height: 183px"></div>
                        </div>
                        <div class="col-xl-6">
                            <h3 align="center" style="color:#{clr_ikp}">INDEKS KERAWANAN PEMILU</h3>
                            <p align="center" style="color:#{clr_ikp} "> <font size="14">{ikp}</font>  </p> 
                            <table align="center" >
                                <tbody>
                                    <tr class="">
                                        <td><small>0 - 1.99</small></td>
                                        <td><small>Rendah</small></td>
                                    </tr>
                                    <tr class="">
                                        <td><small>2 - 2.99</small></td>
                                        <td><small>Sedang</small></td>
                                    </tr>
                                    <tr class="">
                                        <td><small>3 - 4.00</small></td>
                                        <td><small>Tinggi</small></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="cat__core__sortable" id="left-col1">
            <section class="card" order-id="card-002">
                <div class="card-block">
                   <div class="col-xl-12">
                        <div id="chart2" style="height: 250px"></div>
                    </div>
                   <p align="center"> Analisis Hasil : Selisih Suara Paslon no 2 dan 3 sebesar 2,9 kemungkinan terjadi sengketa.</p>
                </div>
            </section>
        </div>
    </div> 
    <div class="col-lg-7">
        <div class="cat__core__sortable" id="left-col2">
            <section class="card" order-id="card-003">
                <div class="card-block">
                   <div class="col-xl-12">
                        <div class="mb-5">
                              <table class="table table-striped">
                                  <tbody id="check_hasil_pilkada">
                                      
                                  </tbody>
                              </table>
                        </div>
                    </div>
                </div>
            </section>
        </div> 
    </div>
    <div class="col-lg-12" align="center">
        <button type="button" class="btn btn-danger mr-2 mb-2 pointer" onclick="history.go(-1);" >Tutup</button>
    </div>  
</div>  

<!-- START: page scripts -->
<script>
    function check_hasil_pilkada(ini){

    var data_pilkada = '';
    var tot_suara = 0;
    
        $.ajax({
            url: '{base_url}/check_hasil_pilkada',
            type: 'POST',
            dataType: 'json',
            data: {id: ini},
        })
        .done(function(data) {

            $.each(data, function(index, val) {
                 /* iterate through array or object */
                 tot_suara    = parseInt(tot_suara)+parseInt(val.jumlah_suara);
            });
            var tot_paslon = 0;
            var percen_total =0;
            $.each(data, function(index, val) {
                tot_paslon++;
                 /* iterate through array or object */
                    if(tot_suara==0 || tot_suara==null){
                        var percen = 0;
                    }else{
                        var percen = (val.jumlah_suara/tot_suara)*100;
                        
                        numeral.defaultFormat('0.00');

                        var number = numeral(percen); 
                        var percen = number.format();
                    }
                if(val.parpol_pengusung!=''){
                    var objparpol = JSON.parse(val.parpol_pengusung);
                    var parpol = '';
                        $.each(objparpol, function(index, value_parpol) {
                         /* iterate through array or object */
                            parpol = parpol+value_parpol+', ';
                        });
                    var parpol_pengusung = parpol.substring(0, parpol.length -2); 
                }else{
                    var parpol_pengusung = "";
                }    
                

                if(val.jenis_calon=='PARPOL'){
                    var pendukung = 'Kursi';
                }else{
                    var pendukung = 'KTP';
                }
                  data_pilkada = data_pilkada+'<tr>';
                  data_pilkada = data_pilkada+'<td width="10%"> ';
                  data_pilkada = data_pilkada+'<font size="3px">No '+val.no_urut+'</font>';
                  data_pilkada = data_pilkada+'</td>';
                  data_pilkada = data_pilkada+'<td>';
                  data_pilkada = data_pilkada+'<a href="javascript:void(0);">';
                  data_pilkada = data_pilkada+'<img src="'+val.img_kd+'" alt="Kepala Daerah" width="50px">';
                  data_pilkada = data_pilkada+'</a>';
                  data_pilkada = data_pilkada+'<a href="javascript:void(0);">';
                  data_pilkada = data_pilkada+'<img src="'+val.img_wakil+'" alt="Wakil Kepala Daerah" width="50px">';
                  data_pilkada = data_pilkada+'</a>';
                  data_pilkada = data_pilkada+'</td>';
                  data_pilkada = data_pilkada+'<td width="20%">';
                  data_pilkada = data_pilkada+'<font size="1px">'+val.jenis_calon+'</font>: ';
                  data_pilkada = data_pilkada+'<font size="1px">'+parpol_pengusung+'</font><br>';
                  data_pilkada = data_pilkada+'<font size="1px">Total :'+val.jml_kursi_ktp+' '+pendukung+'</font><br>';
                  data_pilkada = data_pilkada+'</td>';
                  data_pilkada = data_pilkada+'<td align="center" width="30%">';
                  data_pilkada = data_pilkada+'<font size="2px">'+val.kepala_daerah+'</font><br>';
                  data_pilkada = data_pilkada+'<font size="1px">&</font><br>';
                  data_pilkada = data_pilkada+'<font size="2px">'+val.wakil_kepala_daerah+'</font>';
                  data_pilkada = data_pilkada+'</td>';
                  data_pilkada = data_pilkada+'<td align="center" width="20%">';
                  data_pilkada = data_pilkada+'<font size="5px" style="color:#cd1c00">'+percen+' %</font><br>';
                  data_pilkada = data_pilkada+'<font size="1px">'+addCommas(val.jumlah_suara)+' Suara</font>';
                  data_pilkada = data_pilkada+'</td>';
                  data_pilkada = data_pilkada+'</tr>';

                  percen_total = percen_total+percen;

            });
                
                if(tot_paslon==1){
                      data_pilkada = data_pilkada+'<tr>';
                      data_pilkada = data_pilkada+'<td width="10%"> ';
                      data_pilkada = data_pilkada+'</td>';
                      data_pilkada = data_pilkada+'<td>';
                      data_pilkada = data_pilkada+'<a href="javascript:void(0);">';
                      data_pilkada = data_pilkada+'<img src="{base}assets/img/kotak_kosong.jpg" alt="Kepala Daerah" width="50px">';
                      data_pilkada = data_pilkada+'</a>';
                      data_pilkada = data_pilkada+'<a href="javascript:void(0);">';
                      data_pilkada = data_pilkada+'<img src="{base}assets/img/kotak_kosong.jpg" alt="Wakil Kepala Daerah" width="50px">';
                      data_pilkada = data_pilkada+'</a>';
                      data_pilkada = data_pilkada+'</td>';
                      data_pilkada = data_pilkada+'<td align="center" colspan="3">';
                      data_pilkada = data_pilkada+'<font size="4px"></font>';
                      data_pilkada = data_pilkada+'</td>';
                      data_pilkada = data_pilkada+'</tr>';
                 }

                 data_pilkada  = data_pilkada +'<tr>';
                 data_pilkada  = data_pilkada +'<td colspan="4" align="center">';
                 data_pilkada  = data_pilkada +'<font size="5px" style="color:#cd1c00">Total</font>';
                 data_pilkada  = data_pilkada +'</td>';
                 data_pilkada  = data_pilkada +'<td>';
                 data_pilkada  = data_pilkada+'<font size="5px" style="color:#cd1c00">'+Math.ceil(percen_total)+' %</font><br>';
                 data_pilkada  = data_pilkada+'<font size="1px">'+addCommas(tot_suara)+' Suara</font>';
                 data_pilkada  = data_pilkada +'</td>';
                 data_pilkada  = data_pilkada +'</tr>';


        })
        .fail(function() {
            console.log("error");
        })
        .always(function() {
            $('#check_hasil_pilkada').html(data_pilkada);
            console.log("complete");
        });
        
    }

    function addCommas(nStr) {

        nStr += '';
        var x = nStr.split('.');
        var x1 = x[0];
        var x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + ',' + '$2');
        }
        return x1 + x2;
    }

    $(document).ready(function() {

        setInterval(check_hasil_pilkada({kode_wilayah}), 600000);  

            Highcharts.chart('chart1', {
                chart: {
                    type: 'bar'
                },
                title: {
                    text: ''
                },
                legend: {
                    enabled: false
                },
                xAxis: {
                    categories: ['Penyelenggara', 'Konstetasi', 'Partisipasi'],
                    title: {
                        text: null
                    }
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: '',
                        align: 'high'
                    },
                    labels: {
                        overflow: 'justify'
                    }
                },
                tooltip: {
                    valueSuffix: ' index'
                },
                plotOptions: {
                    bar: {
                        dataLabels: {
                            enabled: true
                        }
                    }
                },
                credits: {
                    enabled: false
                },
                series: [{name: 'Tahun 2018',{bar_chart}}]
            });


            // Build the chart
            Highcharts.chart('chart2', {
                chart: {
                    type: 'column'
                },
                title: {
                    text: 'Hasil Hitung TPS (Form C1) {name_small}'
                },
                yAxis: {
                    title: {
                        text: 'Suara'
                    }
                },
                legend: {
                    enabled: false
                },
                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },
                plotOptions: {
                    column: {
                        pointPadding: 0.2,
                        borderWidth: 0
                    }
                },
                series: [{name: 'Suara',colorByPoint: true, data: {pie_chart}
                }]
            });
    });
    

    $( function() {

        ///////////////////////////////////////////////////////////
        // tooltips
        $("[data-toggle=tooltip]").tooltip();

        ///////////////////////////////////////////////////////////
        // jquery ui sortable
        $('#left-col, #left-col0, #left-col1, #left-col2, #left-col3, #left-col4, #left-col5, #left-col6, #right-col, #right-col0, #bottom-col, #top-col').each(function(){
            $(this).sortable({
                // connect left and right containers
                connectWith: '.cat__core__sortable',
                tolerance: 'pointer',
                scroll: true,

                // set initial order from localStorage
                create: function () {

                    var that = $(this),
                        id = $(this).attr('id'),
                        orderLs = localStorage.getItem('order-' + id);

                    if (orderLs) {
                        var order = orderLs.split(',');

                        $.each(order, function(key, val){
                            var el = $('[order-id=' + val + ']');
                            that.append(el);
                        });
                    }

                },

                // save order state on order update to localStorage
                update: function () {
                    var orderArray = $(this).sortable('toArray', {attribute: 'order-id'}),
                        prefix = $(this).attr('id');

                    localStorage.setItem('order-' + prefix, orderArray);
                },

                // handler
                handle: ".card-header"
            });
        });

        ///////////////////////////////////////////////////////////
        // reset dashboard
        $('.reset-button').on('click', function(){
            localStorage.removeItem('order-left-col');
            localStorage.removeItem('order-right-col');
            localStorage.removeItem('order-bottom-col');
            setTimeout(function () {
                location.reload();
            }, 500)
        });

        ///////////////////////////////////////////////////////////
        // card controls
        $('.cat__core__sortable__collapse, .cat__core__sortable__uncollapse').on('click', function(){
            $(this).closest('.card').toggleClass('cat__core__sortable__collapsed');
        });
        $('.cat__core__sortable__close').on('click', function(){
            $(this).closest('.card').remove();
            $('.tooltip').remove();
        });

        // header double click
        $('.cat__core__sortable .card-header').on('dblclick', function() {
            $(this).closest('.card').toggleClass('cat__core__sortable__collapsed');
        });

        ///////////////////////////////////////////////////////////
        // custom scroll
        if (!('ontouchstart' in document.documentElement) && jQuery().jScrollPane) {
            $('.custom-scroll').each(function() {
                $(this).jScrollPane({
                    contentWidth: '100%',
                    autoReinitialise: true,
                    autoReinitialiseDelay: 100
                });
                var api = $(this).data('jsp'),
                        throttleTimeout;
                $(window).bind('resize', function() {
                    if (!throttleTimeout) {
                        throttleTimeout = setTimeout(function() {
                            api.reinitialise();
                            throttleTimeout = null;
                        }, 50);
                    }
                });
            });
        }

    } );

</script>
<!-- END: page scripts -->