
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">
<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <span class="text-muted">Administration ·</span>
        <strong>SUKET</strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Daftar Penggunaan Surat Keterangan (SUKET)</strong>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-hover nowrap" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Wilayah</th>
                            <th>Jumlah Suket yang digunakan</th>
                            <th>Action</th>
                        </tr>
                        </thead >
                        <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama Wilayah</th>
                            <th>Jumlah Suket yang digunakan</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div> 
        </div>
    </div>
</section>
<div class="modal fade" id="merge_modal" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Data Suket Pilkada</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="form-1" name="form-1" method="POST">
            <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" style="display: none"> 
            <input type="hidden" name="act" id="act" value="" style="display: none"> 
            <div class="modal-body">
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Nama Wilayah</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="kode_wilayah" 
                                            name="kode_wilayah">
                                        <option value="">Choose</option>    
                                        {list_provinces}
                                        {list_regency}
                            </select>
                        </div>
                </div> 
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Jumlah</label>
                        <div class="col-md-9">
                            <input type="number" class="form-control" placeholder="Jumlah Suket" id="jumlah" name="jumlah" value="">
                        </div>
                </div>          
            </div>
            <div class="modal-footer">
                <button type="button" class="btn pointer" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary pull-right pointer" >Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- END: tables/datatables -->
<!-- START: page scripts -->
<script>
    jQuery(document).ready(function($) {
        $('.select2').select2();
    });

    $(function(){
         var baseUrl = '{base_url}';  

         var table =   
         $('#data-table').DataTable({
                processing: true,
                destroy:true,
                serverSide: true,
                responsive: true,
                autoFill: true,
                colReorder: true,
                keys: true,
                rowReorder: true,
                columnDefs: [
                    { "width": "10%", "targets": 0 },
                    { className: "text-right col-with-icon", "targets": [ 2 ] },
                    { className: "text-center col-with-icon", "targets": [ 3 ] },
                ],
                ajax: {
                    url: baseUrl+"/json_list",
                    type:'POST',
                }
        });  
    });

    $('#form-1').validate({
        submit: {
            settings: {
                inputContainer: '.form-group',
                errorListClass: 'form-control-error',
                errorClass: 'has-danger'
            },
            callback: {
                onBeforeSubmit: function (node) {
                    NProgress.start();    
                },
                onSubmit: function (node) {

                    $.ajax({
                        url: '{base_url}/forms_submit',
                        type: 'POST',
                        dataType: 'json',
                        data: $('#form-1').serialize() ,
                    })
                    .done(function(data) {
                        NProgress.done();
                        if(data.status==true){
                            
                            $.notify({
                            title: '<strong>Success!</strong>',
                            message: data.reason
                            },{
                                type: 'primary'
                            });
                            
                             $('#merge_modal').modal('hide');
                             $("#jumlah").val('');
                             $('#kode_wilayah').val(null).trigger('change');
                            table.ajax.reload( null, false );
                        }else{
                            $.notify(data.reason);
                        }          
                    })
                    .fail(function() {
                        NProgress.done();
                        $.notify("Fail Save Data, Please check your connections...");
                    });
                    
                },
                onError: function (error) {
                    $.notify("Fail, Please Check your input...");
                }

            }
        },
        debug: true

    });

    function detail_data(id,idx){

    var baseUrl = '{base_url}';  
        
        $.ajax({
            url: baseUrl+"/detail_data",
            type: 'POST',
            dataType: 'json',
            data: {id:id, idx:idx },
        })
        .done(function(data) {
                $("#jumlah").val(data.jumlah);
                $('#kode_wilayah').val(idx).trigger('change');
                
        })
        .fail(function(data) {
                $("#jumlah").val('');
                $('#kode_wilayah').val(null).trigger('change');
        });
    }
</script>
<!-- END: page scripts -->