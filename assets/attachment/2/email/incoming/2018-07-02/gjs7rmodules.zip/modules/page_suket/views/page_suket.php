
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">
<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <span class="text-muted">Pemilih ·</span>
        <strong>SUKET <a href="{base_url}/download_suket">(Permendagri Mengenai Suket) <i class="fa fa-arrow-circle-down"></i> </a>.
            <a href="{base_url}/download_suket_surat_edaran">(Surat Edaran Mengenai Suket) <i class="fa fa-arrow-circle-down"></i> </a></strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Daftar Penggunaan Surat Keterangan (SUKET) </strong>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-hover nowrap" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Wilayah</th>
                            <th>Jumlah Suket yang digunakan</th>
                        </tr>
                        </thead >
                        <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama Wilayah</th>
                            <th>Jumlah Suket yang digunakan</th>
                        </tr>
                        </tfoot>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div> 
        </div>
    </div>
</section>
<!-- END: tables/datatables -->
<!-- START: page scripts -->
<script>
    jQuery(document).ready(function($) {
        $('.select2').select2();
    });

    $(function(){
         var baseUrl = '{base_url}';  

         var table =   
         $('#data-table').DataTable({
                processing: true,
                destroy:true,
                serverSide: true,
                responsive: true,
                autoFill: true,
                colReorder: true,
                keys: true,
                rowReorder: true,
                columnDefs: [
                    { "width": "10%", "targets": 0 },
                    { className: "text-right col-with-icon", "targets": [ 2 ] },
                ],
                ajax: {
                    url: baseUrl+"/json_list",
                    type:'POST',
                }
        });  
    });
</script>
<!-- END: page scripts -->