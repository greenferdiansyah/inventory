<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_admin_users extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY userid";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (`userid` like '%$search%' OR `first_name` like '%$search%' OR `last_name` like '%$search%'

			OR `userlevel` like '%$search%' OR `status` like '%$search%' )";
		}

		$sql		= " SELECT userid, first_name, last_name, userlevel, `status`, id
						FROM m_user
						WHERE is_deleted='0'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	function detail_data($id){
		$this->db->query("SET sql_mode=''");
		$this->db->select('id, userid, first_name, last_name, userlevel, status, position, email, phone, fail_login, 
						JSON_UNQUOTE(JSON_EXTRACT(group_member,"$.assigned_group")) AS assigned_group , 
						JSON_UNQUOTE(JSON_EXTRACT(group_member,"$.assigned_support_organization")) AS assigned_support_organization , 
						JSON_UNQUOTE(JSON_EXTRACT(group_member,"$.assigned_support_company")) AS assigned_support_company ');
		$query = $this->db->get_where('m_user', array('id' => $id));

		$data = $query->result_array();
		
		return $data;

	}

	function update_status($id,$status,$upd,$lup){

		$data = array('status' => $status,
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_user', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}

	function deleted_item($id,$status,$upd,$lup){

		$data = array('is_deleted' => '1',
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_user', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been deleted');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Deleted Data');
		}

		return $result;

	}


	function add($userid,$first_name,$last_name,$password,$userlevel,
							$position,$phone,$email,$status,$upd,$lup){

		$password =  password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);

		$data = array(
		   'userid' => $userid,
		   'first_name' => $first_name,
		   'last_name' => $last_name,
		   'password'  => $password,
		   'userlevel' => $userlevel,
		   'position' => $position,
		   'phone' => $phone,
		   'email' => $email,
		   'status' => $status, 
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('m_user', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit($act,$id,$userid,$first_name,$last_name,$password,$userlevel,
							$position,$phone,$email,$status,$upd,$lup){
		
		$data = array('userid' => $userid,
					  'first_name' => $first_name,
					  'last_name' => $last_name,
					  'userlevel' => $userlevel,
					  'position' => $position,
					  'phone' => $phone,
					  'email' => $email,
					  'status' => $status,
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_user', $data); 

		if($update){
			if($password!=NULL){

				$password =  password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);

				$data_pass = array('password'  => $password);

				$this->db->where('id', $id );

				$update	= $this->db->update('m_user', $data_pass); 

				$result = array('status'=> 'success', 'reason'=> 'Data User & Password has been changed');

			}else{
				$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
			}
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}

}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
