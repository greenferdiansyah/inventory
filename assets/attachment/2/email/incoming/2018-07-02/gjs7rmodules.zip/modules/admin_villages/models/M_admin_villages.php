<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_admin_villages extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY a.village_id";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (a.village_id like '%$search%' OR d.`name` like '%$search%' OR c.`name` like '%$search%' OR b.`name` like '%$search%' OR a.`name` like '%$search%' )";
		}

		$sql		= " SELECT a.village_id, d.`name` AS provinsi, c.`name` AS kota_kab, b.`name` AS kecamatan, a.`name` AS desa
						FROM `m_area_villages` a
						LEFT JOIN m_area_districts b ON a.`district_id`=b.`district_id`
						LEFT JOIN m_area_regencies c ON b.`regency_id`=c.`regency_id`
						LEFT JOIN m_area_provinces d ON c.`province_id`=d.`province_id`
						WHERE a.`is_deleted`=0
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	function detail_data($id){

		$sql ="SELECT a.village_id, b.`district_id`, c.`regency_id`, d.`province_id`, a.`name` AS desa
			FROM `m_area_villages` a
			LEFT JOIN m_area_districts b ON a.`district_id`=b.`district_id`
			LEFT JOIN m_area_regencies c ON b.`regency_id`=c.`regency_id`
			LEFT JOIN m_area_provinces d ON c.`province_id`=d.`province_id`
			WHERE a.village_id='$id'";

		$query = $this->db->query($sql);	
		$data = $query->result_array();
		
		return $data[0];

	}

	function deleted_item($id,$status,$upd,$lup){

		$data = array('is_deleted' => '1',
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('district_id', $id );

		$update	= $this->db->update('m_area_districts', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been deleted');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Deleted Data');
		}

		return $result;

	}


	function add($act,$id,$province_id,$regency_id,$district_id,$nama_wilayah,$upd,$lup){

		$data = array(
		   'village_id' => $id,	
		   'district_id' => $district_id,
		   'name' => $nama_wilayah,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('m_area_villages', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit($act,$id,$province_id,$regency_id,$district_id,$nama_wilayah,$upd,$lup){
		
		$data = array( 'district_id' => $district_id,
					   'name' => $nama_wilayah,
					   'updated' => $upd,
					   'updated_at' => $lup
					);

		$this->db->where('village_id', $id );

		$update	= $this->db->update('m_area_villages', $data); 
		
		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}

	function find_regency($q,$province_id){

          $this->db->select('regency_id, name');
          $this->db->like('name', $q);
          $query = $this->db->get_where('m_area_regencies', array('province_id' => $province_id, 'is_deleted' => '0' ));

          $data = $query->result_array();

          return $data;
     

	}

	function find_district($q,$regency_id){

          $this->db->select('district_id, name');
          $this->db->like('name', $q);
          $query = $this->db->get_where('m_area_districts', array('regency_id' => $regency_id, 'is_deleted' => '0' ));

          $data = $query->result_array();

          return $data;
     

	}

}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
