<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_pelanggaran_pidana extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%' OR a.kode_wilayah like '%$search%' OR a.pemohon like '%$search%'
			OR a.termohon like '%$search%' OR a.kategori_sengketa like '%$search%' OR a.obyek_sengketa like '%$search%' 
			OR a.keterangan like '%$search%' )";
		}

		$sql		= " SELECT b.`name`, a.`kode_wilayah`, a.`pemohon`,a.`termohon`,a.`kategori_sengketa`,a.`obyek_sengketa`,a.`keterangan`,a.id
						FROM trans_sengketa a
						LEFT JOIN m_area_provinces b ON a.`kode_wilayah`=b.`province_id` COLLATE utf8_unicode_ci
						WHERE LENGTH(a.`kode_wilayah`)=2 AND a.`kode_wilayah`=b.`province_id` COLLATE utf8_unicode_ci AND a.kategori_pelanggaran='Pidana Pemilu'
						$where_clause
						UNION
						SELECT b.`name`, a.`kode_wilayah`, a.`pemohon`,a.`termohon`,a.`kategori_sengketa`,a.`obyek_sengketa`,a.`keterangan`,a.id
						FROM trans_sengketa a
						LEFT JOIN m_area_regencies b ON a.`kode_wilayah`=b.regency_id COLLATE utf8_unicode_ci
						WHERE LENGTH(a.`kode_wilayah`)=4 AND a.`kode_wilayah`=b.`regency_id` COLLATE utf8_unicode_ci AND a.kategori_pelanggaran='Pidana Pemilu'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	function detail_data($id){
		$this->db->query("SET sql_mode=''");
		$this->db->select('id, kode_wilayah, pemohon, termohon, kategori_sengketa, obyek_sengketa, keterangan');
		$query = $this->db->get_where('trans_sengketa', array('id' => $id));

		$data = $query->result_array();
		
		return $data[0];

	}

	function add($act,$id,$province_id,$regency_id,$periode,$pemohon,
						$termohon,$kategori_pelanggaran,$kategori_sengketa,$obyek_sengketa,$keterangan,$upd,$lup){

		
		if($regency_id!=''){
			$kode_wilayah = $regency_id;
		}else{
			$kode_wilayah = $province_id;
		}
		$data = array(
		   'kode_wilayah' => $kode_wilayah,	
		   'periode' => $periode,
		   'pemohon' => $pemohon,
		   'termohon' => $termohon,
		   'kategori_pelanggaran' => $kategori_pelanggaran,
		   'kategori_sengketa' => $kategori_sengketa,
		   'obyek_sengketa' => $obyek_sengketa,
		   'keterangan' => $keterangan,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('trans_sengketa', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit($act,$id,$province_id,$regency_id,$periode,$pemohon,
						$termohon,$kategori_pelanggaran,$kategori_sengketa,$obyek_sengketa,$keterangan,$upd,$lup){
		if($regency_id!=''){
			$kode_wilayah = $regency_id;
		}else{
			$kode_wilayah = $province_id;
		}
		$data = array('kode_wilayah' => $kode_wilayah,	
					  'periode' => $periode,
					  'pemohon' => $pemohon,
					  'termohon' => $termohon,
					  'kategori_pelanggaran' => $kategori_pelanggaran,
					  'kategori_sengketa' => $kategori_sengketa,
					  'obyek_sengketa' => $obyek_sengketa,
					  'keterangan' => $keterangan,
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('trans_sengketa', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
