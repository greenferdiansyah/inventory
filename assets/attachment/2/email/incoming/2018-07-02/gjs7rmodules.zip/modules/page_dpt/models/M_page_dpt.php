<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_dpt extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY b.name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%')";
		}

		$sql		= " SELECT b.`name`,
						a.`sum_tps` AS sum_tps ,
						a.`sum_man` AS sum_man,
						a.`sum_woman` AS sum_woman,
						a.`sum_man`+a.`sum_woman` AS sum_gender, 
						a.dif_1 AS dif_1,
						a.dif_2 AS dif_2,
						a.dif_3 AS dif_3,
						a.dif_4 AS dif_4,
						a.dif_5 AS dif_5,
						a.dif_1+a.dif_2+a.dif_3+a.dif_4+a.dif_5 AS sum_dif, a.id_provinces
						FROM m_dpt_provinces a
						LEFT JOIN m_area_provinces b ON a.id_provinces=b.province_id
						WHERE a.is_deleted='0'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	public function list_data_regency($length,$start,$search,$order,$dir,$find_id){
		
		$order_by="ORDER BY b.name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%')";
		}

		$sql		= " SELECT b.`name`,
						a.`sum_tps` AS sum_tps ,
						a.`sum_man` AS sum_man,
						a.`sum_woman` AS sum_woman,
						a.`sum_man`+a.`sum_woman` AS sum_gender, 
						a.dif_1 AS dif_1,
						a.dif_2 AS dif_2,
						a.dif_3 AS dif_3,
						a.dif_4 AS dif_4,
						a.dif_5 AS dif_5,
						a.dif_1+a.dif_2+a.dif_3+a.dif_4+a.dif_5 AS sum_dif, a.id_regencies
						FROM m_dpt_regencies a
						LEFT JOIN m_area_regencies b ON a.id_regencies=b.regency_id
						WHERE a.is_deleted='0' AND b.province_id='$find_id'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	public function list_data_district($length,$start,$search,$order,$dir,$find_id){
		
		$order_by="ORDER BY b.name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%')";
		}

		$sql		= " SELECT b.`name`,
						a.`sum_tps` AS sum_tps ,
						a.`sum_man` AS sum_man,
						a.`sum_woman` AS sum_woman,
						a.`sum_man`+a.`sum_woman` AS sum_gender, 
						a.dif_1 AS dif_1,
						a.dif_2 AS dif_2,
						a.dif_3 AS dif_3,
						a.dif_4 AS dif_4,
						a.dif_5 AS dif_5,
						a.dif_1+a.dif_2+a.dif_3+a.dif_4+a.dif_5 AS sum_dif, a.id_district
						FROM m_dpt_district a
						LEFT JOIN m_area_districts b ON a.id_district=b.district_id
						WHERE a.is_deleted='0' AND b.regency_id='$find_id'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	public function list_data_villages($length,$start,$search,$order,$dir,$find_id){
		
		$order_by="ORDER BY b.name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%')";
		}

		$sql		= " SELECT b.`name`,
						a.`sum_tps` AS sum_tps ,
						a.`sum_man` AS sum_man,
						a.`sum_woman` AS sum_woman,
						a.`sum_man`+a.`sum_woman` AS sum_gender, 
						a.dif_1 AS dif_1,
						a.dif_2 AS dif_2,
						a.dif_3 AS dif_3,
						a.dif_4 AS dif_4,
						a.dif_5 AS dif_5,
						a.dif_1+a.dif_2+a.dif_3+a.dif_4+a.dif_5 AS sum_dif
						FROM m_dpt_villages a
						LEFT JOIN m_area_villages b ON a.id_villages=b.village_id COLLATE utf8_unicode_ci
						WHERE a.is_deleted='0' AND b.district_id='$find_id'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	public function find_province_name($id_provinces){

		$sql = "SELECT `name` FROM m_area_provinces WHERE is_deleted=0 AND province_id='$id_provinces'";
		$query = $this->db->query($sql);

		$result = $query->result_array();

		return $result[0]['name'];
	}

	public function find_regency_name($id_regency){

		$sql = "SELECT a.name AS regency , b.name AS province
				FROM
				m_area_regencies a, m_area_provinces b
				WHERE a.regency_id='$id_regency' AND a.province_id=b.province_id";
		$query = $this->db->query($sql);

		$result = $query->result_array();
		return $result;
	}

	public function find_district_name($id_district){

		$sql = "SELECT a.name AS regency , b.name AS province, c.name AS district
				FROM
				m_area_regencies a, m_area_provinces b, m_area_districts c
				WHERE c.district_id='$id_district' AND a.province_id=b.province_id AND c.regency_id=a.regency_id";
		$query = $this->db->query($sql);

		$result = $query->result_array();
		return $result;
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
