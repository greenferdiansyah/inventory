<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Q_login extends CI_Model {

	function check_login($userid,$password){

		$this->db->select('userid, first_name, last_name, password , userlevel, position, email, phone');
		$query = $this->db->get_where('m_user', array('userid' => $userid, 'status' => '1', 'is_deleted' => '0'));

		$data = $query->result_array();
		
		if(isset($data[0]['userid'])){
			if (password_verify($password, $data[0]['password'])) {
				$result = array("status"	=> true,
							"userid"		=> $data[0]['userid'],
							"first_name"	=> $data[0]['first_name'],
							"last_name"		=> $data[0]['last_name'],
							"group_member"	=> '',
							"userlevel"		=> $data[0]['userlevel'],
							"position"		=> $data[0]['position'],
							"email"			=> $data[0]['email'],
							"phone"			=> $data[0]['phone'],
							"foto"			=> ''
							);
			}else{
				$result = array("status"	=> false,
							"userid"		=> '',
							"first_name"	=> '',
							"last_name"		=> '',
							"group_member"	=> '',
							"userlevel"		=> '',
							"position"		=> '',
							"email"			=> '',
							"phone"			=> '',
							"foto"			=> ''
							);
			}
		}else{
				$result = array("status"	=> false,
							"userid"		=> '',
							"first_name"	=> '',
							"last_name"		=> '',
							"group_member"	=> '',
							"userlevel"		=> '',
							"position"		=> '',
							"email"			=> '',
							"phone"			=> '',
							"foto"			=> ''
							);
		}	
		
		return $result;
	}

	function check_tenant(){
		
		$this->db->select('favicon, logo, title ');
		$query = $this->db->get('master_setting');

		$data = $query->result_array();

		if(isset($data[0])){
				$result = array("status" => true, "favicon" => $data[0]['favicon'] , "logo" => $data[0]['logo'], "title" => $data[0]['title']);
		}else{
				$result = array("status" => false );
		}

		return $result;
	}

}

/* End of file q_login.php */
/* Location: ./application/models/q_login.php */
