<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_hasil_psu extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY a.kode_wilayah,a.no_urut";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" WHERE (b.name like '%$search%' OR c.name like '%$search%' 
			OR a.no_urut like '%$search%' OR a.kepala_daerah like '%$search%' OR a.wakil_kepala_daerah like '%$search%')";
		}

		$sql		= "SELECT
					  CASE
					    WHEN LENGTH(a.kode_wilayah) = 2
					    THEN c.name
					    WHEN LENGTH(a.kode_wilayah) = 4
					    THEN b.name
					  END nama_wil,
					  CASE
					    WHEN LENGTH(a.kode_wilayah) = 2
					    THEN 'Pemilihan Gubernur'
					    WHEN LENGTH(a.kode_wilayah) = 4
					    AND LOWER(b.name) LIKE 'kabupaten%'
					    THEN 'Pemilihan Bupati'
					    WHEN LENGTH(a.kode_wilayah) = 4
					    AND LOWER(b.name) LIKE 'kota%'
					    THEN 'Pemilihan Walikota'
					  END tipe_pemilihan,
					  a.no_urut,
					  a.kepala_daerah,
					  a.wakil_kepala_daerah,
					  a.parpol_pengusung,
					  d.jml_suara_sah,
					  f.total
					FROM
					  m_paslon a
					  LEFT JOIN m_area_regencies b
					    ON a.kode_wilayah = b.regency_id COLLATE utf8_unicode_ci
					  LEFT JOIN m_area_provinces c
					    ON a.kode_wilayah = c.province_id COLLATE utf8_unicode_ci
					  INNER JOIN trans_js_v2 d
					    ON d.id_paslon = a.id
					  INNER JOIN trans_suara e
					    ON e.kode_wilayah=a.kode_wilayah AND e.id=d.id_trans_suara AND e.is_psu=1
					  INNER JOIN (
					    SELECT id_trans_suara, SUM(jml_suara_sah) total FROM trans_js_v2 GROUP BY id_trans_suara		
					  )  f ON f.id_trans_suara=e.id
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
