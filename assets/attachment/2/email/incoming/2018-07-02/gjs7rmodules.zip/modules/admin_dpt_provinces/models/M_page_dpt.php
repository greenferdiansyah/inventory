<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_dpt extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY b.name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%')";
		}

		$sql		= " SELECT b.`name`,
						a.`sum_tps` AS sum_tps ,
						a.`sum_man` AS sum_man,
						a.`sum_woman` AS sum_woman,
						a.`sum_man`+a.`sum_woman` AS sum_gender, 
						a.dif_1 AS dif_1,
						a.dif_2 AS dif_2,
						a.dif_3 AS dif_3,
						a.dif_4 AS dif_4,
						a.dif_5 AS dif_5,
						a.dif_1+a.dif_2+a.dif_3+a.dif_4+a.dif_5 AS sum_dif, a.id_provinces
						FROM m_dpt_provinces a
						LEFT JOIN m_area_provinces b ON a.id_provinces=b.province_id
						WHERE a.is_deleted='0'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	public function list_data_regency($length,$start,$search,$order,$dir,$find_id){
		
		$order_by="ORDER BY b.name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%')";
		}

		$sql		= " SELECT b.`name`,
						a.`sum_tps` AS sum_tps ,
						a.`sum_man` AS sum_man,
						a.`sum_woman` AS sum_woman,
						a.`sum_man`+a.`sum_woman` AS sum_gender, 
						a.dif_1 AS dif_1,
						a.dif_2 AS dif_2,
						a.dif_3 AS dif_3,
						a.dif_4 AS dif_4,
						a.dif_5 AS dif_5,
						a.dif_1+a.dif_2+a.dif_3+a.dif_4+a.dif_5 AS sum_dif, a.id_regencies
						FROM m_dpt_regencies a
						LEFT JOIN m_area_regencies b ON a.id_regencies=b.regency_id
						WHERE a.is_deleted='0' AND b.province_id='$find_id'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	public function list_data_district($length,$start,$search,$order,$dir,$find_id){
		
		$order_by="ORDER BY b.name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%')";
		}

		$sql		= " SELECT b.`name`,
						a.`sum_tps` AS sum_tps ,
						a.`sum_man` AS sum_man,
						a.`sum_woman` AS sum_woman,
						a.`sum_man`+a.`sum_woman` AS sum_gender, 
						a.dif_1 AS dif_1,
						a.dif_2 AS dif_2,
						a.dif_3 AS dif_3,
						a.dif_4 AS dif_4,
						a.dif_5 AS dif_5,
						a.dif_1+a.dif_2+a.dif_3+a.dif_4+a.dif_5 AS sum_dif, a.id_district
						FROM m_dpt_district a
						LEFT JOIN m_area_districts b ON a.id_district=b.district_id
						WHERE a.is_deleted='0' AND b.regency_id='$find_id'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	public function list_data_villages($length,$start,$search,$order,$dir,$find_id){
		
		$order_by="ORDER BY b.name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%')";
		}

		$sql		= " SELECT b.`name`,
						a.`sum_tps` AS sum_tps ,
						a.`sum_man` AS sum_man,
						a.`sum_woman` AS sum_woman,
						a.`sum_man`+a.`sum_woman` AS sum_gender, 
						a.dif_1 AS dif_1,
						a.dif_2 AS dif_2,
						a.dif_3 AS dif_3,
						a.dif_4 AS dif_4,
						a.dif_5 AS dif_5,
						a.dif_1+a.dif_2+a.dif_3+a.dif_4+a.dif_5 AS sum_dif, a.id_villages
						FROM m_dpt_villages a
						LEFT JOIN m_area_villages b ON a.id_villages=b.village_id COLLATE utf8_unicode_ci
						WHERE a.is_deleted='0' AND b.district_id='$find_id'
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	public function find_province_name($id_provinces){

		$sql = "SELECT `name` FROM m_area_provinces WHERE is_deleted=0 AND province_id='$id_provinces'";
		$query = $this->db->query($sql);

		$result = $query->result_array();

		return $result[0]['name'];
	}

	public function find_regency_name($id_regency){

		$sql = "SELECT a.name AS regency , b.name AS province
				FROM
				m_area_regencies a, m_area_provinces b
				WHERE a.regency_id='$id_regency' AND a.province_id=b.province_id";
		$query = $this->db->query($sql);

		$result = $query->result_array();
		return $result;
	}

	public function find_district_name($id_district){

		$sql = "SELECT a.name AS regency , b.name AS province, c.name AS district
				FROM
				m_area_regencies a, m_area_provinces b, m_area_districts c
				WHERE c.district_id='$id_district' AND a.province_id=b.province_id AND c.regency_id=a.regency_id";
		$query = $this->db->query($sql);

		$result = $query->result_array();
		return $result;
	}

	function detail_data($id){
		$this->db->query("SET sql_mode=''");
		$this->db->select('id, id_provinces, sum_citizen, sum_asn, sum_tps, sum_man, sum_woman, dif_1, dif_2, dif_3, dif_4, dif_5, periode');
		$query = $this->db->get_where('m_dpt_provinces', array('id_provinces' => $id));

		$data = $query->result_array();
		
		return $data[0];

	}

	function add($act,$id_provinces,$periode,$sum_citizen,$sum_asn,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup){

		$data = array(
		   'id_provinces' => $id_provinces,	
		   'periode' => $periode,
		   'sum_citizen' => $sum_citizen,
		   'sum_asn' => $sum_asn,
		   'sum_tps' => $sum_tps,
		   'sum_man' => $sum_man,
		   'sum_woman' => $sum_woman,
		   'dif_1' => $dif_1,
		   'dif_2' => $dif_2,
		   'dif_3' => $dif_3,
		   'dif_4' => $dif_4,
		   'dif_5' => $dif_5,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('m_dpt_provinces', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit($act,$id,$id_provinces,$periode,$sum_citizen,$sum_asn,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup){
		
		$data = array( 'id_provinces' => $id_provinces,	
					   'periode' => $periode,
					   'sum_citizen' => $sum_citizen,
					   'sum_asn' => $sum_asn,
					   'sum_tps' => $sum_tps,
					   'sum_man' => $sum_man,
					   'sum_woman' => $sum_woman,
					   'dif_1' => $dif_1,
					   'dif_2' => $dif_2,
					   'dif_3' => $dif_3,
					   'dif_4' => $dif_4,
					   'dif_5' => $dif_5,
					   'created' => $upd,
					   'created_at' => $lup,
					   'updated' => $upd,
					   'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_dpt_provinces', $data); 
		
		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}

	function detail_data_regency($id){
		$this->db->query("SET sql_mode=''");
		$this->db->select('id, id_regencies, sum_tps, sum_man, sum_woman, dif_1, dif_2, dif_3, dif_4, dif_5, periode');
		$query = $this->db->get_where('m_dpt_regencies', array('id_regencies' => $id));

		$data = $query->result_array();
		
		return $data[0];

	}

	function add_dpt_regency($act,$id_regencies,$periode,$sum_citizen,$sum_asn,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup){

		$data = array(
		   'id_regencies' => $id_regencies,	
		   'periode' => $periode,
		   'sum_citizen' => $sum_citizen,
		   'sum_asn' => $sum_asn,
		   'sum_tps' => $sum_tps,
		   'sum_man' => $sum_man,
		   'sum_woman' => $sum_woman,
		   'dif_1' => $dif_1,
		   'dif_2' => $dif_2,
		   'dif_3' => $dif_3,
		   'dif_4' => $dif_4,
		   'dif_5' => $dif_5,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('m_dpt_regencies', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit_dpt_regency($act,$id,$id_regencies,$periode,$sum_citizen,$sum_asn,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup){
		
		$data = array( 'id_regencies' => $id_regencies,	
					   'periode' => $periode,
					   'sum_citizen' => $sum_citizen,
		   			   'sum_asn' => $sum_asn,
					   'sum_tps' => $sum_tps,
					   'sum_man' => $sum_man,
					   'sum_woman' => $sum_woman,
					   'dif_1' => $dif_1,
					   'dif_2' => $dif_2,
					   'dif_3' => $dif_3,
					   'dif_4' => $dif_4,
					   'dif_5' => $dif_5,
					   'created' => $upd,
					   'created_at' => $lup,
					   'updated' => $upd,
					   'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_dpt_regencies', $data); 
		
		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}

	function detail_data_district($id){
		$this->db->query("SET sql_mode=''");
		$this->db->select('id, id_district, sum_tps, sum_man, sum_woman, dif_1, dif_2, dif_3, dif_4, dif_5, periode');
		$query = $this->db->get_where('m_dpt_district', array('id_district' => $id));

		$data = $query->result_array();
		
		return $data[0];

	}

	function add_dpt_district($act,$id_district,$periode,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup){

		$data = array(
		   'id_district' => $id_district,	
		   'periode' => $periode,
		   'sum_tps' => $sum_tps,
		   'sum_man' => $sum_man,
		   'sum_woman' => $sum_woman,
		   'dif_1' => $dif_1,
		   'dif_2' => $dif_2,
		   'dif_3' => $dif_3,
		   'dif_4' => $dif_4,
		   'dif_5' => $dif_5,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('m_dpt_district', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit_dpt_district($act,$id,$id_district,$periode,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup){
		
		$data = array( 'id_district' => $id_district,	
					   'periode' => $periode,
					   'sum_tps' => $sum_tps,
					   'sum_man' => $sum_man,
					   'sum_woman' => $sum_woman,
					   'dif_1' => $dif_1,
					   'dif_2' => $dif_2,
					   'dif_3' => $dif_3,
					   'dif_4' => $dif_4,
					   'dif_5' => $dif_5,
					   'created' => $upd,
					   'created_at' => $lup,
					   'updated' => $upd,
					   'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_dpt_district', $data); 
		
		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}

	function detail_data_villages($id){
		$this->db->query("SET sql_mode=''");
		$this->db->select('id, id_villages, sum_tps, sum_man, sum_woman, dif_1, dif_2, dif_3, dif_4, dif_5, periode');
		$query = $this->db->get_where('m_dpt_villages', array('id_villages' => $id));

		$data = $query->result_array();
		
		return $data[0];

	}

	function add_dpt_villages($act,$id_villages,$periode,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup){

		$data = array(
		   'id_villages' => $id_villages,	
		   'periode' => $periode,
		   'sum_tps' => $sum_tps,
		   'sum_man' => $sum_man,
		   'sum_woman' => $sum_woman,
		   'dif_1' => $dif_1,
		   'dif_2' => $dif_2,
		   'dif_3' => $dif_3,
		   'dif_4' => $dif_4,
		   'dif_5' => $dif_5,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('m_dpt_villages', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit_dpt_villages($act,$id,$id_villages,$periode,$sum_tps,$sum_man,$sum_woman,
						$dif_1,$dif_2,$dif_3,$dif_4,$dif_5,$upd,$lup){
		
		$data = array( 'id_villages' => $id_villages,	
					   'periode' => $periode,
					   'sum_tps' => $sum_tps,
					   'sum_man' => $sum_man,
					   'sum_woman' => $sum_woman,
					   'dif_1' => $dif_1,
					   'dif_2' => $dif_2,
					   'dif_3' => $dif_3,
					   'dif_4' => $dif_4,
					   'dif_5' => $dif_5,
					   'created' => $upd,
					   'created_at' => $lup,
					   'updated' => $upd,
					   'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_dpt_villages', $data); 
		
		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
