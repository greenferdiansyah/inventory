<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page_pelaporan extends CI_Controller {

	public function index(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
				
			$this->load->library('page_render');
			
			$data=array(
				'page_content' 				=> $page,
				'base'						=> base_url(),
				'base_url'					=> base_url().$page,
				"tenant_id"					=> $this->session->userdata('tenant_id')
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list(){
			
			$parent_page	=  $this->uri->segment(1);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_pelaporan');
			
			$data =  $this->m_page_pelaporan->list_data($length,$start,$search,$order,$dir);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
			$iconAction = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-warning btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['img_laporan']."')>
								<i class='icmn-eye'></i>
							  </a>";
				$output['data'][]=array(
					$nomor_urut, 
					$row['tanggal'],
					$row['jam'],
					$row['lokasi'],
					$row['keterangan'],
					$iconAction
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
