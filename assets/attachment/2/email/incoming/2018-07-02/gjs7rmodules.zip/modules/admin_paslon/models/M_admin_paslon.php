<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_admin_paslon extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY area_name,no_urut";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (b.name like '%$search%' OR a.no_urut like '%$search%' OR a.kepala_daerah like '%$search%' 
			OR a.gender_kd like '%$search%' OR a.pekerjaan_kd like '%$search%' OR a.wakil_kepala_daerah like '%$search%' 
			OR a.gender_wakil like '%$search%' OR a.pekerjaan_wakil like '%$search%' OR a.jenis_calon like '%$search%'
			OR a.parpol_pengusung like '%$search%' OR a.status_penetapan like '%$search%' OR a.keterangan like '%$search%')";
		}

		$sql		= " SELECT b.name AS area_name,a.no_urut,a.kepala_daerah,a.gender_kd,a.pekerjaan_kd,
						a.`wakil_kepala_daerah`,a.`gender_wakil`,a.`pekerjaan_wakil`,a.`jenis_calon`,
						a.parpol_pengusung,a.`status_penetapan`,a.`keterangan`,a.id
						FROM
						m_paslon a 
						INNER JOIN m_area_provinces b ON a.kode_wilayah=b.province_id COLLATE utf8_unicode_ci AND a.is_deleted='0'
						WHERE LENGTH(a.`kode_wilayah`)=2
						$where_clause
						UNION 
						SELECT b.name AS area_name,a.no_urut,a.kepala_daerah,a.gender_kd,a.pekerjaan_kd,
						a.`wakil_kepala_daerah`,a.`gender_wakil`,a.`pekerjaan_wakil`,a.`jenis_calon`,
						a.parpol_pengusung,a.`status_penetapan`,a.`keterangan`,a.id
						FROM
						m_paslon a 
						INNER JOIN m_area_regencies b ON a.kode_wilayah=b.regency_id COLLATE utf8_unicode_ci AND a.is_deleted='0'
						WHERE LENGTH(a.`kode_wilayah`)=4
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	function detail_data($id){

		$sql ="SELECT * FROM m_paslon WHERE id='$id'";

		$query = $this->db->query($sql);	
		$data = $query->result_array();
		
		return $data[0];

	}

	function deleted_item($id,$status,$upd,$lup){

		$data = array('is_deleted' => '1',
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_paslon', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been deleted');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Deleted Data');
		}

		return $result;

	}


	function add($act,$id,$kode_wilayah,$periode,$is_petahana,$no_urut,$kepala_daerah,$gender_kd,$pekerjaan_kd,$wakil_kepala_daerah,
								$gender_wakil,$pekerjaan_wakil,$jenis_calon,$status_penetapan,$parpol_pengusung,$jml_kursi_ktp,$keterangan,$upd,$lup){

		$data = array(
		   	 "kode_wilayah" => $kode_wilayah,
             "periode" 	=> $periode,
             "is_petahana" 	=> $is_petahana,
             "no_urut" 	=> $no_urut,
             "kepala_daerah" => $kepala_daerah,
             "gender_kd" => $gender_kd,
             "pekerjaan_kd" => $pekerjaan_kd,
             "wakil_kepala_daerah" => $wakil_kepala_daerah,
             "gender_wakil" => $gender_wakil,
             "pekerjaan_wakil" => $pekerjaan_wakil,
             "jenis_calon" => $jenis_calon,
             "parpol_pengusung" => $parpol_pengusung,
             "status_penetapan" => $status_penetapan,
             "jml_kursi_ktp" => $jml_kursi_ktp,
             "keterangan" => $keterangan,
             "created" => $upd,
             "created_at" => $lup,
             "updated" => $upd,
             "updated_at" => $lup,
		);

		$insert = $this->db->insert('m_paslon', $data); 
		$insert_id = $this->db->insert_id();

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed', 'insert_id' => $insert_id);
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit($act,$id,$kode_wilayah,$periode,$is_petahana,$no_urut,$kepala_daerah,$gender_kd,$pekerjaan_kd,$wakil_kepala_daerah,
								$gender_wakil,$pekerjaan_wakil,$jenis_calon,$status_penetapan,$parpol_pengusung,$jml_kursi_ktp,$keterangan,$upd,$lup){
		
		$data = array(
					 "kode_wilayah" => $kode_wilayah,
					 "periode" 	=> $periode,
             		 "is_petahana" 	=> $is_petahana,
		             "no_urut" 	=> $no_urut,
		             "kepala_daerah" => $kepala_daerah,
		             "gender_kd" => $gender_kd,
		             "pekerjaan_kd" => $pekerjaan_kd,
		             "wakil_kepala_daerah" => $wakil_kepala_daerah,
		             "gender_wakil" => $gender_wakil,
		             "pekerjaan_wakil" => $pekerjaan_wakil,
		             "jenis_calon" => $jenis_calon,
		             "parpol_pengusung" => $parpol_pengusung,
		             "status_penetapan" => $status_penetapan,
		             "jml_kursi_ktp" => $jml_kursi_ktp,
		             "keterangan" => $keterangan,
		             "updated" => $upd,
		             "updated_at" => $lup,
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('m_paslon', $data); 
		
		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}

	function upload_kd($id,$file_img){

		if(isset($file_img)){
			$data = array("img_kd" => $file_img);

			$this->db->where('id', $id );

			$update	= $this->db->update('m_paslon', $data); 
		}
		
	}

	function upload_wakil($id,$file_img){
		if(isset($file_img)){
			$data = array("img_wakil" => $file_img);

			$this->db->where('id', $id );

			$update	= $this->db->update('m_paslon', $data); 
		}
	}

}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
