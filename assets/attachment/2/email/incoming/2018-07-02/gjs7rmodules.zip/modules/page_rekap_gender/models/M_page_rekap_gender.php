<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_rekap_gender extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir,$periode){

		$sql		= "SELECT 'Pemilihan Gubernur' AS pilkada, COUNT(c.kode_wilayah) AS jumlah_wilayah,
						IFNULL(SUM(CASE WHEN e.gender_kd ='L' THEN '1' ELSE '0' END ),0) AS jumlah_pria,
						IFNULL(SUM(CASE WHEN e.gender_kd ='P' THEN '1' ELSE '0' END),0) AS jumlah_wanita,
						IFNULL(SUM(CASE WHEN e.gender_wakil ='L' THEN '1' ELSE '0' END ),0) AS jumlah_wakil_pria,
						IFNULL(SUM(CASE WHEN e.gender_wakil ='P' THEN '1' ELSE '0' END),0) AS jumlah_wakil_wanita
						FROM trans_js_v2 a
						INNER JOIN (
						    SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						    FROM trans_js_v2
						    GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_provinces d ON c.kode_wilayah=d.province_id COLLATE utf8_unicode_ci
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						UNION
						SELECT 'Pemilihan Bupati' AS pilkada, COUNT(c.kode_wilayah) AS jumlah_wilayah,
						IFNULL(SUM(CASE WHEN e.gender_kd ='L' THEN '1' ELSE '0' END ),0) AS jumlah_pria,
						IFNULL(SUM(CASE WHEN e.gender_kd ='P' THEN '1' ELSE '0' END),0) AS jumlah_wanita,
						IFNULL(SUM(CASE WHEN e.gender_wakil ='L' THEN '1' ELSE '0' END ),0) AS jumlah_wakil_pria,
						IFNULL(SUM(CASE WHEN e.gender_wakil ='P' THEN '1' ELSE '0' END),0) AS jumlah_wakil_wanita
						FROM trans_js_v2 a
						INNER JOIN (
						    SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						    FROM trans_js_v2
						    GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_regencies d ON c.kode_wilayah=d.regency_id COLLATE utf8_unicode_ci AND LOWER(d.name) LIKE 'kabupaten%'
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'
						UNION
						SELECT 'Pemilihan Walikota' AS pilkada, COUNT(c.kode_wilayah) AS jumlah_wilayah,
						IFNULL(SUM(CASE WHEN e.gender_kd ='L' THEN '1' ELSE '0' END ),0) AS jumlah_pria,
						IFNULL(SUM(CASE WHEN e.gender_kd ='P' THEN '1' ELSE '0' END),0) AS jumlah_wanita,
						IFNULL(SUM(CASE WHEN e.gender_wakil ='L' THEN '1' ELSE '0' END ),0) AS jumlah_wakil_pria,
						IFNULL(SUM(CASE WHEN e.gender_wakil ='P' THEN '1' ELSE '0' END),0) AS jumlah_wakil_wanita
						FROM trans_js_v2 a
						INNER JOIN (
						    SELECT id_trans_suara, MAX(jml_suara_sah) jml_suara_sah
						    FROM trans_js_v2
						    GROUP BY id_trans_suara
						) b ON a.id_trans_suara = b.id_trans_suara AND a.jml_suara_sah = b.jml_suara_sah
						INNER JOIN trans_suara c ON a.id_trans_suara=c.id AND c.is_psu=0
						INNER JOIN m_area_regencies d ON c.kode_wilayah=d.regency_id COLLATE utf8_unicode_ci AND LOWER(d.name) LIKE 'kota%'
						INNER JOIN m_paslon e ON a.id_paslon=e.id AND e.periode='$periode'";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
