<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page_pelanggaran_pidana extends CI_Controller {

	public function index(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
				
			$this->load->library('page_render');
			$this->load->library('drop_down');

			$this->drop_down->select('province_id','name');
			$this->drop_down->from('m_area_provinces');
			$this->drop_down->where('is_deleted="0"');
			$list_provinces = $this->drop_down->build(null);

			$this->drop_down->select('regency_id','name');
			$this->drop_down->from('m_area_regencies');
			$this->drop_down->where('is_deleted="0"');
			$list_regencies = $this->drop_down->build(null);

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="periode_pilkada"');
			$list_periode = $this->drop_down->build(null);

			$this->drop_down->select('option_id','option_name');
			$this->drop_down->from('m_option');
			$this->drop_down->where('option_type="kategori_pelanggaran"');
			$list_kategori_pelanggaran = $this->drop_down->build(null);

			$data=array(
				'page_content' 				=> $page,
				'base_url'					=> base_url().$page,
				'list_provinces'			=> $list_provinces,
				'list_regencies'			=> $list_regencies,
				'list_periode'				=> $list_periode,
				'list_kategori_pelanggaran' => $list_kategori_pelanggaran,
				"tenant_id"					=> $this->session->userdata('tenant_id')
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function detail_data(){

		if($this->session->userdata('is_logged_in') == true){
			
		$id 		= $this->input->post('id');

		$this->load->model('m_page_sengketa');

		$data =  $this->m_page_sengketa->detail_data($id);


		echo json_encode($data);

		}else{
			exit();
		}
	}

	public function forms_submit(){

		if($this->session->userdata('is_logged_in') == true){

			$act 		= $this->input->post('act');
			$id 		= $this->input->post('id');
			$province_id= $this->input->post('province_id');
			$regency_id = $this->input->post('regency_id');
			$periode 	= $this->input->post('periode');
			$pemohon 	= $this->input->post('pemohon');
			$termohon 	= $this->input->post('termohon');
			$kategori_pelanggaran = $this->input->post('kategori_pelanggaran');
			$kategori_sengketa  = $this->input->post('kategori_sengketa');
			$obyek_sengketa  	= $this->input->post('obyek_sengketa');
			$keterangan = $this->input->post('keterangan');

			$upd 	= $this->session->userdata('userid');
			$lup 	= date('Y-m-d H:i:s');
	
			$this->load->model('m_page_sengketa');

			if($act=="Edit"){

					$submit = $this->m_page_sengketa->edit($act,$id,$province_id,$regency_id,$periode,$pemohon,
						$termohon,$kategori_pelanggaran,$kategori_sengketa,$obyek_sengketa,$keterangan,$upd,$lup);

					if($submit['status']){
						$statusResp=true;
						$reason="Update Data Successfully...!";
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}

			}else{
				
					$submit = $this->m_page_sengketa->add($act,$id,$province_id,$regency_id,$periode,$pemohon,
						$termohon,$kategori_pelanggaran,$kategori_sengketa,$obyek_sengketa,$keterangan,$upd,$lup);

					
					if($submit['status']){
						$statusResp=true;
						$reason=$submit['reason'];
					}else{
						$statusResp="fail";
						$reason= $submit['reason'];
					}					
			}

			echo json_encode(array("status"=>$statusResp, "reason"=>$reason));

		}else{
			exit();
		}

	}

	public function json_list(){
			
			$parent_page	=  $this->uri->segment(1);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_pelanggaran_pidana');
			
			$data =  $this->m_page_pelanggaran_pidana->list_data($length,$start,$search,$order,$dir);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				$iconAction = "<a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-primary btn-rounded mr-2 mb-2 pointer' id='modal_form' onclick=detail_data('".$row['id']."')>
								<i class='icmn-pencil'></i>
							  </a>";

				$output['data'][]=array(
					$nomor_urut, 
					$row['name'],
					$row['kode_wilayah'],
					$row['pemohon'],
					$row['termohon'],
					$row['kategori_sengketa'],
					$row['obyek_sengketa'],
					$row['keterangan'],
					$iconAction
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
