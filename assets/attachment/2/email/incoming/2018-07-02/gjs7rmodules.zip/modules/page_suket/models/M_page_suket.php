<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_suket extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY name";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" AND (a.name like '%$search%')";
		}

		$sql		= " SELECT a.`name`, IFNULL(b.`jumlah`,'0') AS jumlah, b.id, a.`province_id` as idx
						FROM 
						m_area_provinces a
						LEFT JOIN trans_suket b ON a.`province_id`=b.`kode_wilayah` COLLATE utf8_unicode_ci
						WHERE 1=1 COLLATE utf8_unicode_ci  AND a.status='1' $where_clause
						UNION
						SELECT a.`name`, IFNULL(b.`jumlah`,'0') AS jumlah, b.id , a.`regency_id` as idx
						FROM 
						m_area_regencies a
						LEFT JOIN trans_suket b ON a.`regency_id`=b.`kode_wilayah` COLLATE utf8_unicode_ci
						WHERE 1=1 COLLATE utf8_unicode_ci AND a.status='1' $where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
