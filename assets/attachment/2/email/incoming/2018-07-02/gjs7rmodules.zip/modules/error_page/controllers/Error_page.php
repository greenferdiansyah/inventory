<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Error_page extends CI_Controller {

	public function index(){
			
		$data = array("base_url" => base_url());

		$this->parser->parse('error_page', $data);
		
	}

}

/* End of file error_page.php */
/* Location: ./application/controllers/error_page.php */
