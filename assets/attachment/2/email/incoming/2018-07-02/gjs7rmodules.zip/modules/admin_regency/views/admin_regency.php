<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <span class="text-muted">Administration ·</span>
        <span class="text-muted">Wilayah ·</span>
        <strong>Kota/Kabupaten</strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Kota/Kabupaten </strong>
            <a data-toggle='modal' data-target='#merge_modal' class='btn btn-icon btn-success btn-rounded mr-2 mb-2 pointer pull-right' id='modal_form'>
                    <i class='icmn-plus'>Add</i>
            </a>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-hover nowrap" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Wilayah</th>
                            <th>Nama Provinsi</th>
                            <th>Nama Kota/Kabupaten</th>
                            <th>Partisipasi Pemilu</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Kode Wilayah</th>
                            <th>Nama Provinsi</th>
                            <th>Nama Kota/Kabupaten</th>
                            <th>Partisipasi Pemilu</th>
                            <th>Action</th>
                        </tr>
                        </tfoot>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="merge_modal" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Kota/Kabupaten</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="form-1" name="form-1" method="POST">
            <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" style="display: none"> 
            <input type="hidden" name="act" id="act" value="" style="display: none"> 
            <div class="modal-body">
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Kode Wilayah</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Kode Wilayah" id="kode_wil" name="kode_wil" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Nama Provinsi</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="province_id" 
                                            name="province_id">
                                        <option value="">Choose</option>    
                                        {list_provinces}
                            </select>
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Nama Kota/Kabupaten</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="Nama Provinsi" id="nama_wilayah" name="nama_wilayah" value="">
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">Status Partisipasi</label>
                        <div class="col-md-9">
                            <select class="form-control select2"
                                            data-validation="[NOTEMPTY]"
                                            id="status" 
                                            name="status">
                                        <option value="">Choose</option>    
                                        {list_status}
                            </select>
                        </div>
                </div>
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">IKP Partisipasi</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="IKP Partisipasi" id="ikp_partisipasi" name="ikp_partisipasi" value="">
                        </div>
                </div>    
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">IKP Konstetasi</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="IKP Konstetasi" id="ikp_konstetasi" name="ikp_konstetasi" value="">
                        </div>
                </div>  
                <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="l1">IKP Penyelenggaraan</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" placeholder="IKP Penyelenggaraan" id="ikp_penyelenggaraan" name="ikp_penyelenggaraan" value="">
                        </div>
                </div>          
            </div>
            <div class="modal-footer">
                <button type="button" class="btn pointer" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary pull-right pointer" >Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- END: tables/datatables -->
<!-- START: page scripts -->
<script>
    jQuery(document).ready(function($) {
        $('.select2').select2();

        $('#merge_modal').on('hidden.bs.modal', function () {
            // do something…
            $("#act").val('add');
            $("#kode_wil").val('');
            $("#nama_wilayah").val('');
            $("#ikp_partisipasi").val('');
            $("#ikp_konstetasi").val('');
            $("#ikp_penyelenggaraan").val('');
            $('#status').val(null).trigger('change');
            $('#province_id').val(null).trigger('change');
        })
    });

    $(function(){
     var baseUrl = '{base_url}';  

     var table =   
     $('#data-table').DataTable({
            processing: true,
            destroy:true,
            serverSide: true,
            responsive: true,
            autoFill: true,
            colReorder: true,
            keys: true,
            rowReorder: true,
            columnDefs: [
                { "width": "10%", "targets": 0 },
                { className: "text-center col-with-icon", "targets": [ 3 ] },
                { className: "text-center col-with-icon", "targets": [ 4 ] },
            ],
            ajax: {
                url: baseUrl+"/json_list",
                type:'POST',
            }
        });

    table_reload = setInterval( function () {
        table.ajax.reload( null, false ); // user paging is not reset on reload
    }, 50000 );  

    $('#form-1').validate({
        submit: {
            settings: {
                inputContainer: '.form-group',
                errorListClass: 'form-control-error',
                errorClass: 'has-danger'
            },
            callback: {
                onBeforeSubmit: function (node) {
                    NProgress.start();    
                },
                onSubmit: function (node) {

                    $.ajax({
                        url: '{base_url}/forms_submit',
                        type: 'POST',
                        dataType: 'json',
                        data: $('#form-1').serialize() ,
                    })
                    .done(function(data) {
                        NProgress.done();
                        if(data.status==true){
                            
                            $.notify({
                            title: '<strong>Success!</strong>',
                            message: data.reason
                            },{
                                type: 'primary'
                            });
                            
                            $('#merge_modal').modal('hide');
                            $("#act").val('add');
                            $("#kode_wil").val('');
                            $("#nama_wilayah").val('');
                            $("#ikp_partisipasi").val('');
                            $("#ikp_konstetasi").val('');
                            $("#ikp_penyelenggaraan").val('');
                            $('#status').val(null).trigger('change');
                            $('#province_id').val(null).trigger('change');
                            table.ajax.reload( null, false );
                        }else{
                            $.notify(data.reason);
                        }          
                    })
                    .fail(function() {
                        NProgress.done();
                        $.notify("Fail Save Data, Please check your connections...");
                    });
                    
                },
                onError: function (error) {
                    $.notify("Fail, Please Check your input...");
                }

            }
        },
        debug: true

    });

    del = function (id){   
   
        swal({
            title: "Are you sure?",
            text: "You will not be able to recover this item!",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Yes, remove it",
            cancelButtonText: "Cancel",
            closeOnConfirm: false,
            closeOnCancel: false
        },
        function(isConfirm) {
            if (isConfirm) {

                $.ajax({
                    url: baseUrl+"/del_item",
                    type: 'POST',
                    dataType: 'json',
                    data: {id: id},
                })
                .done(function() {
                    swal({
                        title: "Deleted!",
                        text: "Your item has been deleted.",
                        type: "success",
                        confirmButtonClass: "btn-success"
                    });
                })
                .fail(function() {
                    swal({
                        title: "Error",
                        text: "Your item is safe :). Fail deleted item",
                        type: "error",
                        confirmButtonClass: "btn-danger"
                    });
                })
                .always(function() {
                    table.ajax.reload( null, false );
                });
                          
            } else {
                swal({
                    title: "Cancelled",
                    text: "Your item is safe :)",
                    type: "error",
                    confirmButtonClass: "btn-danger"
                });
            }
        });
    }

    });

    function change_status(id){

    var baseUrl = '{base_url}';  
        
        if ($("#"+id+"").is(':checked')) {
            var dataStatus = '1';
        }else{
            var dataStatus = '0';
        }

        $.ajax({
            url: baseUrl+"/change_status",
            type: 'POST',
            dataType: 'json',
            data: {id: id , status:dataStatus },
        })
        .done(function(data) {
            if(data.status='success'){
                $.notify({
                title: '<strong>Success!</strong>',
                message: data.reason
                },{
                    type: 'primary'
                });
            }else{
                $.notify({
                title: '<strong>Fail!</strong>',
                message: data.reason
                },{
                    type: 'danger'
                });
            }
            
        })
        .fail(function(data) {
            $.notify({
                title: '<strong>Error!</strong>',
                message: data.reason
            },{
                type: 'danger'
            });
        });
        
    }

    function detail_data(id){

    var baseUrl = '{base_url}';  
        
        $.ajax({
            url: baseUrl+"/detail_data",
            type: 'POST',
            dataType: 'json',
            data: {id: id },
        })
        .done(function(data) {
            
                $("#act").val('Edit');
                $("#kode_wil").val(data.regency_id);
                $("#nama_wilayah").val(data.kota_kab);
                $("#ikp_partisipasi").val(data.ikp_partisipasi);
                $("#ikp_konstetasi").val(data.ikp_konstetasi);
                $("#ikp_penyelenggaraan").val(data.ikp_penyelenggaraan);
                $('#status').val(data.status).trigger('change');
                $('#province_id').val(data.province_id).trigger('change');
                
        })
        .fail(function(data) {
                $("#act").val('add');
                $("#kode_wil").val('');
                $("#nama_wilayah").val('');
                $("#ikp_partisipasi").val('');
                $("#ikp_konstetasi").val('');
                $("#ikp_penyelenggaraan").val('');
                $('#status').val(null).trigger('change');
                $('#province_id').val(null).trigger('change');
        });
    }
  
    
</script>
<!-- END: page scripts -->