<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page_dpt extends CI_Controller {

	public function index(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
				
			$this->load->library('page_render');
			
			$data=array(
				'page_content' 				=> $page,
				'base_url'					=> base_url().$page,
				"tenant_id"					=> $this->session->userdata('tenant_id')
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list(){
			
			$parent_page	=  $this->uri->segment(1);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_dpt');
			
			$data =  $this->m_page_dpt->list_data($length,$start,$search,$order,$dir);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				$iconAction = "<a href='main#".$parent_page."/view_regency/".base64_encode($this->encryption->encrypt($row['id_provinces']))."' data-toggle='tooltip' title='View Details Area' aria-expanded='false'>
			                    ".$row['name']."
			                  </a>";

				$output['data'][]=array(
					$nomor_urut, 
					$iconAction, 
					number_format($row['sum_tps']),
					number_format($row['sum_man']),
					number_format($row['sum_woman']),
					number_format($row['sum_gender']),
					number_format($row['dif_1']),
					number_format($row['dif_2']),
					number_format($row['dif_3']),
					number_format($row['dif_4']),
					number_format($row['dif_5']),
					number_format($row['sum_dif']),
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function view_regency(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
			$page_content	=  $this->uri->segment(2);

			$this->load->library('encryption');
			$id_provinces = $this->encryption->decrypt(base64_decode($this->uri->segment(3)));

			$this->load->model('m_page_dpt');

			$province_name = $this->m_page_dpt->find_province_name($id_provinces);

			$this->load->library('page_render');
			
			$data=array(
				'page_content' 				=> $page.'_'.$page_content,
				'base_url'					=> base_url().$page,
				'id_provinces'				=> $id_provinces,
				'province_name'				=> $province_name,
				"tenant_id"					=> $this->session->userdata('tenant_id')
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list_regency(){
			
			$parent_page	=  $this->uri->segment(1);

			$this->load->library('encryption');
			$find_id		=  $this->uri->segment(3);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_dpt');
			
			$data =  $this->m_page_dpt->list_data_regency($length,$start,$search,$order,$dir,$find_id);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				$iconAction = "<a href='main#".$parent_page."/view_district/".base64_encode($this->encryption->encrypt($row['id_regencies']))."' data-toggle='tooltip' title='View Details Area' aria-expanded='false'>
			                    ".$row['name']."
			                  </a>";

				$output['data'][]=array(
					$nomor_urut, 
					$iconAction, 
					number_format($row['sum_tps']),
					number_format($row['sum_man']),
					number_format($row['sum_woman']),
					number_format($row['sum_gender']),
					number_format($row['dif_1']),
					number_format($row['dif_2']),
					number_format($row['dif_3']),
					number_format($row['dif_4']),
					number_format($row['dif_5']),
					number_format($row['sum_dif']),
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function view_district(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
			$page_content	=  $this->uri->segment(2);

			$this->load->library('encryption');
			$id_regency = $this->encryption->decrypt(base64_decode($this->uri->segment(3)));

			$this->load->model('m_page_dpt');

			$regency_name = $this->m_page_dpt->find_regency_name($id_regency);

			$this->load->library('page_render');
			
			$data=array(
				'page_content' 				=> $page.'_'.$page_content,
				'base_url'					=> base_url().$page,
				'id_regency'				=> $id_regency,
				'province_name'				=> $regency_name[0]['province'],
				'regency_name'				=> $regency_name[0]['regency'],
				"tenant_id"					=> $this->session->userdata('tenant_id')
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list_district(){
			
			$parent_page	=  $this->uri->segment(1);

			$this->load->library('encryption');
			$find_id		=  $this->uri->segment(3);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_dpt');
			
			$data =  $this->m_page_dpt->list_data_district($length,$start,$search,$order,$dir,$find_id);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				$iconAction = "<a href='main#".$parent_page."/view_villages/".base64_encode($this->encryption->encrypt($row['id_district']))."' data-toggle='tooltip' title='View Details Area' aria-expanded='false'>
			                    ".$row['name']."
			                  </a>";

				$output['data'][]=array(
					$nomor_urut, 
					$iconAction, 
					number_format($row['sum_tps']),
					number_format($row['sum_man']),
					number_format($row['sum_woman']),
					number_format($row['sum_gender']),
					number_format($row['dif_1']),
					number_format($row['dif_2']),
					number_format($row['dif_3']),
					number_format($row['dif_4']),
					number_format($row['dif_5']),
					number_format($row['sum_dif']),
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

	public function view_villages(){

		if($this->session->userdata('is_logged_in') == true){

			$parent_page	=  $this->uri->segment(1);
			$page			=  $this->uri->segment(1);
			$page_content	=  $this->uri->segment(2);

			$this->load->library('encryption');
			$id_district = $this->encryption->decrypt(base64_decode($this->uri->segment(3)));

			$this->load->model('m_page_dpt');

			$district_name = $this->m_page_dpt->find_district_name($id_district);

			$this->load->library('page_render');
			
			$data=array(
				'page_content' 				=> $page.'_'.$page_content,
				'base_url'					=> base_url().$page,
				'id_district'				=> $id_district,
				'province_name'				=> $district_name[0]['province'],
				'regency_name'				=> $district_name[0]['regency'],
				'district'					=> $district_name[0]['district'],
				"tenant_id"					=> $this->session->userdata('tenant_id')
			);

			$this->parser->parse('master/content', $data);

		}else{
			redirect('login');
		}
	}

	public function json_list_villages(){
			
			$parent_page	=  $this->uri->segment(1);

			$this->load->library('encryption');
			$find_id		=  $this->uri->segment(3);
			
			$draw=$_REQUEST['draw'];
			$length=$_REQUEST['length'];
			$start=$_REQUEST['start'];
			$search=$_REQUEST['search']["value"];
			
			$order=$_REQUEST['order'][0]["column"];
			$dir=$_REQUEST['order'][0]["dir"];

			$this->load->library('encryption');
			$this->load->model('m_page_dpt');
			
			$data =  $this->m_page_dpt->list_data_villages($length,$start,$search,$order,$dir,$find_id);
			
			$output=array();
			$output['draw']=$draw;
			$output['recordsTotal']=$output['recordsFiltered']=$data['total_data'];
			$output['data']=array();
			
			
			$nomor_urut=$start+1;
			setlocale(LC_ALL, 'id_ID');
			
			foreach ($data['data'] as $rows =>$row) {
				
				/*$iconAction = "<a href='main#".$parent_page."/view_villages/".base64_encode($this->encryption->encrypt($row['id_district']))."' data-toggle='tooltip' title='View Details Area' aria-expanded='false'>
			                    ".$row['name']."
			                  </a>";*/
			                  
				$output['data'][]=array(
					$nomor_urut, 
					$row['name'], 
					number_format($row['sum_tps']),
					number_format($row['sum_man']),
					number_format($row['sum_woman']),
					number_format($row['sum_gender']),
					number_format($row['dif_1']),
					number_format($row['dif_2']),
					number_format($row['dif_3']),
					number_format($row['dif_4']),
					number_format($row['dif_5']),
					number_format($row['sum_dif']),
				);
				$nomor_urut++;
			}
			
			echo json_encode($output);
	}

}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
