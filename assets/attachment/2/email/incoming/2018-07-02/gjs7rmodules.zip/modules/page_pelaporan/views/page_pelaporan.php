<nav class="cat__core__top-sidebar cat__core__top-sidebar--bg">
    <span class="cat__core__title d-block mb-2">
        <strong>E-Pelaporan</strong>
    </span>
</nav>
<!-- START: tables/datatables -->
<section class="card">
    <div class="card-header">
        <span class="cat__core__title">
            <strong> Data E-Pelaporan </strong>
        </span>   
    </div>
    <div class="card-block">
        <div class="row">
            <div class="col-lg-12">
                <div class="mb-5">
                    <table class="table table-striped table-bordered table-condensed display select" id="data-table" width="100%">
                        <thead>
                        <tr>
                            <th rowspan="1" style="text-align: center; vertical-align: middle; width: 21px;">No</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle; width: 21px;">Tanggal</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Jam</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Daerah</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Kejadian</th>
                            <th rowspan="1" style="text-align: center; vertical-align: middle" >Tindak Lanjut</th>
                        </tr>
                        </thead>
                        <tbody id="list_queue_data" >
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="merge_modal" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Bukti Pelaporan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="image_bukti"></div>
        </div>
    </div>
</div>
<!-- END: tables/datatables -->
<!-- START: page scripts -->
<script src="assets/js/numeral.min.js"></script>
<script>
    $(function(){
     var baseUrl = '{base_url}';  
     var table =   
     $('#data-table').DataTable({
            processing: true,
            destroy:true,
            serverSide: true,
            responsive: true,
            autoFill: true,
            colReorder: true,
            keys: true,
            rowReorder: true,
            pageLength : 50,
            columnDefs: [
                { "width": "2%", "targets": 0 },
                { "width": "15%", "targets": 1 },
                { "width": "15%", className: "text-left col-with-icon", "targets": [ 2 ] },
                { className: "text-left col-with-icon", "targets": [ 3 ] },
                { className: "text-left col-with-icon", "targets": [ 4 ] },
                { className: "text-center col-with-icon", "targets": [ 5 ] },
            ],
            ajax: {
                url: baseUrl+"/json_list",
                type:'POST',
            }
    });

    }); 

    function detail_data(img_laporan){
        var xx ='<img class="cat__apps__profile__wall__message-img" src="{base}assets/img/laporan/'+img_laporan+'">';
         $('#image_bukti').html(xx);
    }
</script>
<!-- END: page scripts -->