<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Master_setting extends CI_Model {
	
	public function SetSettings()
	{
		$data = $this->db->query("SELECT * FROM master_setting");
		
		$setting = $data->result_array();
		
		return $setting[0];
	}
	
	public function SetMenu($level=NULL)
	{
		
		$where_clause = "";
		if($level!=NULL){
			$where_clause .= "AND userlevel REGEXP \"$level\"";
		}
		
		$sql = "SELECT id, menuname, parent, url, icon, is_default, tooltip, divider
				FROM m_menu
				WHERE `status`=1 
				$where_clause
				ORDER BY parent, id ASC";
		
		$query = $this->db->query($sql);
		
		$menus = $query->result_array();
		
		return $menus;
	}
	
	public function check_auth($level=NULL, $url=NULL)
	{
		
		$where_clause = "AND userlevel REGEXP \"$level\" AND url='$url'";
		
		$sql	=	"SELECT id
					FROM m_menu
					WHERE id IS NOT NULL
					$where_clause";
		
		$query	= $this->db->query($sql);
		
		$result	= $query->num_rows();
		
		return $result;
	}

}

/* End of file Master_setting.php */
/* Location: ./application/models/Master_setting.php */