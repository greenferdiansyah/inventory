<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Download extends CI_Controller {

	public function index(){

		redirect('login');
	}


	public function file(){

		if($this->session->userdata('is_logged_in') == true){

			$this->load->library('encryption');

			$id	=	$this->encryption->decrypt(base64_decode($this->uri->segment(3)));
			
			$sql = "SELECT a.id, a.ticket_id, a.attach_type, a.filename, a.orig_name, a.path_file
					FROM 
					trans_attachments a WHERE a.id='$id'";
			$query = $this->db->query($sql);
		
			$result = $query->result_array();		
			if(isset($result[0])){
				// Contents will be automatically read
					$file		= $result[0]['path_file'].'/'.$result[0]['filename'];
					
					$data		= file_get_contents($file);
					$orig_name	= $result[0]['orig_name'];
				
					$this->load->helper('download');
					force_download($orig_name, $data, TRUE);
			}else{
				exit();
			}

		}else{
			exit();
		}
		
		
	}


}

/* End of file Admin_support_site.php */
/* Location: ./application/controllers/Admin_support_site.php */
