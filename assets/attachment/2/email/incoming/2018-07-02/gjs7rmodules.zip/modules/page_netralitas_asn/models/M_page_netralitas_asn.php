<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_netralitas_asn extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY a.created_at DESC";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" WHERE (b.name like '%$search%' OR c.name like '%$search%' 
			OR a.kejadian like '%$search%' OR a.jumlah_asn like '%$search%' OR a.keputusan like '%$search%' OR a.keterangan like '%$search%')";
		}

		$sql		= " SELECT b.name AS provinsi, c.name AS kabkot, a.kejadian, a.jumlah_asn, a.keputusan, a.keterangan, a.id  
						FROM trans_netralitas_asn a
						LEFT JOIN m_area_provinces b ON a.province_id=b.province_id COLLATE utf8_unicode_ci
						LEFT JOIN m_area_regencies c ON a.regency_id=c.regency_id COLLATE utf8_unicode_ci
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	function detail_data($id){
		$this->db->query("SET sql_mode=''");
		$this->db->select('id, province_id, regency_id, kejadian, jumlah_asn, keputusan, keterangan');
		$query = $this->db->get_where('trans_netralitas_asn', array('id' => $id));

		$data = $query->result_array();
		
		return $data[0];

	}

	function add($act,$id,$province_id,$regency_id,$kejadian,
						$jumlah_asn,$keputusan,$keterangan,$upd,$lup){

		$data = array(
		   'province_id' => $province_id,	
		   'regency_id' => $regency_id,
		   'kejadian' => $kejadian,
		   'jumlah_asn' => $jumlah_asn,
		   'keputusan' => $keputusan,
		   'keterangan' => $keterangan,
		   'created' => $upd,
		   'created_at' => $lup,
		   'updated' => $upd,
		   'updated_at' => $lup
		);

		$insert = $this->db->insert('trans_netralitas_asn', $data); 

		if($insert){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}


	function edit($act,$id,$province_id,$regency_id,$kejadian,
						$jumlah_asn,$keputusan,$keterangan,$upd,$lup){
		
		$data = array('province_id' => $province_id,
					  'regency_id' => $regency_id,
					  'kejadian' => $kejadian,
					  'jumlah_asn' => $jumlah_asn,
					  'keputusan' => $keputusan,
					  'keterangan' => $keterangan,
					  'updated' => $upd,
					  'updated_at' => $lup
					);

		$this->db->where('id', $id );

		$update	= $this->db->update('trans_netralitas_asn', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;
	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
