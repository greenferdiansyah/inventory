<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_page_wait_approval extends CI_Model {

	public function list_data($length,$start,$search,$order,$dir){
		
		$order_by="ORDER BY a.tanggal_laporan DESC";
		if($order!=0){
			$order_by="ORDER BY $order $dir";
		}
		
		$where_clause="";
		 if($search!=""){
			$where_clause=" WHERE (DATE(a.`tanggal_laporan`) like '%$search%' OR DATE_FORMAT(a.`tanggal_laporan`, '%H:%i') like '%$search%' 
			OR a.`lokasi` like '%$search%' OR a.`keterangan` like '%$search%' )";
		}

		$sql		= " SELECT DATE(a.`tanggal_laporan`) AS tanggal, DATE_FORMAT(a.`tanggal_laporan`, '%H:%i') AS jam,
						a.`lokasi`,a.`keterangan`,a.`img_laporan`, a.flg_verify_show ,a.nomor_laporan
						FROM trans_laporan a
						INNER JOIN m_login b ON a.`id_pelapor`=b.`userid` AND a.flg_verify_show=0
						$where_clause
						$order_by";
						
		$query		= $this->db->query($sql . " LIMIT $start, $length");

		$numrows	= $this->db->query($sql);
		$total		= $numrows->num_rows();
		
		return array("data"=>$query->result_array(),
						"total_data"=>$total
				);
	}

	function update_status($id,$status,$upd,$lup){

		$data = array('flg_verify_show' => $status);

		$this->db->where('nomor_laporan', $id );

		$update	= $this->db->update('trans_laporan', $data); 

		if($update){
			$result = array('status'=> 'success', 'reason'=> 'Data has been changed');
		}else{
			$result = array('status'=> 'fail', 'reason'=> 'Failed Update Data');
		}

		return $result;

	}
}

/* End of file M_admin_users.php */
/* Location: ./application/models/M_admin_users.php */
